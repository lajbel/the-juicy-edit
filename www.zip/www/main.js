(() => {
  // node_modules/kaboom/dist/kaboom.mjs
  var Ft = Object.defineProperty;
  var cs = (i, r, o) => r in i ? Ft(i, r, { enumerable: true, configurable: true, writable: true, value: o }) : i[r] = o;
  var u = (i, r) => Ft(i, "name", { value: r, configurable: true });
  var ls = (i, r) => {
    for (var o in r)
      Ft(i, o, { get: r[o], enumerable: true });
  };
  var Z = (i, r, o) => (cs(i, typeof r != "symbol" ? r + "" : r, o), o);
  var hs = (() => {
    for (var i = new Uint8Array(128), r = 0; r < 64; r++)
      i[r < 26 ? r + 65 : r < 52 ? r + 71 : r < 62 ? r - 4 : r * 4 - 205] = r;
    return (o) => {
      for (var c2 = o.length, b = new Uint8Array((c2 - (o[c2 - 1] == "=") - (o[c2 - 2] == "=")) * 3 / 4 | 0), m = 0, C = 0; m < c2; ) {
        var R = i[o.charCodeAt(m++)], T = i[o.charCodeAt(m++)], O = i[o.charCodeAt(m++)], M = i[o.charCodeAt(m++)];
        b[C++] = R << 2 | T >> 4, b[C++] = T << 4 | O >> 2, b[C++] = O << 6 | M;
      }
      return b;
    };
  })();
  function me(i) {
    return i * Math.PI / 180;
  }
  u(me, "deg2rad");
  function Bt(i) {
    return i * 180 / Math.PI;
  }
  u(Bt, "rad2deg");
  function te(i, r, o) {
    return r > o ? te(i, o, r) : Math.min(Math.max(i, r), o);
  }
  u(te, "clamp");
  function ze(i, r, o) {
    return i + (r - i) * o;
  }
  u(ze, "lerp");
  function dt(i, r, o, c2, b) {
    return c2 + (i - r) / (o - r) * (b - c2);
  }
  u(dt, "map");
  function qn(i, r, o, c2, b) {
    return te(dt(i, r, o, c2, b), c2, b);
  }
  u(qn, "mapc");
  var H = class {
    x = 0;
    y = 0;
    constructor(r = 0, o = r) {
      this.x = r, this.y = o;
    }
    static fromAngle(r) {
      let o = me(r);
      return new H(Math.cos(o), Math.sin(o));
    }
    clone() {
      return new H(this.x, this.y);
    }
    add(...r) {
      let o = f(...r);
      return new H(this.x + o.x, this.y + o.y);
    }
    sub(...r) {
      let o = f(...r);
      return new H(this.x - o.x, this.y - o.y);
    }
    scale(...r) {
      let o = f(...r);
      return new H(this.x * o.x, this.y * o.y);
    }
    dist(...r) {
      let o = f(...r);
      return Math.sqrt((this.x - o.x) * (this.x - o.x) + (this.y - o.y) * (this.y - o.y));
    }
    len() {
      return this.dist(new H(0, 0));
    }
    unit() {
      let r = this.len();
      return r === 0 ? new H(0) : this.scale(1 / r);
    }
    normal() {
      return new H(this.y, -this.x);
    }
    dot(r) {
      return this.x * r.x + this.y * r.y;
    }
    angle(...r) {
      let o = f(...r);
      return Bt(Math.atan2(this.y - o.y, this.x - o.x));
    }
    lerp(r, o) {
      return new H(ze(this.x, r.x, o), ze(this.y, r.y, o));
    }
    isZero() {
      return this.x === 0 && this.y === 0;
    }
    toFixed(r) {
      return new H(Number(this.x.toFixed(r)), Number(this.y.toFixed(r)));
    }
    eq(r) {
      return this.x === r.x && this.y === r.y;
    }
    toString() {
      return `vec2(${this.x.toFixed(2)}, ${this.y.toFixed(2)})`;
    }
  };
  var D = H;
  u(D, "Vec2"), Z(D, "LEFT", new H(-1, 0)), Z(D, "RIGHT", new H(1, 0)), Z(D, "UP", new H(0, -1)), Z(D, "DOWN", new H(0, 1));
  function f(...i) {
    if (i.length === 1) {
      if (i[0] instanceof D)
        return f(i[0].x, i[0].y);
      if (Array.isArray(i[0]) && i[0].length === 2)
        return f(...i[0]);
    }
    return new D(...i);
  }
  u(f, "vec2");
  var je = class {
    x = 0;
    y = 0;
    z = 0;
    constructor(r, o, c2) {
      this.x = r, this.y = o, this.z = c2;
    }
    xy() {
      return f(this.x, this.y);
    }
  };
  u(je, "Vec3");
  var ge = u((i, r, o) => new je(i, r, o), "vec3");
  var se = class {
    r = 255;
    g = 255;
    b = 255;
    constructor(r, o, c2) {
      this.r = te(r, 0, 255), this.g = te(o, 0, 255), this.b = te(c2, 0, 255);
    }
    static fromArray(r) {
      return new se(r[0], r[1], r[2]);
    }
    static fromHex(r) {
      if (typeof r == "number")
        return new se(r >> 16 & 255, r >> 8 & 255, r >> 0 & 255);
      {
        let o = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(r);
        return new se(parseInt(o[1], 16), parseInt(o[2], 16), parseInt(o[3], 16));
      }
    }
    static fromHSL(r, o, c2) {
      if (o == 0)
        return x(255 * c2, 255 * c2, 255 * c2);
      let b = u((M, U, g) => (g < 0 && (g += 1), g > 1 && (g -= 1), g < 1 / 6 ? M + (U - M) * 6 * g : g < 1 / 2 ? U : g < 2 / 3 ? M + (U - M) * (2 / 3 - g) * 6 : M), "hue2rgb"), m = c2 < 0.5 ? c2 * (1 + o) : c2 + o - c2 * o, C = 2 * c2 - m, R = b(C, m, r + 1 / 3), T = b(C, m, r), O = b(C, m, r - 1 / 3);
      return new se(Math.round(R * 255), Math.round(T * 255), Math.round(O * 255));
    }
    clone() {
      return new se(this.r, this.g, this.b);
    }
    lighten(r) {
      return new se(this.r + r, this.g + r, this.b + r);
    }
    darken(r) {
      return this.lighten(-r);
    }
    invert() {
      return new se(255 - this.r, 255 - this.g, 255 - this.b);
    }
    mult(r) {
      return new se(this.r * r.r / 255, this.g * r.g / 255, this.b * r.b / 255);
    }
    eq(r) {
      return this.r === r.r && this.g === r.g && this.b === r.b;
    }
    toString() {
      return `rgb(${this.r}, ${this.g}, ${this.b})`;
    }
    toHex() {
      return "#" + ((1 << 24) + (this.r << 16) + (this.g << 8) + this.b).toString(16).slice(1);
    }
  };
  var E = se;
  u(E, "Color"), Z(E, "RED", x(255, 0, 0)), Z(E, "GREEN", x(0, 255, 0)), Z(E, "BLUE", x(0, 0, 255)), Z(E, "YELLOW", x(255, 255, 0)), Z(E, "MAGENTA", x(255, 0, 255)), Z(E, "CYAN", x(0, 255, 255)), Z(E, "WHITE", x(255, 255, 255)), Z(E, "BLACK", x(0, 0, 0));
  function x(...i) {
    if (i.length === 0)
      return new E(255, 255, 255);
    if (i.length === 1) {
      if (i[0] instanceof E)
        return i[0].clone();
      if (Array.isArray(i[0]) && i[0].length === 3)
        return E.fromArray(i[0]);
    }
    return new E(...i);
  }
  u(x, "rgb");
  var zn = u((i, r, o) => E.fromHSL(i, r, o), "hsl2rgb");
  var j = class {
    x = 0;
    y = 0;
    w = 1;
    h = 1;
    constructor(r, o, c2, b) {
      this.x = r, this.y = o, this.w = c2, this.h = b;
    }
    scale(r) {
      return new j(this.x + this.w * r.x, this.y + this.h * r.y, this.w * r.w, this.h * r.h);
    }
    clone() {
      return new j(this.x, this.y, this.w, this.h);
    }
    eq(r) {
      return this.x === r.x && this.y === r.y && this.w === r.w && this.h === r.h;
    }
    toString() {
      return `quad(${this.x}, ${this.y}, ${this.w}, ${this.h})`;
    }
  };
  u(j, "Quad");
  function Hn(i, r, o, c2) {
    return new j(i, r, o, c2);
  }
  u(Hn, "quad");
  var A = class {
    m = [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1];
    constructor(r) {
      r && (this.m = r);
    }
    static translate(r) {
      return new A([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, r.x, r.y, 0, 1]);
    }
    static scale(r) {
      return new A([r.x, 0, 0, 0, 0, r.y, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]);
    }
    static rotateX(r) {
      return r = me(-r), new A([1, 0, 0, 0, 0, Math.cos(r), -Math.sin(r), 0, 0, Math.sin(r), Math.cos(r), 0, 0, 0, 0, 1]);
    }
    static rotateY(r) {
      return r = me(-r), new A([Math.cos(r), 0, Math.sin(r), 0, 0, 1, 0, 0, -Math.sin(r), 0, Math.cos(r), 0, 0, 0, 0, 1]);
    }
    static rotateZ(r) {
      return r = me(-r), new A([Math.cos(r), -Math.sin(r), 0, 0, Math.sin(r), Math.cos(r), 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]);
    }
    translate(r) {
      return this.mult(A.translate(r));
    }
    scale(r) {
      return this.mult(A.scale(r));
    }
    rotateX(r) {
      return this.mult(A.rotateX(r));
    }
    rotateY(r) {
      return this.mult(A.rotateY(r));
    }
    rotateZ(r) {
      return this.mult(A.rotateZ(r));
    }
    mult(r) {
      let o = [];
      for (let c2 = 0; c2 < 4; c2++)
        for (let b = 0; b < 4; b++)
          o[c2 * 4 + b] = this.m[0 * 4 + b] * r.m[c2 * 4 + 0] + this.m[1 * 4 + b] * r.m[c2 * 4 + 1] + this.m[2 * 4 + b] * r.m[c2 * 4 + 2] + this.m[3 * 4 + b] * r.m[c2 * 4 + 3];
      return new A(o);
    }
    multVec4(r) {
      return { x: r.x * this.m[0] + r.y * this.m[4] + r.z * this.m[8] + r.w * this.m[12], y: r.x * this.m[1] + r.y * this.m[5] + r.z * this.m[9] + r.w * this.m[13], z: r.x * this.m[2] + r.y * this.m[6] + r.z * this.m[10] + r.w * this.m[14], w: r.x * this.m[3] + r.y * this.m[7] + r.z * this.m[11] + r.w * this.m[15] };
    }
    multVec3(r) {
      let o = this.multVec4({ x: r.x, y: r.y, z: r.z, w: 1 });
      return ge(o.x, o.y, o.z);
    }
    multVec2(r) {
      return f(r.x * this.m[0] + r.y * this.m[4] + 0 * this.m[8] + 1 * this.m[12], r.x * this.m[1] + r.y * this.m[5] + 0 * this.m[9] + 1 * this.m[13]);
    }
    invert() {
      let r = [], o = this.m[10] * this.m[15] - this.m[14] * this.m[11], c2 = this.m[9] * this.m[15] - this.m[13] * this.m[11], b = this.m[9] * this.m[14] - this.m[13] * this.m[10], m = this.m[8] * this.m[15] - this.m[12] * this.m[11], C = this.m[8] * this.m[14] - this.m[12] * this.m[10], R = this.m[8] * this.m[13] - this.m[12] * this.m[9], T = this.m[6] * this.m[15] - this.m[14] * this.m[7], O = this.m[5] * this.m[15] - this.m[13] * this.m[7], M = this.m[5] * this.m[14] - this.m[13] * this.m[6], U = this.m[4] * this.m[15] - this.m[12] * this.m[7], g = this.m[4] * this.m[14] - this.m[12] * this.m[6], de = this.m[5] * this.m[15] - this.m[13] * this.m[7], V = this.m[4] * this.m[13] - this.m[12] * this.m[5], Y = this.m[6] * this.m[11] - this.m[10] * this.m[7], Se = this.m[5] * this.m[11] - this.m[9] * this.m[7], Ce = this.m[5] * this.m[10] - this.m[9] * this.m[6], nt = this.m[4] * this.m[11] - this.m[8] * this.m[7], rt = this.m[4] * this.m[10] - this.m[8] * this.m[6], Te = this.m[4] * this.m[9] - this.m[8] * this.m[5];
      r[0] = this.m[5] * o - this.m[6] * c2 + this.m[7] * b, r[4] = -(this.m[4] * o - this.m[6] * m + this.m[7] * C), r[8] = this.m[4] * c2 - this.m[5] * m + this.m[7] * R, r[12] = -(this.m[4] * b - this.m[5] * C + this.m[6] * R), r[1] = -(this.m[1] * o - this.m[2] * c2 + this.m[3] * b), r[5] = this.m[0] * o - this.m[2] * m + this.m[3] * C, r[9] = -(this.m[0] * c2 - this.m[1] * m + this.m[3] * R), r[13] = this.m[0] * b - this.m[1] * C + this.m[2] * R, r[2] = this.m[1] * T - this.m[2] * O + this.m[3] * M, r[6] = -(this.m[0] * T - this.m[2] * U + this.m[3] * g), r[10] = this.m[0] * de - this.m[1] * U + this.m[3] * V, r[14] = -(this.m[0] * M - this.m[1] * g + this.m[2] * V), r[3] = -(this.m[1] * Y - this.m[2] * Se + this.m[3] * Ce), r[7] = this.m[0] * Y - this.m[2] * nt + this.m[3] * rt, r[11] = -(this.m[0] * Se - this.m[1] * nt + this.m[3] * Te), r[15] = this.m[0] * Ce - this.m[1] * rt + this.m[2] * Te;
      let bt = this.m[0] * r[0] + this.m[1] * r[4] + this.m[2] * r[8] + this.m[3] * r[12];
      for (let Ae = 0; Ae < 4; Ae++)
        for (let Oe = 0; Oe < 4; Oe++)
          r[Ae * 4 + Oe] *= 1 / bt;
      return new A(r);
    }
    clone() {
      return new A(this.m);
    }
    toString() {
      return this.m.toString();
    }
  };
  u(A, "Mat4");
  function Vt(i, r, o, c2 = Math.sin) {
    return i + (c2(o) + 1) / 2 * (r - i);
  }
  u(Vt, "wave");
  var ds = 1103515245;
  var fs = 12345;
  var _n = 2147483648;
  var ke = class {
    seed;
    constructor(r) {
      this.seed = r;
    }
    gen() {
      return this.seed = (ds * this.seed + fs) % _n, this.seed / _n;
    }
    genNumber(r, o) {
      return r + this.gen() * (o - r);
    }
    genVec2(r, o) {
      return new D(this.genNumber(r.x, o.x), this.genNumber(r.y, o.y));
    }
    genColor(r, o) {
      return new E(this.genNumber(r.r, o.r), this.genNumber(r.g, o.g), this.genNumber(r.b, o.b));
    }
    genAny(...r) {
      if (r.length === 0)
        return this.gen();
      if (r.length === 1) {
        if (typeof r[0] == "number")
          return this.genNumber(0, r[0]);
        if (r[0] instanceof D)
          return this.genVec2(f(0, 0), r[0]);
        if (r[0] instanceof E)
          return this.genColor(x(0, 0, 0), r[0]);
      } else if (r.length === 2) {
        if (typeof r[0] == "number" && typeof r[1] == "number")
          return this.genNumber(r[0], r[1]);
        if (r[0] instanceof D && r[1] instanceof D)
          return this.genVec2(r[0], r[1]);
        if (r[0] instanceof E && r[1] instanceof E)
          return this.genColor(r[0], r[1]);
      }
    }
  };
  u(ke, "RNG");
  var Lt = new ke(Date.now());
  function $n(i) {
    return i != null && (Lt.seed = i), Lt.seed;
  }
  u($n, "randSeed");
  function et(...i) {
    return Lt.genAny(...i);
  }
  u(et, "rand");
  function Gt(...i) {
    return Math.floor(et(...i));
  }
  u(Gt, "randi");
  function Yn(i) {
    return et() <= i;
  }
  u(Yn, "chance");
  function Xn(i) {
    return i[Gt(i.length)];
  }
  u(Xn, "choose");
  function Kn(i, r) {
    return i.pos.x + i.width > r.pos.x && i.pos.x < r.pos.x + r.width && i.pos.y + i.height > r.pos.y && i.pos.y < r.pos.y + r.height;
  }
  u(Kn, "testRectRect");
  function ms(i, r) {
    if (i.p1.x === i.p2.x && i.p1.y === i.p2.y || r.p1.x === r.p2.x && r.p1.y === r.p2.y)
      return null;
    let o = (r.p2.y - r.p1.y) * (i.p2.x - i.p1.x) - (r.p2.x - r.p1.x) * (i.p2.y - i.p1.y);
    if (o === 0)
      return null;
    let c2 = ((r.p2.x - r.p1.x) * (i.p1.y - r.p1.y) - (r.p2.y - r.p1.y) * (i.p1.x - r.p1.x)) / o, b = ((i.p2.x - i.p1.x) * (i.p1.y - r.p1.y) - (i.p2.y - i.p1.y) * (i.p1.x - r.p1.x)) / o;
    return c2 < 0 || c2 > 1 || b < 0 || b > 1 ? null : c2;
  }
  u(ms, "testLineLineT");
  function Ne(i, r) {
    let o = ms(i, r);
    return o ? f(i.p1.x + o * (i.p2.x - i.p1.x), i.p1.y + o * (i.p2.y - i.p1.y)) : null;
  }
  u(Ne, "testLineLine");
  function Qn(i, r) {
    if (He(i, r.p1) || He(i, r.p2))
      return true;
    let o = i.points();
    return !!Ne(r, new ie(o[0], o[1])) || !!Ne(r, new ie(o[1], o[2])) || !!Ne(r, new ie(o[2], o[3])) || !!Ne(r, new ie(o[3], o[0]));
  }
  u(Qn, "testRectLine");
  function He(i, r) {
    return r.x > i.pos.x && r.x < i.pos.x + i.width && r.y > i.pos.y && r.y < i.pos.y + i.height;
  }
  u(He, "testRectPoint");
  function Jn(i, r) {
    return i.center.dist(r) < i.radius;
  }
  u(Jn, "testCirclePoint");
  function Zn(i, r) {
    let o = false, c2 = i.pts;
    for (let b = 0, m = c2.length - 1; b < c2.length; m = b++)
      c2[b].y > r.y != c2[m].y > r.y && r.x < (c2[m].x - c2[b].x) * (r.y - c2[b].y) / (c2[m].y - c2[b].y) + c2[b].x && (o = !o);
    return o;
  }
  u(Zn, "testPolygonPoint");
  var ie = class {
    p1;
    p2;
    constructor(r, o) {
      this.p1 = r, this.p2 = o;
    }
    transform(r) {
      return new ie(r.multVec2(this.p1), r.multVec2(this.p2));
    }
    bbox() {
      return I.fromPoints(this.p1, this.p2);
    }
  };
  u(ie, "Line");
  var I = class {
    pos;
    width;
    height;
    constructor(r, o, c2) {
      this.pos = r, this.width = o, this.height = c2;
    }
    static fromPoints(r, o) {
      return new I(r.clone(), o.x - r.x, o.y - r.y);
    }
    center() {
      return new D(this.pos.x + this.width / 2, this.pos.y + this.height / 2);
    }
    points() {
      return [this.pos, this.pos.add(this.width, 0), this.pos.add(this.width, this.height), this.pos.add(0, this.height)];
    }
    transform(r) {
      return new oe(this.points().map((o) => r.multVec2(o)));
    }
    bbox() {
      return new I(this.pos.clone(), this.width, this.height);
    }
    distToPoint(r) {
      let o = this.pos, c2 = this.pos.add(this.width, this.height), b = Math.max(o.x - r.x, 0, r.x - c2.x), m = Math.max(o.y - r.y, 0, r.y - c2.y);
      return Math.sqrt(b * b + m * m);
    }
  };
  u(I, "Rect");
  var pe = class {
    center;
    radius;
    constructor(r, o) {
      this.center = r, this.radius = o;
    }
    transform(r) {
      return new _e(this.center, this.radius, this.radius).transform(r);
    }
    bbox() {
      return I.fromPoints(this.center.sub(f(this.radius)), this.center.add(f(this.radius)));
    }
  };
  u(pe, "Circle");
  var _e = class {
    center;
    radiusX;
    radiusY;
    constructor(r, o, c2) {
      this.center = r, this.radiusX = o, this.radiusY = c2;
    }
    transform(r) {
      return new _e(r.multVec2(this.center), r.m[0] * this.radiusX, r.m[5] * this.radiusY);
    }
    bbox() {
      return I.fromPoints(this.center.sub(f(this.radiusX, this.radiusY)), this.center.add(f(this.radiusX, this.radiusY)));
    }
  };
  u(_e, "Ellipse");
  var oe = class {
    pts;
    constructor(r) {
      if (r.length < 3)
        throw new Error("Polygons should have at least 3 vertices");
      this.pts = r;
    }
    transform(r) {
      return new oe(this.pts.map((o) => r.multVec2(o)));
    }
    bbox() {
      let r = f(Number.MAX_VALUE), o = f(-Number.MAX_VALUE);
      for (let c2 of this.pts)
        r.x = Math.min(r.x, c2.x), o.x = Math.max(o.x, c2.x), r.y = Math.min(r.y, c2.y), o.y = Math.max(o.y, c2.y);
      return I.fromPoints(r, o);
    }
  };
  u(oe, "Polygon");
  function Wn(i, r) {
    let o = Number.MAX_VALUE, c2 = f(0);
    for (let b of [i, r])
      for (let m = 0; m < b.pts.length; m++) {
        let C = b.pts[m], T = b.pts[(m + 1) % b.pts.length].sub(C).normal().unit(), O = Number.MAX_VALUE, M = -Number.MAX_VALUE;
        for (let V = 0; V < i.pts.length; V++) {
          let Y = i.pts[V].dot(T);
          O = Math.min(O, Y), M = Math.max(M, Y);
        }
        let U = Number.MAX_VALUE, g = -Number.MAX_VALUE;
        for (let V = 0; V < r.pts.length; V++) {
          let Y = r.pts[V].dot(T);
          U = Math.min(U, Y), g = Math.max(g, Y);
        }
        let de = Math.min(M, g) - Math.max(O, U);
        if (de < 0)
          return null;
        if (de < Math.abs(o)) {
          let V = g - O, Y = U - M;
          o = Math.abs(V) < Math.abs(Y) ? V : Y, c2 = T.scale(o);
        }
      }
    return c2;
  }
  u(Wn, "sat");
  var qe = { linear: (i) => i, easeInSine: (i) => 1 - Math.cos(i * Math.PI / 2), easeOutSine: (i) => Math.sin(i * Math.PI / 2), easeInOutSine: (i) => -(Math.cos(Math.PI * i) - 1) / 2, easeInQuad: (i) => i * i, easeOutQuad: (i) => 1 - (1 - i) * (1 - i), easeInOutQuad: (i) => i < 0.5 ? 2 * i * i : 1 - Math.pow(-2 * i + 2, 2) / 2, easeInCubic: (i) => i * i * i, easeOutCubic: (i) => 1 - Math.pow(1 - i, 3), easeInOutCubic: (i) => i < 0.5 ? 4 * i * i * i : 1 - Math.pow(-2 * i + 2, 3) / 2, easeInQuart: (i) => i * i * i * i, easeOutQuart: (i) => 1 - Math.pow(1 - i, 4), easeInOutQuart: (i) => i < 0.5 ? 8 * i * i * i * i : 1 - Math.pow(-2 * i + 2, 4) / 2, easeInQuint: (i) => i * i * i * i * i, easeOutQuint: (i) => 1 - Math.pow(1 - i, 5), easeInOutQuint: (i) => i < 0.5 ? 16 * i * i * i * i * i : 1 - Math.pow(-2 * i + 2, 5) / 2, easeInExpo: (i) => i === 0 ? 0 : Math.pow(2, 10 * i - 10), easeOutExpo: (i) => i === 1 ? 1 : 1 - Math.pow(2, -10 * i), easeInOutExpo: (i) => i === 0 ? 0 : i === 1 ? 1 : i < 0.5 ? Math.pow(2, 20 * i - 10) / 2 : (2 - Math.pow(2, -20 * i + 10)) / 2, easeInCirc: (i) => 1 - Math.sqrt(1 - Math.pow(i, 2)), easeOutCirc: (i) => Math.sqrt(1 - Math.pow(i - 1, 2)), easeInOutCirc: (i) => i < 0.5 ? (1 - Math.sqrt(1 - Math.pow(2 * i, 2))) / 2 : (Math.sqrt(1 - Math.pow(-2 * i + 2, 2)) + 1) / 2, easeInBack: (i) => 2.70158 * i * i * i - 1.70158 * i * i, easeOutBack: (i) => 1 + 2.70158 * Math.pow(i - 1, 3) + 1.70158 * Math.pow(i - 1, 2), easeInOutBack: (i) => {
    let o = 2.5949095;
    return i < 0.5 ? Math.pow(2 * i, 2) * ((o + 1) * 2 * i - o) / 2 : (Math.pow(2 * i - 2, 2) * ((o + 1) * (i * 2 - 2) + o) + 2) / 2;
  }, easeInBounce: (i) => 1 - qe.easeOutBounce(1 - i), easeOutBounce: (i) => i < 1 / 2.75 ? 7.5625 * i * i : i < 2 / 2.75 ? 7.5625 * (i -= 1.5 / 2.75) * i + 0.75 : i < 2.5 / 2.75 ? 7.5625 * (i -= 2.25 / 2.75) * i + 0.9375 : 7.5625 * (i -= 2.625 / 2.75) * i + 0.984375, easeInOutBounce: (i) => i < 0.5 ? (1 - qe.easeOutBounce(1 - 2 * i)) / 2 : (1 + qe.easeOutBounce(2 * i - 1)) / 2 };
  var ce = class extends Map {
    lastID;
    constructor(...r) {
      super(...r), this.lastID = 0;
    }
    push(r) {
      let o = this.lastID;
      return this.set(o, r), this.lastID++, o;
    }
    pushd(r) {
      let o = this.push(r);
      return () => this.delete(o);
    }
  };
  u(ce, "IDList");
  var ne = class {
    handlers = new ce();
    add(r) {
      return this.handlers.pushd(r);
    }
    addOnce(r) {
      let o = this.add((...c2) => {
        r(...c2), o();
      });
      return o;
    }
    trigger(...r) {
      this.handlers.forEach((o) => o(...r));
    }
    numListeners() {
      return this.handlers.size;
    }
  };
  u(ne, "Event");
  var le = class {
    handlers = /* @__PURE__ */ new Map();
    on(r, o) {
      return this.handlers.get(r) || this.handlers.set(r, new ne()), this.handlers.get(r).add(o);
    }
    onOnce(r, o) {
      let c2 = this.on(r, (...b) => {
        o(...b), c2();
      });
      return c2;
    }
    trigger(r, ...o) {
      this.handlers.get(r) && this.handlers.get(r).trigger(...o);
    }
    remove(r) {
      this.handlers.delete(r);
    }
    clear() {
      this.handlers = /* @__PURE__ */ new Map();
    }
    numListeners(r) {
      return this.handlers.get(r)?.numListeners() ?? 0;
    }
  };
  u(le, "EventHandler");
  function It(i, r) {
    let o = typeof i, c2 = typeof r;
    if (o !== c2)
      return false;
    if (o === "object" && c2 === "object") {
      let b = Object.keys(i), m = Object.keys(r);
      if (b.length !== m.length)
        return false;
      for (let C of b) {
        let R = i[C], T = r[C];
        if (!(typeof R == "function" && typeof T == "function") && !It(R, T))
          return false;
      }
      return true;
    }
    return i === r;
  }
  u(It, "deepEq");
  function ps(i) {
    let r = window.atob(i), o = r.length, c2 = new Uint8Array(o);
    for (let b = 0; b < o; b++)
      c2[b] = r.charCodeAt(b);
    return c2.buffer;
  }
  u(ps, "base64ToArrayBuffer");
  function er(i) {
    return ps(i.split(",")[1]);
  }
  u(er, "dataURLToArrayBuffer");
  function ft(i, r) {
    let o = document.createElement("a");
    o.href = r, o.download = i, o.click();
  }
  u(ft, "download");
  function Nt(i, r) {
    ft(i, "data:text/plain;charset=utf-8," + r);
  }
  u(Nt, "downloadText");
  function tr(i, r) {
    Nt(i, JSON.stringify(r));
  }
  u(tr, "downloadJSON");
  function jt(i, r) {
    let o = URL.createObjectURL(r);
    ft(i, o), URL.revokeObjectURL(o);
  }
  u(jt, "downloadBlob");
  function kt(i) {
    return i.match(/^data:\w+\/\w+;base64,.+/);
  }
  u(kt, "isDataURL");
  var nr = (() => {
    let i = 0;
    return () => i++;
  })();
  var $e = class {
    dts = [];
    timer = 0;
    fps = 0;
    tick(r) {
      this.dts.push(r), this.timer += r, this.timer >= 1 && (this.timer = 0, this.fps = Math.round(1 / (this.dts.reduce((o, c2) => o + c2) / this.dts.length)), this.dts = []);
    }
  };
  u($e, "FPSCounter");
  var he = class {
    time;
    action;
    finished = false;
    paused = false;
    constructor(r, o) {
      this.time = r, this.action = o;
    }
    tick(r) {
      return this.finished || this.paused ? false : (this.time -= r, this.time <= 0 ? (this.action(), this.finished = true, this.time = 0, true) : false);
    }
    reset(r) {
      this.time = r, this.finished = false;
    }
  };
  u(he, "Timer");
  var rr = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAhQAAAC0CAYAAADM+bUiAAAAAXNSR0IArs4c6QAAHTdJREFUeJztndnW5CiuhSN6nfd/5TgXne5yuhg0D3h/V92VNpJAgJAI/58PeB2/P2TrAQAA4By+2QqAWJ6BxPf7hQ8AAABQ859sBQD4fJA1AQCA7vxftgIUro0m+jSdJbcjo2CA2m/3d3+/30/S35RgBOMIAOhGp6xyWcUuvDtzFjREDeIuaNEGNbuN1sIujQxNIEKRrWmbI7/yJAcA6FitM957Q7ZMjqzyi6DWQE7b93YjAoqdDK0OUZutJjugsVFSIrEcx8yTQ1Sg7dU+AB3grDFe+1K2LI483KE4FMlmG/VO9rvdGdlu2R/e7QMQheZuFvc9izkSNc+4/UJ9FgFFEp6OE7VRj06xFxLZ2qj7O0DTXkUyN/ZTgwpcCD6T592sKJlRAYwUT/0QUBRhV+6waF9ySdILD/ss26tIVE2Ve+elMxmbDvDHayyphxVL+Z5l2pk8aon6CQKKJmicavWu1HGseUNAoGE2Hl6ZGM2iAkA1LO6fPduwnnve7e8OJE95kvmPgAKYOe7laLsNBxuSDRFBWHSgh/ID0OLhP7tD2ejfJXpEl2t3srh6vDqgWEVjlEiNym/A7pnZv2v02GFhs3QSSWRlY+kjKyinJU+sFssdKD8ADyyyEyew2uM4761o8WErTyyjsxHWzvn7yT78RIXT9vf7/VJrctf/jpysEbK6BkMAnEhmMEBdDzPxXq9enaEAsUSetLNP9VZUsSMqS7EDJRHAwWKudFw3skBA4Yy1M1Zz7p0+3hmgC6TLzwdjDFZU9ImKOnny+pJHBKuUP+XkZ3GHI6JMstLbemKN0ou7W8yW8rPItMMypXu1Q7XnbQsz0HPKnO8EAopieC2c1e4TWKUiuXc4QD6jTMNsjGbjyxlTju9byAPxWAe6Ujrco/AEAUVxJAtZNafOviiVJRvQmf2yafSsVzCxa6eDL3Ht7WCTBCu7Tu0fDhyfwh2KQCI31u8fds+tfqrqhdUk3ZU4nnJwoa8GmvHHAj9H4tsnzIcTbDgFBBSJRCyO3NOcx89cLdu72ty1u7pfgQUoH2nmLeIdz3aAPxgrO7i/MkPJ4wVwL0d6pnctLphynsXiUpfZZd7Zc1o5I6wvQGciKXV2tvfzweHAE0nfIqBwgrpxU5+JnvgWm3FUtmMVMGHBqc9uI0RgSOft/fR2+62Q3l9CycMBrzS/dZufT+xfltRMdqqDY0Hph1XwDd5FhE+80e80l6ERUACXv1gZMRFnOu9sQdBRB24J640LPKBRYV539s/V/KL2bbuAooLT7PDQUXK5MqueurvI85tgqWsHP5GQuWBFlbCi9YhG6vPgHyIzthpZXdahlY0cG8rfobjXV7sMzuezvwg5+knj7hkKszsEmX1HvRQaoWsnHzoZyiK9urTZ9V7FaH52tKMa6EMZu3nI7dcWGQqPlHwmFFs8ShAz57E8MVECBk0bWj26nQqtT0xSrAJeSVunzP1TfHKHdwbGu7+kc67bOO6yEpJ51yKgAHS4TmCV6vJsg8tuYneb+CMibchYwEfP3J87Jcg4jVmG1JMoX+Aelir7qNe6X77k8fmc9VvxCO5lIk0b3He4MqmlEA/ZnVLNs/GMsGHWrxq5mjJmlzF7I6sMjOf9LA9Wc+7+TIQu1njM6YvyAUX3+mlWqmxVf6a+a6WDBxy7MjdkK3YLnEeJbKWLtv0q/R55R8si0Ad/433fSlrCtSwHUp+jyLQoSa9kouQRTPT9ie8N6rMSORJnvN7xXGQve2Z2dVrgV2NjaYd3MFENjd9LZEXIOZGMuRo5XtFZWgueMhFQvIjR5OAEHFpZI6iTQJIaf75zwmKeaUPECT5KVhadAtjqVA0CT/VdCggonMEiyWfWTxZZlhOCjAydIxfvjmNCwbN2XQHNvOW2H91n1IOXRi+tTdHZ71F7LRz5DZcyo+q4Hn3JaXMXfJw4tp5436HAeNjR7ZcAAHCBM78Mr+CMuwFhcQVv5IRfCQAAwP/4/SFbDwAAAAAAAAAAAAAAAAAAAAAAKAbKqe8Gl4IKgItaALyDkz8a9oZf44E1Zl8P7Oo82mhaa7fnrx0sTgoaXSJ/IkqxtauPgt5wPxPvqYsn3r8g49C5Hztj/qeRLb9rMGvL6jfyVqk5603X49sQGrj6SGVL7MZiAyrzJv/0WMsq7Ec7PaLWa69vzXBZfjjQSghV4I5dlGsZBWcHFNWzExccnSIXAI2sros26EOmf0ZvUF5fAc3ej7g6RByKKhw4Zzr869PbFZTthOWkrNoWFYtxp7ahlfUmHwXx7E60d7jva2Q/n7sjlWehiycRfXl/3tvmCn06Y/jnyy1Oib9fnz8NfRGpb4RTWETLFn3CXTR3viM5DY3e6eijQIdVuVTCTOb3O//T9FQ9rYL56vNhp5/lfqQNRDz7MnOsVnKHAYWk8cpR04hMfT1LHRqsI/mdTZa+Q5FlPeYewVdluSs9Kvjvjru+0QuydC5Q9LT0a4+NN7KvrdYUyqHFaw8Z9ZX3gciqHbO/NopSCY1ONmrGlPOu1neo73vXjCPGNkvuU95o44vUwQJPne++5n1S3elBKbFw2uyAR58/21z1qbV8bpY3C3WGwpNKJ4hTZVeg2qTQ4Hkaq9BPFXSwxLMEImnTKpO2kv38N+sxHdnQoZyygpph8taheunWLKA4baGJooojWJc7It4FcVBOwlG6SFlt1pUWZQ2clPz1rCYAWJUGus7tynprSmMRmJQ8LAag8iBa0clGz3LH74a1bGDPym+pafQqrHTtND8/n7W+FFvuz1SrxWuxHMsqNt0Z6VTBf1UZit1Co2k7ehAzNrcqjppV+x9RpU/Af/Ga41qfswh4q6ePuazsmrGyd9cX3DGM6ltkTPMQBRQnpD+pPG2V2jZbvCjvRvenVt594eBM0E5+M0vpegegkTK9gmyrjKbFoaVaUEHtm1XpxlYjOZFljzftSRcV76psAwquQ0iMqTQJdly6Rg5atpPsmDk25317rf7Gw8cyxuTZ192CiWpUCio0PrrS9flvq7H10uEuOzqz5Vm+BX+zDCg6bfRctJOHMzGqnMhm7Vq3ScXKnl3a1kJGJbwXOe9gwuLkatkHq6DCWtYMrz6PDDgrzrXTAwKrLBClDUpfmv9s1GISRjmBZX0wgohTk7T9yPTmiIrj1ZGozES1hX7lv97zjtvn2nLH3da7jMjyRNT4V8/udoLSl8tfeUSnpirxfTB6xsrGp6yVTEssx0jS1u8P3PewQPjwljLHjIi5Tm3Xos93trxlXLvvRVwy7d1mKKh1MakCXQb76gdLfXd9G33qly4wWh0lp4hqafNTeWMfrUoglv1hFUxwnr/L3NnjGVxJ+1KaVUamQk9YySNqAp7CG/qEm0rNCirAfxn14xv8NIuMbNBuw9W07X3w5Orwpv2o0uHK7A6F1eJ+4oBXxGpyUzai5/+3rFVTn3/KhJ/tOXUB3uG98WUEb542VfQRHHJzML2UaRFUcN/HRmGDpN+kC6NH+WjFiVkMa79fLcAW7Xdh5SsWfRDpixpZUXe4POUggxmP2V8brQIcaE+VPsrapKzr4E+s2l7JpPw3LtL69CmsyhDeG59X2zu4Pls9SKkg880cF1B4cuqiajXpKk5ezzFblW6iZVrx1qAi406DdfsZ81grs7pPVdfv86mlo2lAITHMesJSLwdFnSZBHhhfGbug4rR+jQwm7m1atX/Xf9em5t+9s2AVGOl3mr97YnKHQtvhHCfT1o6f71PreNL7ArO2sm5FV5ocGbpUX9CqsLvnor1bEblmSPToVuK4rymUoMFyPdPifZfCAq2/e5CVVVshDigoC0Klzl+xcmivTW83iaI2W+v7BLv2ouzKXDBPumjmEVhY6K/dhCouxlRWF2ip+lvYKW0jyoelMlb6UfzdO/iodCh84raJRnWmRE6GfRX61GOTtXRu6+DGq+0MOTN5UXJXsrl6WPmMdXakQzBxh9qPFnZZrx3U9iTza9cvVL2j1uydjRw9Im0byTOvF0UvqBkp104yV/K9FhoJnsGEdfszeScHEzsd7kQEFZ2DibsO0QG9Zb9Z604JKLREHwSrBtheB0Hz71BYtueJJO2mtU+a6qvcr9r0pbVtGaWOzPGJlr0rgXDbqUBmQKYt3XDnn1TeU06l8aMitfvzKV5mKDQWqpJHliGWJ8IsW61OelK5GfbciSpBeMrKoNqiHl3y0ZKtr5d/eqTFI9itRxVKxXe8+jlj/fTo2zKOBYAV1TZdUIuoEtVK9h0E12tOy+quWNnawabyCgIAwEkg4AUAAAAAAAAAAAAAAAAAAAAAAAAAAOBcSl4IyvpJJZATfXM+86Y+AACAf1Pui3ZVvmfggbQvJTZ6fQmNIst7TLK/JQD0VPoYmieZh6Od7E79CHoQ8oecvD8/KvmAiGYySdqIDMw8vuq2kv+WgII77lJf0/po9exNxqeGJbK1/S8h44NFVf2kM9XnoBfkTUIlhHnCjZJjsSBxNxcppwUUmgmXEVBwZVr5iTbDV3FBi1xbLORGz73qgUz0+HUrp3aag9aHlv/oVVuj6czvgNXzHhupFdp+iJIV0d59nCqPWQWy+udHJEO3p56Wz1m/GyVPq2NEP0ra064VXD+NXJs85hClTYs+nb1P/uNgkXW+lazr3yosZlxGdnlFs5oTh2dE3XHcRvx+8z+y1N1G6QIs9RvvLJ/FeKzGm0KWr3Dkam2sxnPjy8hkUp6z0k3aJvfZ1b+7Zyi4UA0bPXfSZDgRbvB4El1OyJX1nGUpV3Jn/zbKfu6yoBL7dm1KbKI8S5FLbd/ivaj2rNH6dEX7LHV6tmX658ujqThYYEznYKJCxiHihFXhJG/JKphYvbfKglaybwb3UHbZqTnM3YnMeFrz/fL+HPwpUPya0i+pGYo3Dtwb6RxMrJhtOBm6aMk+yXPQ+A7n3UgfzZwPu/EENDKze9z3LTJ9ozbKlTzAWZwaTGTgtVFrTvJVx9LK77TlCNAf6Xh7lJwsZHN14MylUgFF1cUJyEAwYY/1ZiYNJnbPVtt03+R31fq+GxJf8ezz3x+82n/K2j2z6p9SAQU4h7cEE8+b1dRnqWT0WfVxit4wI/rDI1BEYJGHlc9w1hcJFvcm7iCgAOa8JZjY4WWz50Yh1bnS+HbbSLXzZXef5Y5Ux7fzpr67bJX4JflXHpwOrbS4gHw6+0OFhWR087zDrw08OClYtfStqw84WbKu/RYB59ceVuP4nNOzS9/W4zZbX0bP7dpy+dlol8WuwmZxOh38gAN18kXIBTQq+aC2Rk15l7sRVuqfE6D2p9WctmjDSheUPIAbpy5UljeoNbwtwOiYneCWHCzs4f765m1+JCWyn1aydnp4zAlqmy4ZCmuDulxmA3/TJVMViaZP3lb6eNtG55HKvv43pRRyqh9JoZzaT/LRmb0cv0j/Wx47pAOGCVKDt4+DdanixNKH1J4T/CrKhqec03woit16doJPamj96W0tksHHRORzYlCx2tijbT2xf3dE2ms95yuM1duyXVJW89xrL6C06zFWKzupssrfodCkh611ATRGfd8xEKuq8yn9K4F7P4AK9Y7DpYNWluZ9K7BG2mLRn7OSg/dYWZV2ygcUn8/87wmsnsvQswKchdGTEze9Sn7lpUvFMdLOa85iGWV/xX4GNKxLmBo9vPxIqleLgALQyFgYV5wYVNyZBbW79zJTpV5oZM8ODFmHA8t5tLKhSvAP1mSuY3fZlLkgmS9UWyjPlQooOIOEibinQh+dHlRQ8NoULdq1GJ9q42ll0yz9bKWTVDdQj0rZSw4rH5fMo9SAousgnETEYnZyUME9QXjKz6DKxVQNUbrushXSdn83uO9JZWbRUWdLvH312T5XXqkMxedDv+EaoUs3uBt3ZD+eHlR02kCfzMZmtkntNrAKfbGyifq85Bmpbp+PbD4836Gun13mnnTdsLbvxMOCtI9W75ULKHZ0mQiV+E0YPevpxJ2Ciqp6jYhYeKin4ArBxAX37kKk7p73Kmbv79quNHY7qhyUPh99v2XfE9rpwdEv/TsU32/O30Y4lVF/ct611mckYzTeGtkR9lr3jdbmJ5pxt3j/akPzvgcru7j2Xs9bZipWulGzJqM2uLZVHLsLCxsr2zdipa92rloE0zP/bJeh6Ao1S0B9boVk8mSfzjKCyEiZHRY0aemmesnHIxi0amulG1VOxxMyF42OnqWqSn0n1UVa7hv5Z4mAotKgeGCxAHkGFVXqg8hM6S55Wi6clCCheiBxp7KeFrqdGAg+qX5Q0sCd91K7tFnM3TPTksc9rRIxKJcMisGcZ9/Mqp8qTDRp6k6b8ru3Q5ER3Vfa05il3hX8xArJGkN9/v6epP8t1jTqvOg8ptIxtJTvtS5UOdhxeJY+yjoWZRN8PkPpHAtnkLRxYn36jqZfszbuDN5k64qO/RClc8e+eXKCDR3Q7EVWWY6jxlhyxwAAAAAAMrDvAgAAAAAAAAAAAAAAAAAAAADAe0CNGAA+59zOBAAAA46+xQ6AI399h8Lypz73SYkJCUBt8DM/UB34aH2mH2+x+E4Dtb2oT9lq5Xd15NPtAzpwIv8b9Ec9MCY9mH56W7rJc9+zrlN6ytfomlWTjbJv1y7q0QAAoOd3I1uXJ8u/Nvr8rOaOmYFvjybv/cLt0848/eFNtgNQDazPNmSW86uvqf/LUFh803v033ftdvoeulXbkZFllrPNbKwYVUuoekIA4MnOV+HHdEYbepYuVliuZX9lKEZ/XIYSAWkjX6t7D1X/GBL1j/Z4EXV/hdpm98tVz4zT59PXFnA2J2x4wA/r7Pm/7lCMGpQ4pecC6xVMRHLiROdGuif1wUm2gDOg+mS3tfPNPMeq2tgN71BwMhXRm3vXYCI7S+ENJUs1eqZaDVDDSbaA3qzWGi8f3a1vJ8yN5zqeYVPlfpxeyqQEFV039yqcsgFRS16zoKpbP5weHAIfsjfc6IPe6plO8/1JZ901UMq7y195zBrNWlC7BzBv2ohm43L9d8ldnUrM7PAg47QJbOCWAL3GMzuYGL0D3+0D9a7FMqBYnShnz3MVpdI9mJhxwsS6+wnnIu4JwZXEdg6nX3C9yD69e/CGjfaEOdyRyHnPGeNthoK68FeLgKtyykb6RDL+3ptxFFk16eezUQGNpRyqjd3S5Zo53iWooB4svda77H0pC2q2wFoWBVLJY7cJ4mKKji4LiAdvtXtH5uk2Kisi3Wgs7MwK6kd6n3Cv6GKks0d5kBOIWvdjt+BWiqQSMf30NqcRT04sdXTXH/iymsgX0TqN+P1B+q61PlS53rJna9buXlF3dnZEZS48eerc0QYK0msNrEuZo0xFpXRLZ7qeSEAMT9+Ynfoy/MhSJmXTkcqqlJUYPeMZnEk3iBPA2spD4yvsX3lkc4pjnHqXAuiompGzTFtzbLSyPepOQ/Sc1srrvtnOdK8QaJ8Ete/IJY9oqi6sniDAAE+4aWRr2c9UPXUBr8Tu/leFMlLl/gPvQbvvtslQZE94D5ClAFVZzTfr9HzG3B7JtMzC3PGc49o1pPO66uWjQE7JgOLNjoDUHMjGu+afDSXrk20bZw0YPRt51+0ucyUnu08BH67flC153Dl5gz3ZNgB2wP//Tec+Gf2KxuOXNZ37qBPccSsXUCCKRR8A8FY6bZS7bETET3SBP5wxLFXyqFJfjaZCihUAYM/p65dm7Tq9bzoyG09qKb5chgL8FwQYoDJW/gk/7w8Cg7PQ/JKrTEDx1uzExZtsBeAONahAGr0uFX56+waifF8aVJQoecyUfHsqDb/4AJKb895+own+pSny7A8VSeVx3rvb2HXed/xOSSW4PuDpJ5LyR4mAwhrNYjNz/IgJ7nmXAhO6LzN/jvCVu1yruTHy8+v/P9vysHG1PnjJ+3x4my0OE+8jO2gewQ0qjgwoPMgaXAu5pwYTJ2awVhOY085uE+O2EwVVXlW7VoeC0+ahJqNSeQ5WooLPcIKKEncorJ2rs7N21j0SzUSrMElXWPqAt61SXTU2Vt+8LORVXwdGp+m3BFJeVB5zanZNVBOkCOoExeGj7bQ6YT7bW9FpLLWLVAdbOTauTsYUWyX9GembFjKjfSYzg+a9TmfMP8maGLGOZvWttU2Suz7P91T3DDosyuBcTix5POEGglYbidV9Ca08a7ncxTqydOS1MWWN2YpOc/CJptQjkTEiu/9mvtV2UAEAAOSSmdkC9cDAAgAAUHFaSRUAAAAAAAAAAAAAdAUpKAAAAG2J+OVFJJ3taaEkAAAA8GR1d6PLJnynuz0lPmwFAAAAcMj6YNbqI17ecqNlcikf8QAAAAB3sr7TEPFhx+rfoFjB/lse+KgVAACAapyyJ60+VFcdVsnjblw3QwEAAJzJKcHEk2524Q4FAE3Iqt0CAAAF/PnyFxD9x2Y4crtF4Fk8s4PoNwBANZChOBzOidbqBMxpByduAAA4A2QoDka6WWtOwG8JEKL+5DYAAHQBAQUYIgkq3hBMSGzsUqKQ/IKL+w5+JWaPpk81Yy4FY38uCChexGwizxYIq43w2YZVWWUlw4OTAybJHQ3uO9H3QCib5V0njs1VNkVNn2rHXEqXABvwKRVQZH52NPpjIpU+XnLJ0iwWo3ejPi5z/TeOHZHZFyyedlA3dMpm+RzT3UYnDaA8Mz6j96MCgyw6626BdUBmuXanBxScy3sWnTiasBQdrOVTn4sOLKwma8YmytHdK/sC/IjOcMxkc5/3yvhI0QbHb9/QT2E1jlL/Sw0oJI6pOdmPJix3E9rJoLzPfQeb1t9UWNSyF/vZc6f6ivV4R/sPJ/vBYTQXJGsG53ltBsR6/TzV5y9mY3z9m6RN7SH6/v79mVY/G6V2gmV7Vu9pFrDszbMi3z9o3rfUxwKLce7kKxV1HekkSQlTSiya9rNkUVht/JGHsTfgvRf9/rB6//7/0zIUlAg2w4meDu+5yFOiv/t/q7gJVsW7xgjisN4Eo8aTkj3w3OAjZa1keMjxbrcaVllZ6b5LlV0uQ3F3kOjU2OjftSdhjizKv3lyysbZdZHpqjcVK/uy+8kqe2C5we/ey5zbFuPFOXydiGeg9tzjNOWy9EuZUnaRt6Y9byiyrCJSKqdMzKhxfPaX92bpJa861n7Jbc9qbdmlja/nIuRYyXvinQGJXhOr4xmoUfv6+X6pDAW1g57PZSyuJzj278bo3zuklSOg9MNvQIRu3Vn1U0SKfpVBoD4vlWPRrrSdbsGEZ5sdsfBDjU/OMvdtMxTRnBAdc/S3mLgn3fuQjP/1/Cl9YAG1HyPvTcx0sp7vMzkeQdJJmQlgi7Zkt6JUhiKCUQfB+f9G0h+rVP0pJ3epn3S2OQKP/ql4Op7ZGWk/ggngyesCCjBnlsbivG+pT0W+D6jvIaj4h12/VUifR9/diJAXEUyAd4OSR1EiJ6vlQnNCaYjDKjMTrUskHhtgVElA0qZ1uWVkq1WJMDNr8IZDBZiDDEVBvBaE5+lam5FYybFusxvd+4B7WdJbpjer8fIIJmbtavsgqg9R6gAjkKFIYHYSOelUG5lOBnHsAg3qpkLNZHUOeCmbrmWmYtafKHWAKFQBxUm3+KOJ/sUFOAvruTfb2Kzap8p8/runfE84J3iLoCIqmJiROVan70OdAjh1hiJ6MDs6juZeQUd7T4SzQXjd2uds+BF+43kPwKoN7VhY9eOuHY2ukcGE9pcqVca1M5X3BNYdisgFdCSzckfukOje2d6TWC2iI6L1GyHRI8NHR+97+r3XXYlVW5wykJUuVdcOz/s31eaglM62pF3KHNUSV89WnSAcOAvLCfaCf6hyareQ8fRP7UboeWjgtm29qXPb4L7DyZy9iW4b8UVXvS9MPtRTxYEvvSj6cJ61eC+D6uN0odErykbNRI9MPXvKBPXICCiqzIWMOeC93nSf16WVAzqqBhSfj21gFh3kRdaLAdhx98e3+Vzk/ZGnzOjDy9vGFhSkYx0OAAAAAAAAAMAL+X/JDsqsuDEYXwAAAABJRU5ErkJggg==";
  var ir = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD0AAAA1CAYAAADyMeOEAAAAAXNSR0IArs4c6QAAAoVJREFUaIHdm7txwkAQhheGAqACiCHzOKQDQrqgILpwSAeEDBnEUAF0gCMxZ7G72qce/mec2Lpf9+3unaS78wgSNZ8uX5729+d1FNWXUuGmXlBOUUEIMckEpeQJgBu6C+BSFngztBR2vd+ovY+7g+p6LbgaWgJrAeUkDYIUXgXdBBwNi6kpABJwMTQH3AZsXRR8GHTfgEth8E3gjdAUcNewpbTgY85sCMCUuOokozE0YM0YRzM9NGAAXd8+omAF5h4lnmBRvpSnZHyLoLEbaN+aKB9KWv/KWw0tAbbANnlG+UvB2dm77NxxdwgBpjrF/d7rW9cbmpvio2A5z8iAYpVU8pGZlo6/2+MSco2lHfd3rv9jAP038e1xef9o2mjvYb2OqpqKE81028/jeietlSEVO5FRWsxWsJit1G3aFpW8iWe5RwpiCZAk25QvV6nz6fIlynRGuTd5WqpJ4guAlDfVKBK87hXljflgv1ON6fV+4+5gVlA17SfeG0heKqQd4l4jI/wrmaA9N9R4ar+wpHJDZyrrfcH0nB66PqAzPi76pn+faSyJk/vzOorYhGurQrzj/P68jtBMawHaHBIR9xoD5O34dy0qQOSYHvqExq2TpT2nf76+w7y251OYF0CRaU+J920TwLUa6inx6OxE6g80lu2ux7Y2eJLF/rCXE6zEPdnenk9o+4ih9AEdnW2q81HXl5LuU6OTl2fXUhqganbXAGq3g6jJOWV/OnoesO6YqqEB/GdNsjf7uHtwj2DzmRNpp7iOZfm6D9oAxB6Yi1gC4oIYeo4MIPdopEQRB+cAko5J1tW386HpB2Kz1eop4Epdwls/kgZ1sh8gZsEjdcWkr//D8Qu3Z3l5Nl1NtAAAAABJRU5ErkJggg==";
  var bs = {};
  ls(bs, { default: () => _t });
  var _t = hs("SUQzBAAAAAAAI1RTU0UAAAAPAAADTGF2ZjU4Ljc2LjEwMAAAAAAAAAAAAAAA//tQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAASW5mbwAAAA8AAAASAAAeMwAUFBQUFCIiIiIiIjAwMDAwPj4+Pj4+TExMTExZWVlZWVlnZ2dnZ3V1dXV1dYODg4ODkZGRkZGRn5+fn5+frKysrKy6urq6urrIyMjIyNbW1tbW1uTk5OTk8vLy8vLy//////8AAAAATGF2YzU4LjEzAAAAAAAAAAAAAAAAJAQKAAAAAAAAHjOZTf9/AAAAAAAAAAAAAAAAAAAAAP/7kGQAAANUMEoFPeACNQV40KEYABEY41g5vAAA9RjpZxRwAImU+W8eshaFpAQgALAAYALATx/nYDYCMJ0HITQYYA7AH4c7MoGsnCMU5pnW+OQnBcDrQ9Xx7w37/D+PimYavV8elKUpT5fqx5VjV6vZ38eJR48eRKa9KUp7v396UgPHkQwMAAAAAA//8MAOp39CECAAhlIEEIIECBAgTT1oj///tEQYT0wgEIYxgDC09aIiE7u7u7uIiIz+LtoIQGE/+XAGYLjpTAIOGYYy0ZACgDgSNFxC7YYiINocwERjAEDhIy0mRoGwAE7lOTBsGhj1qrXNCU9GrgwSPr80jj0dIpT9DRUNHKJbRxiWSiifVHuD2b0EbjLkOUzSXztP3uE1JpHzV6NPq+f3P5T0/f/lNH7lWTavQ5Xz1yLVe653///qf93B7f/vMdaKJAAJAMAIwIMAHMpzDkoYwD8CR717zVb8/p54P3MikXGCEWhQOEAOAdP6v8b8oNL/EzdnROC8Zo+z+71O8VVAGIKFEglKbidkoLam0mAFiwo0ZoVExf/7kmQLgAQyZFxvPWAENcVKXeK0ABAk2WFMaSNIzBMptBYfArbkZgpWjEQpcmjxQoG2qREWQcvpzuuIm29THt3ElhDNlrXV///XTGbm7Kbx0ymcRX///x7GVvquf5vk/dPs0Wi5Td1vggDxqbNII4bAPTU3Ix5h9FJTe7zv1LHG/uPsPrvth0ejchVzVT3giirs6sQAACgQAAIAdaXbRAYra/2t0//3HwqLKIlBOJhOg4BzAOkt+MOL6H8nlNvKyi3rOnqP//zf6AATwBAKIcHKixxwjl1TjDVIrvTqdmKQOFQBUBDwZ1EhHlDEGEVyGQWBAHrcJgRSXYbkvHK/8/6rbYjs4Qj0C8mRy2hwRv/82opGT55fROgRoBTjanaiQiMRHUu1/P3V9yGFffaVv78U1/6l/kpo0cz73vuSv/9GeaqDVRA5bWdHRKQKIEAAAAoIktKeEmdQFKN5sguv/ZSC0oxCAR7CzcJgEsd8cA0M/x0tzv15E7//5L5KCqoIAAmBFIKM1UxYtMMFjLKESTE8lhaelUyCBYeA2IN4rK1iDt//+5JkEgAkZzlVq29D8DJDWo0YLLARwPFZrL0PyLsUazTAlpI+hKSx01VSOfbjXg0iW9/jVPDleLJ15QQA4Okdc5ByMDFIeuCCE5CvevwBGH8YibiX9FtaIIgUikF42wrZw6ZJ6WlHrA+Ki5++NNMeYH1lEkwwJAIJB4ugVFguXFc20Vd/FLlvq1GSiSwAFABABABA47k6BFeNvxEQZO9v3L1IE4iEVElfrXmEmlyWIyGslFA55gH/sW7////o9AAFIBIIAAIUMzYTTNkgsAmYObfwQyzplrOmYvq0BKCKNN+nUTbvD7cJzvHxrEWG5QqvP8U1vFx6CwE8NoRc2ADBeEb/HoXh60N7ST8nw9QiiGoYvf/r6GtC9+vLwXHjaSkIp3iupC5+Nii81Zhu85pNYbFvrf+UFThDOYYY26off+W6b//73GTiN9xDfl0AAwBAiMBO8qsDBPOZtuT/dTbjVVbY/KSGH6ppHwKv/6X+s8gUCN/lODzv////GQAGAMQAADlXAUCBJiY0wFQZusYQOaQzaTwDBTcx0IvVp8m7uxKp//uSZBMCBHRI1eNPLHAyxNqWGeoYUIEnWYyxD8DUFSn0l6iojcd+oEOkzV6uWqyHNzjqmv+7V5xGUfY9yEmbziTzjRscm9OqFQp1PKFrqu3PX/7YuGtDU6bt0OUTpv38rdc+37dVDQLKUchaJ853E9edNDGqWwsYz1VoiSStEJtZvw6+sNqFWqaIXJjQCGAAGWAYVwmag/x3BRJw1wYF7IzVqDcNzn85d//FzK7IgwbQwccLoB4AsF8Nj/1ESRUAAVJwAFh0YOFEhmSJEHKQRDyhszgLUpHIgFrb5cySFg5jv10ImlYuvaaGBItfXqnNPmic+XNkmb5fW49vdhq97nQMQyGIlM2v8oQSrxKSxE4F1WqrduqvuJCRof1R7Gsre9KszUVF1/t3PzH2tnp+iSUG3rDwGNcDzxCGA8atuQF0paZAAkAhAQAEAC240yJV+nJgUrqq8axAYtVpYjZyFGb13/17jwiClQDaCdytZpyHHf1R/EG/+lUAgAAAChhmJvioVGGBCFgqdpsGAkUUrbTstwTCJgLQpFIsELW7t/68Iv/7kmQUgAQ9NFO9aeAAPAU6RKwUABClY2e5hoARGpDvPydCAsY8WO10fSvUOnfT98+n/l/6/+hxslhQ1DEOaevNKGocvIYba8WJpaP/15pX0NQ1DUNn/////k6lPp/N61rBi8RJFfERV3IgrqDsJA64sjCoKxDDQ9xEcWDpMBDwVFDIAEIAAzryxsjGi4q/oWpixKjhklAF4pUrDPjFhFVupDFZ/t/t0YPAygUBhADPR/KLCKJ8h2Oxhpxz/zNRAAFl0MAZLAYEAiVbEiz36LSgZ5QoQVat69KNy8FyM5Z80ACHAzgnISEkxUSJIDyBSwi5KF4mjBl4xJdbrG9ComLrL8YATiodhQKCkj6ROdyg1y5XmZlvMVmpJzYppJDwLi/Lp9vT3TfmimOGpuezi2U/9FNav0zX9Oja2r//8+hvuihuQAAMAVmqFgAgCcuboAEAAAUcqy8ca0BHBmwbFkED0CNA1YYDPkhcQrRJxcY3BzfxxltAz9vX62Xl3plAzWmRO+FkZyH///1qAAEjQBAACUpgU5o2AIBmFBGMamrGg0b/+5JkC4ADxyLWb2ngAEEkGofsoACP7U1JLaxTkOqFaKhspGgnW3SGC56ZgUJGCRnLOmIJAkuNBgvwU4Ocf8CJK9UsafH9/Frj///365XSoME+DZMw5UNjrMbVoeIj9EL91IuQ5KHyl5V2LCpdIdESgafOHxVGkAlkHuakmix/gN8+BP/sKguLAAoAtUjtvaoeEADwr3OK11E4KBlojgeQNQBJ4MvCAd/4t/xMMzeLhQGQ1//6tQu5BaBOGCT6U4aafvXZ//4iAPAAAAbLkgIlQmMSLA2H1CVNAlWwyVvKIQIxOSK1NWxs4MBUATlKrAkIMPAjCAdS6MVFzuURWa/+/qQWEGsA6EEpiBEJb9Q21lAHoBoD0B6aAPhyt+bG3muoXIN3RLadXxUfr/ohjGFF/p97eqNI5noKAqYLNPpUTDSI9/TmA6B+YAAADgA0Y4lxTW1SQfOQuDDDI0KTTuIrF5qoJrUFhUFAsg+AT2hbkaRZYGIjBKVDIa5VgNN/9P/rCDsBJbYJRKpCA1ArAkigIeYY61AjE+jubyiZFZ3+L789//uSZBCABHVj2entNmw1JXokLycYEFTFVa0wz4DYjKs08J2Q+r4n3lgbWaaMwMLEjFW88F39brqPF83cv1mCSJeY3Q2uiQxhBJxCBeR1D2LQRsYQcZUTzdNll8+OwZBsIwSgl45ymaHX603Mz7JmZuvt71GDTN66zev/+cLn/b5imV8pAHkg61FIJchBSG+zycgAZgADD6F1iQQRXRWmWS6bDIIgyBCZEcdl/KgXGmVKFv/vl8ry/5bLypf//U5jhYDhL9X/pAA0AKBIAAKgGtGXGGWJgEoF2JNsHlKfSKLRhGBAgIuWZKIJCFpF1VBhkB+EfzEyMUJdWuMrEZoPZ5BfF3/Nu62riIdjoO4AAKD2sTrDmpZZaYysf/810TitAVvn9xtFucieiaEy54YqiIO6RqkGAm5wVO0bFB0sDTdNxYGekKktR4KAAfAwUIgI8Ci6aXgtwbhPWAC+CKExAFydNtYGXNZoQjUsXv/9vKjgmdwieb+h7kHvPoc//0FaCACAATKFC4Y9ammklidbaiJNPBhGWTNhFSgdtalK12lpl//7kmQRAFN2NFI7TBvwNKNaTRsFGBWdfV2tPNcYvBHpgPKJsc8IUcTCxY3HSvUVNTWe/Z3YWlrJ0yrNRUiT19aprA7E+mPP+ZmC3/CsheOJXhc/9VJb3UZnphUBcqZUZQth1i3XqtPYu2Sy1s8DV9ZYACAAASAAHgFkQcOqgB5utFHFh3kSi4USs0yk4iOClREmjvdG+upaiLcRA6/9QGbOfxF/8sEAQAVG0G07YFMihKR4EXJCkRdX9isueLqUMRAQdhDZmv3KeR0nPqRVrZmSIXDt+BBSR7qqbKQcB98W9qiMb55preHIStxFWPE4lAyI+BKz2iSxonpvMR5DgKxTH6vGGXAbYCaAnJUW4W07EesQqbfqdbo4qNnPxSpn1H8eahszc/y9//dn1V7D/OYpn1szQKAPXTMlO/rO//u7JriJXbld7aP33v6RXYg/COIDzTWkTspg6Ay1YaDSwKxrP/LfIikHjmO871POf/kEAseAgoPEi9/0ZziNwfxVKy9qAEGEEAAq1EcOamDEGHAA0iao8k31rz2MiLNEik6VQ37/+5JkEAgEYU5WU0M3MDjDe0o9IjiOzSVM7aCzEM2GqXD8pFB0zxMcHCQNHtZD+R+pMWZxOJ/otEZTvVN/MeU12xTVcL+f2YaiNJTVoPd6SvzEnKel5GXOzEaazgdChnP2jOAwpfyRpVlQwoJBwpN1L1DL////6TVWcoepf7CVWrpEWiym5lR5U0BSMlxQC4qByOyQIAEuJfIriWixDqRgMfVZWuvRowjR9BzP5lZlT/+YG50CsSBG////////liXDQVMxEaBkbzKAAACnDIAstY7iK7gGSF7SIDexaTtPOHABk9YcmJEACmo50pgWal22etroBpYoVqtU6OPqvlf0c4QCAfLk9P/FJs4KCQMf6ECZyA6BwqqyJ0rMYj56k1/UlTIx1V3Rt5NF71D4qlptDC8VMgQVHFDlQnDFi06qQgKQAAIK4TxxJGFGYJuZNGXRdpq7IW/DYpPIQRFJLAc+qn1E0XYdOkQVJT+z8Lvff//8vbKAWTIBBUUdM6cOhlDry7x4dAkJXIBhbO3HSMMMGBQ9K9/JNfu09PjTO64wYEcR//uSZBeABP5g11NPRVwzQ4r8PMJVj7j9UU2wUwDPjeq0Z5w675D9+uDdL2QsuIry2lZtwn/pJYyRRjANEOQxNWw8mU7Tq+vueV7JrX/Pg7VIkEuZT5dwd85MVoq5lpStNICkBAcFR88//58KO8Zjt2PIGxWl1cVfXeNGH18SReNT//hYliWtQuNluxyxONbm4U+lpkAgpyE7yAIYUjIaqHmARJ0GQTtmH60xdwFp/u253XBCxD0f/lBcguCALn//Y5nqEv//1h4BAAwgAA5gcHmpIplgeW9fAOM6RFZUywrsGAiRmKkanQnCFBjYoPDS7bjwtPTkVI8D/P8VVLcTUz65n7PW2s3tNYHgEul4tBaIz0A9RgJAyAMI4/i0fpQKjhX9S+qIa0vmc4CZit/0/3UTDGeKNpkk0nu2rUE2ag8WErhE/kgAiQCJKQEYBA5Wn6CxHoIUh6dQ46nLIuwFk4S/LaDQxXu7Yf/pf//lwJB0S/Ff/4C///EiBEiAAAIAMnpngiIABAdMpKigkXaUwhLEGvpiofmXW57h2XAZO3CMRv/7kmQUAEOHQlHraRTQMkQp6GWFZBTVU1lNPTPYyIyocYeUoNgLBWAs1jPkTv/tXBaeZ/tbD/nAGP8/xT0SNEi5zof0KIVEzVe9r5lZOol7kyaXMYS4J/ZS3djp//UaeVyR0mUMlTgfz8XqMzIEgAQQ6UNQ1DSE0/C16OvyaocF4ijAGFci0FSYqCUSaWs6t9F6/699DKvMgMoK1//kSbvxtyBN27I7mdXgNMAW75sRU1UwUHYG5axI2tFIFpkgx7nnK+1JmRKjqeAd5Ph0QAL4QAnirmiPlg0yBDlrb/d3ngtA65rb999+8vdDCfnJuJAYIl285zklpVbrKpk1PEzrOY9NZUgyz6OiOsKt5qG/g2ibxSZ+/eTI/NB8n4ev//n2nIw85GAdwuJL7kYnnAbpcf1RBKH6b2U4RWP8dmWH5snsAFYwADBgAopKdzFJq4Jlmotloh/m4QpTSvJRE3nYZHephoqBhVf+P7vQ9BPlwZCP+3//+hdy5uUwS3LDEgQx4cdIgvDEBR1YqymCsSbKzRy2aQmSv+AAcAgAkvzPfuX/+5JkFQAj6VFX00Zr5DllOhhgpn4MmSs+zSRRiO8U5tWklYgSLKfs+Xheb/+6WaAQCKTztNeJ382MUltZNnjSJoFrCqB6C4mFcwJpJD4Oc8dLDXMTh9k1/rmTopfzqv9AvHWfOuZJlEvHSVMjyjpkVucKSzxJVQBgAAIo8DGqRdYCXPckFYg+dH9A/qUyljrtpxH9RJX/Z3Vv6uFkPg4M2jf3CL09QrwOrMt69n//8UFEAAMHWdhg1CcjyVBwiArOYlDL5NPY6x8ZLFBCGi6SVTKX5nqdSEFjebnv2zHdt0dj6xvORsSFzwqRNTJSZIrrlpXcURNL9WW7krBgr5jPMaGcvJ5v0N1s19CV7+7fvQfjySX2QECWUgKgeJCIif4WRBZ/6archpDkzE7oWctK3zEHP9Smeai8oeHkM6AK7pGjtOgeFv40ugqNd+Iv///uAZAMgAAAUeSWhLPpdwk3iXpBw43hOVIp1gliUOSaeZcZeZhLAH9TtD56wUpBduzLF5v5qViTH6o+I0+8Z1asaLgKVAohlpB72DgAQBQxEd3g//uSZCiAA6k0UdMPQfA+xcnBYON8E3WDVU0w1ZjPDSmo8IniHAFDNnkXF3B94gicH5d8MFw+IHZwufxOf/8gsHw+XrD4Jn8T4RAyQiABNBQg/3giEWuZ42mVFB3kkXNjhqBg1CghEUbN3/7/KBhyqNueef/MIDBClP3YRnKLiIlEFzf//0g+4zKpRIKTpqQgUtnHGFw6RSLN421iGcYapqFxny/capK9r9v+2BSy/RU1yZxa2eGaWK07ijfcxeiO3iuHJvjbXzts+Ny+XyFnsne1h0qG4mAaN6xRGaLVxKPlrri0Bg9oXGyxcw8JRBPkUzC8v451vVd9liSX85JMrmkVNwxOCwUg298////7ks//L409/hwMRIozKiIckXtjzDaAMTBcAACAwLGargPSEgEJZN/EFjfF/VKgaMYKMbwtf/T0UCGGfjfOAZ2frCigYdwh/+sGlQBxhCAAAUHkDPqOdmmUdAVYl3IhrEfR8qZFjLYEPOyzVGvm6lNUJCk2PNazwFxaijk+ZEaiTehoJGuDh6zN/EVP8BCLD/88BoY7Xv/7kmQlgBNmMtNTL0FwOGZJ/WHiKAyhJU+soE3A3JnmAa2oaCIru/+RrEHMTphxQ0X/LzoVy4gKhYl6ZUlklW7CLRVoYmgABwCRMAAMA/poCiEEYLsBVodWcVZ18+CcAfH165U4Xgh7/X1/BAQF6GN/BwQ/+D9S9P6wII//CoANYFYCBAKlGQDKhVjjylKARw2mPAtp8JjcQHggQswVsOEKsF6AIBWvmpIFdSZvRVv/LHWEy0+txMxu+VK9gEqG5pWf6GNGU4UBVkfd+bsj/6lZE0fkOpAqAOvyUO9oo+IiEtcLKOGzhhSGa4MYINHWoQsFr8zzmow0tRILkqz5/+vFxl/oZX/+qGW//xiLjR3xcGn//0QLkTQJh1UA8MAQAEXC/YxODKTDUEhrASs1512GRp+dRFFdTWIRaOXrve1eNjTNpreqQYrC9NBlQc1f8YO2po8bnH6qffuRvU7taiNF3baokE0YpmjRCHRclWBb9NCHKHpERwHRG3pqgXklq4sBpLjGvmekg8Y7SjM1FZopIM8IhB6dtMr8aKsdovh4FW//+5JkQ4CjTDdSU0gtIDiE+YBrKgwNbSVJTCBPwN8N5ZW8NKDnhRB8AXCm//KAsBUCwKU//oJQnET+UP3/zpYRocAAABJkVzzIuoLGEaDoxfsNva12EUdxhJMGFQioSg8GxKsLm8kWEmExJuNidarkk+OTXc0i2OZEq2v+tZr/MDZRS0I7LfRpHdlsiF6m/mEjk+XlK10UqtKYUwNgMx24hUtCJLfpM3ExUeKDYjClgZAzAjQ0qlNQBTsGpk9zSRkCiKkRGp572VXsPYChGvxhAuYkDYZK//jSRgto2mTf6+PJqgAAgIAAAACYZE6aZOHhYkYlcbpeYQq1RgLO4U8TIlL1sGw+iKZi5Kzc/bKT0yXrIUMES89RCWy8oWlxqIQlKANLFpT/KjUrK+UCYbZqGnjVj29aO5dzofWAskRX5eJWPi4kf/aRVjy3Wlyg2AnMYIDSTLwZUTASIzflPWUwwlUnIFMnGiyABeaXJcN91PmQJCLzmvUJkFOHCrX/+6O///IHnT4tT9YYBoNMQ09GfKIErwdwChNz1Qy5+5S/wWeY//uSZF+C03UyT2tMO0A3RRkhY20KzQjDMszhA8DjlGOBp5y4ZCS3ica52GIGiryv7FAaSDVZSXKFTiir+GvGiuK4rjgwPVTddso+W/42a4ueJJHDYtfj6YoKknnjzRgKA0fBIRZOSsprJqnoNN73ps/Z9DVgbKNbMGmRzrYBMAZCPUANkAZQ0syAC2ubK1NF90+WoesBpnhY8qwVDkNb/5Uof6//418TgElCSgAIgyAAQBHEmiaQFPIRmfAMELffpo0IflyEuAAQnSnKvwTlVlnIgOAAGS3P3IydjXPSh/CaVRqpSNCjQqDvPM+fLcuN+WgqNix6CoHomUWTT86JjziRSZ3yjnq+dIldKPU11KUuf6wAASMAAJxE+MlyktgE9UGSxjEx6RR0v1s9bWZ+EJSrGtjqUIhklG3J8eLRn/2U/nv7f///+7/6gBQgEAMUijVMwweWWMyYM/PLXuc7DptIQmBARMRCxXjEIcTNDQgSSeHpUNXO7dRSOllJPvnY7yzaO1hmUjsKvHe99fOxrabMX7mGTi5tsNkZVZLndzxse//7kmR7ABM2O0pbKTvQN4NI+WGFPA2ZESs1pYAAvA0jVrJwAHfbr/c6//vW790dzX36QNBRlDv/6QQAU3V64yUgBEAYc/lI8e5bm+Z9+j+4aaj4tFrb//iker/4a12b/V//q//9v+7vAEAAAAMqZTGd5gL4f54o6ZebKNrR/zWVYUEVYVVv8BuAV2OUT+DUQgkJ8J1Ey4ZbFCiAwgwzMSdHV4jQR+OoPWEASaPkyYq+PsQFFJCsEEJtOiUjI/+GRhtC2DnizTMXATJig9Ey/kAJMrkHGYJ8gpLjmJOYoskpav+ShRJInyGGZVJMihDi6pIxRZJJel/8iZPkYiREnyKE0akTL5QNSqT5iiySS9Ja2SV//5ME0ak//+4KgAAABgQBAADAMDgYCAEgCteQ0fZH6+ICXA357+MPfhR/+ywRf/U///LVTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVX/+5JknQAFoWhGLm5gBClBmT3GiAAAAAGkHAAAIAAANIOAAARVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV");
  var sr = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOcAAACDCAYAAAB2kQxsAAAAAXNSR0IArs4c6QAABdRJREFUeJzt3d3N3TYMgGG16ADdoAhyl7UyV9bqXRB0g2zQXgRGDcOWSIoUaX3vAwQBknMk/4gWLcnHrQEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACDEb9kb8FH99eeXf6Wf/efn35ynDyj1pEsb6G6NUxOYZ7sdB/QtPdnWRnn29gbKMYDUspPs0SgPb22cHANo/JG9AZF6wWBp3JLgeir36bvff3x9LOvzp2/dbSFA97bk5I4a9VMD7TXOUcP0uJ+d6emu5d6V1QvMs5nj8FZPx37X/b2TFpzShtnafeP0DipJMFnLnN3/w1OQ7tZgP+pA4VVKcHo0TG36KNULKGt5XsHZmi1APS5WM2Vqg0i7vbsG6YcIznN9vRTxXHavgdxtv6Tc3vc1pAHqdaG6ipwKYprpf1sFp6aH0gRTrxxLubPB2avHu+c/l3mICvqnsr//+Cq+qGrK1Xw/wzbBaRkNvSv3yew9cq+cu89L6nu6F/cMzCgzF1ftANlbe+Otp1IkDVxyVfbo6Z481f3507dhvXfbrk3HpdtjKTNqKuio8678c7mzF6ns6arfMyrVNoA75wMfNU2hKSeCx3Fq7dc+SPfDc39H9Vqn2CT//4bsYeT1PecOJyGSJdh6PZOlbElPZz2PHtlD1cUeS4LT4z5IOihwfNaD5ERm9qxH/dZ7Vmt9M999CtCZbdLUP/p3r2zFQ0paG8lr4Eb6+ZWBcSeq/qhyK6bXUfXOSgtO7/tOb9eT1NveqKttpYbiyXu/euV51JV16/T6e86zyF5TUp731V5Sp+Z7M71h9QvFNWWuvr0Sy4LzLfNvrel6zRX1e+hN2VzrnNlfaYD0xhCs++851lDh3vNV95xe6YvHgb8bwbNcuc+f09wbaUj2dzYgjz93//5kh94t0quCM8OKK6glKKuM0EYHfhUZWd8WwenZa0rLsp6s2YY66o0k9WUvS4NManBaGuo1eDIHgUZ1ePdkntsfFaCz5VZJdStsxyt7ziMNXHEAK5yk1mqmhrMPf1fcp57Vqe3SqZTMEduZhqAZyaywFne0DVHngHTZ11bznE88l/1lBZ9meP8851plWkBCO7drmQvWnL/sY/fKtFaqN3iy6iofsQxNktJnTMgfPXJUz3w3VaP5vOQ7Iyszvy2DczSi+aYFET2jINUEqFcAS4+rV480WlwRWXe07dLa0YGvfl9kmbTvPZJ1TXGvn4t4yuRp+2aMgk27wkm63DIztU3vOVfueC8wK4zKWtK0M+nvJXmOdlt65MgFFCva06qsKz044SvjIiN5TjLaaHxhtNyyouXBGZ1WSn66Ivt+M7pRZAWoZsDq+t2emeM1am/WtHxFG9runrO1/n1CxLK7CilxJM/H4bwuTJJBvWtgvm0gcNu01uvpd8la1soLE7xkpYDea4Ot6W3GOSzRc3o/qHw2M9qmXWA+uw+jbd0hyO9Yz0+vJ9QGcO/8ZV2YUqYVPN8dImXp3aJ/w1XTGGYfKZN+P7IXiXqO1uINLzFOm/Pz+BV4C03PNEqpZl//ELXP1ro8nhLyKLPHMyAiXyvh4cMFZ2uyAJXc62gzgJl1nhrSLMEzcLx+5qQnIhgqv6qhTHC2Zmus1tUuowCVDkRU6j0jgiJqhLPSSq2q7wMtMSBkdbcQWjNCq2nMlRrTnajAPP/t+c5Sj3K8VNueQ+pGzaa2MyOb2sZseW2dpL6ZnjMzfeQFt/Fe3XP2WIfGvRY6a569jCJ9TaIlcCS9KQE5p1TP2VrMbwLNDlZEvpE5AkGxh9f2nLO/QOetytIwAnMf6SfS2ns+jaZ6B4i2sWvSvF0HWOAj/aRGNFAaPXbw2rS2Rzr0T/ChshKNM3qd4135BCaqK9VAKy+lAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD/4DBC0k0jFtF9wAAAAASUVORK5CYII=";
  var or = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOcAAACDCAYAAAB2kQxsAAAAAXNSR0IArs4c6QAABqxJREFUeJztnU1yFDkQRtMEB+AG7Fk6fBPO6ZsQLGc/N5gbMAtosJvqKv2kpPxS763A0W5XSXqVqZ+SngzgF58/fflx/7N///vnacW1gBkFD2Z2LOYNBF3Dx9UXAGs5kxLWwhNxU2qlJHrOhwLfkNZoiaBzIa3dCFJYLXgSboKXmETPeVDQyamR8vX55fe/v37/9vBzCDoH0tqktEpZ+t0IOh4KOBm16euZmETPtVDAiRgRLRF0HRRuEkrFrE1hzR4Lipxj+bD6AqCPz5++/Bgp5tXfdv1CeAdPPmFmSkn0nE+a0drdFm6XiOkdKWEuKRptTXqlLuqqFNaM6Dkb+T5nbb+npo8WjZVinqFantFJk9bWojaRThq7HzKN8wiPJ7aCoJHEZN5zHvJp7RE1DTV6SnZ1fa/PL1MjJtF5HmnT2tJF3GZ/BIj05I8ULUtR6ypER7ogjxpw61rRGxEal4KYjNyORzatbUlHSxr06tFcBTHPiN5NUEJWzlZKG/aKRqYk5tl1IKgPafucZ7w+vxSluLP6olHnL6MQQfYV6bpk/+BRZXm+cXHEiApSipZHlE6tRBDMkxmyysl5VsmtjXiFoJmiZU35ZWK0oNv1OY+omSv0GDDKJCaMI42cHg25dvFCi6QZxVS6ViVSpLUz38A4oiS9ySjlW2althGWKZrN6XNuOVpbwq0ReIzqZhfTrHwE/PZZuEYqcnqO0tZQGxVqRylprLGIEDXNkLOKEakbYsYiiphmiQaEZuD9BghixiKSmGYJIueqBt4TRZEyHtHENCNyNtMaRREzHhHFNBOKnKv7myVcVXKka4WfRBXTjMjpypl8iBmP6MsOmed0Bgk1UHjxXlpORIAWIqeybyGtha1QEdNMRM5s7wLCGpTENBORE6AXNTHNkBM2QFFMM4F5ToX5TYiLqphmRE7YmMhimiEnJEb9XBdJOUlp4Qp1Mc1E5QQ4I/qyvFJCy8n8JnijEjXNAi3fQ0TwIEM6e2OqnAgII8kkptkgOZEQZlN6BquZjqhVFxlBOkZq4Z6WASAFQQ8jZwQJ70FK8CTiaeb3fDSLJyMiwiwiS/q0SkwEBE+85jYjSTpcTiSE2WQRtVlOpAMVemVdtjXmlZxICFlQk/TJjHcmYS96JJ0p6KmcZggKeWmVdPopYwgKuxJVUuQE+EU0Sd99KYICxJH0ry9DUIA/rFy3WyWnGYLCnqyQ9PCXERTgmJmSPvwlBAU4p1bUWklPP1yytA9JYWdGRtLLDyEowDUjomiRwQgKUIZnJC3OgREUoByPSDpkDyEkBfhJj6RNQ7xEUYA6aiS9Cdo8SUoUBaijVtCuFQwICtBGiajdawARFKCNK0HdVtEjKUAd0+Q0q9v/FklhJ1rmP4e8JEoUBejfq2jYNgtEUdgJzwN7u6dSSkBQyMSME7O7FyHUQpoLCqw8rv5o+d6Uw3NvfzjagUkAZvOlLH1lLMyx8wCzWBEhW3ZDmLZ7NTsrwCpmyui5A1+IPidigjcjhZy14/vytBYxwRsPMVcf/2c2QU72wQUVIgj5lqFyIiZEJ5qQb1me1gLMJLKM93wY9cVETYiGkphmg+RETFhJljY2LHICQB/uchI1AXxwlRMxAfwgrYVtUHvxwk1OoiaAL8MjJ2ICtOEip1q6APnJEBS6VwiRzp4vtM5YBvf3m/EeI8DyvUZK33z4+v1bqsZ7dN+3n2W6zwgMO44hY0X1vIqkXh419x7lXh9ds8oyviFyRqmcXrxf2FUtF89ymFkG6nI2p7WZB4FGvUWfLcVt4ahsdy+TR7ifz6lc0F5v0GfalmXldpE3esrr6PrTR84sjNjS4kpQhQhaUi4lD6KR1xK9DHupfoKoR02vSFDy9FWNoKVivv1/lG7OfZkqR043OZUbWgmtFaomaGl51ZTHCnFv5bqNnFGjZvRtEFUEHSHmI1ZHWgVBXZ5+sxvX7ANlPChpjKsknSllKaPlRU4nZo0Yjq6wiIJGFPMML2mj3M8ZRRe4QkzF6FhCJEFbBn4i0iKswn11yenZiLLKeMRqQdWiZSmlkqrcV9d0gPfksAcqBW+2ZqAoq5gZGSrnTtGwlVmCIqUepxWxerj7iIyNZ7SgiKmJhJw7NJpRgiKmLuHl3KnReA4UIaU+y+WkcbzHQ1DEzMGQ9aJH0BDK6RE0y9wlTDp2HuppERQxc0FFBaZGUMTMB5UlQG/fHyk1odJEaBUUMXWh4oSoFRQxtaHyxMi2uBseQwUKciUoYuaAShTlkaCImQcqUph7QREzF/8DSS/2GZ2/N/sAAAAASUVORK5CYII=";
  var xs = "3000.0.0-alpha.4";
  var ar = { ArrowLeft: "left", ArrowRight: "right", ArrowUp: "up", ArrowDown: "down", " ": "space" };
  var ur = ["left", "middle", "right", "back", "forward"];
  var Es = ["space", "left", "right", "up", "down", "tab", "f1", "f2", "f3", "f4", "f5", "f6", "f7", "f8", "f9", "f10", "f11", "s"];
  var cr = " !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~";
  var lr = 0;
  var hr = 3;
  var Ss = 0;
  var Cs = 3;
  var Ts = -1200;
  var As = 1200;
  var mt = "topleft";
  var dr = 64;
  var Os = "happy";
  var pt = "monospace";
  var Ps = 36;
  var fr = 64;
  var gt = 1024;
  var mr = 0.1;
  var Rs = 1;
  var wr = [{ name: "a_pos", size: 3 }, { name: "a_uv", size: 2 }, { name: "a_color", size: 4 }];
  var wt = wr.reduce((i, r) => i + r.size, 0);
  var br = 2048;
  var pr = br * 4 * wt;
  var gr = br * 6;
  var Ds = `
attribute vec3 a_pos;
attribute vec2 a_uv;
attribute vec4 a_color;

varying vec3 v_pos;
varying vec2 v_uv;
varying vec4 v_color;

vec4 def_vert() {
	return vec4(a_pos, 1.0);
}

{{user}}

void main() {
	vec4 pos = vert(a_pos, a_uv, a_color);
	v_pos = a_pos;
	v_uv = a_uv;
	v_color = a_color;
	gl_Position = pos;
}
`;
  var Ms = `
precision mediump float;

varying vec3 v_pos;
varying vec2 v_uv;
varying vec4 v_color;

uniform sampler2D u_tex;

vec4 def_frag() {
	return v_color * texture2D(u_tex, v_uv);
}

{{user}}

void main() {
	gl_FragColor = frag(v_pos, v_uv, v_color, u_tex);
	if (gl_FragColor.a == 0.0) {
		discard;
	}
}
`;
  var qt = `
vec4 vert(vec3 pos, vec2 uv, vec4 color) {
	return def_vert();
}
`;
  var zt = `
vec4 frag(vec3 pos, vec2 uv, vec4 color, sampler2D tex) {
	return def_frag();
}
`;
  var Fs = /* @__PURE__ */ new Set(["id", "require"]);
  var Ls = /* @__PURE__ */ new Set(["add", "update", "draw", "destroy", "inspect", "drawInspect"]);
  function Ht(i) {
    return i === "pressed" || i === "rpressed" ? "down" : i === "released" ? "up" : i;
  }
  u(Ht, "processButtonState");
  function Bs(i) {
    i.requestFullscreen ? i.requestFullscreen() : i.webkitRequestFullscreen && i.webkitRequestFullscreen();
  }
  u(Bs, "enterFullscreen");
  function Vs() {
    document.exitFullscreen ? document.exitFullscreen() : document.webkitExitFullScreen && document.webkitExitFullScreen();
  }
  u(Vs, "exitFullscreen");
  function Gs() {
    return document.fullscreenElement || document.webkitFullscreenElement;
  }
  u(Gs, "getFullscreenElement");
  function tt(i) {
    switch (i) {
      case "topleft":
        return f(-1, -1);
      case "top":
        return f(0, -1);
      case "topright":
        return f(1, -1);
      case "left":
        return f(-1, 0);
      case "center":
        return f(0, 0);
      case "right":
        return f(1, 0);
      case "botleft":
        return f(-1, 1);
      case "bot":
        return f(0, 1);
      case "botright":
        return f(1, 1);
      default:
        return i;
    }
  }
  u(tt, "anchorPt");
  function Is(i) {
    switch (i) {
      case "left":
        return 0;
      case "center":
        return 0.5;
      case "right":
        return 1;
      default:
        return 0;
    }
  }
  u(Is, "alignPt");
  function $t() {
    return new AudioBuffer({ length: 1, numberOfChannels: 1, sampleRate: 44100 });
  }
  u($t, "createEmptyAudioBuffer");
  var co = u((i = {}) => {
    let r = [], o = (() => {
      let e = i.root ?? document.body;
      e === document.body && (document.body.style.width = "100%", document.body.style.height = "100%", document.body.style.margin = "0px", document.documentElement.style.width = "100%", document.documentElement.style.height = "100%");
      let t = i.canvas ?? (() => {
        let v = document.createElement("canvas");
        return e.appendChild(v), v;
      })(), n = i.scale ?? 1, s = !(i.width && i.height && !i.stretch && !i.letterbox), h = t.parentElement.offsetWidth, a = t.parentElement.offsetHeight;
      s ? (t.width = h, t.height = a) : (t.width = i.width * n, t.height = i.height * n);
      let l = t.width, d = t.height, p = i.pixelDensity || window.devicePixelRatio;
      t.width *= p, t.height *= p;
      let w = [`width: ${l}px`, `height: ${d}px`, "outline: none", "cursor: default"];
      return i.crisp && (w.push("image-rendering: pixelated"), w.push("image-rendering: crisp-edges")), t.style.cssText = w.join(";"), t.tabIndex = 0, { canvas: t, canvas2: t.cloneNode(), pixelDensity: p, stretchToParent: s, lastParentWidth: h, lastParentHeight: a, keyStates: {}, mouseStates: {}, virtualButtonStates: {}, charInputted: [], numKeyDown: 0, isMouseMoved: false, isKeyPressed: false, isKeyPressedRepeat: false, isKeyReleased: false, mouseStarted: false, mousePos: f(0, 0), mouseDeltaPos: f(0, 0), time: 0, realTime: 0, skipTime: false, dt: 0, numFrames: 0, isTouchScreen: "ontouchstart" in window || navigator.maxTouchPoints > 0, loopID: null, stopped: false, paused: false, fpsCounter: new $e() };
    })(), c2 = o.canvas.getContext("webgl", { antialias: true, depth: true, stencil: true, alpha: true, preserveDrawingBuffer: true });
    class b {
      glTex;
      width;
      height;
      constructor(t, n, s = {}) {
        this.glTex = c2.createTexture(), r.push(() => this.free()), this.bind(), t && n && c2.texImage2D(c2.TEXTURE_2D, 0, c2.RGBA, t, n, 0, c2.RGBA, c2.UNSIGNED_BYTE, null), this.width = t, this.height = n;
        let h = (() => {
          switch (s.filter ?? i.texFilter) {
            case "linear":
              return c2.LINEAR;
            case "nearest":
              return c2.NEAREST;
            default:
              return c2.NEAREST;
          }
        })(), a = (() => {
          switch (s.wrap) {
            case "repeat":
              return c2.REPEAT;
            case "clampToEdge":
              return c2.CLAMP_TO_EDGE;
            default:
              return c2.CLAMP_TO_EDGE;
          }
        })();
        c2.texParameteri(c2.TEXTURE_2D, c2.TEXTURE_MIN_FILTER, h), c2.texParameteri(c2.TEXTURE_2D, c2.TEXTURE_MAG_FILTER, h), c2.texParameteri(c2.TEXTURE_2D, c2.TEXTURE_WRAP_S, a), c2.texParameteri(c2.TEXTURE_2D, c2.TEXTURE_WRAP_T, a), this.unbind();
      }
      static fromImage(t, n = {}) {
        let s = new b(0, 0, n);
        return s.bind(), c2.texImage2D(c2.TEXTURE_2D, 0, c2.RGBA, c2.RGBA, c2.UNSIGNED_BYTE, t), s.width = t.width, s.height = t.height, s.unbind(), s;
      }
      update(t, n, s) {
        this.bind(), c2.texSubImage2D(c2.TEXTURE_2D, 0, t, n, c2.RGBA, c2.UNSIGNED_BYTE, s), this.unbind();
      }
      bind() {
        c2.bindTexture(c2.TEXTURE_2D, this.glTex);
      }
      unbind() {
        c2.bindTexture(c2.TEXTURE_2D, null);
      }
      free() {
        c2.deleteTexture(this.glTex);
      }
    }
    u(b, "Texture");
    let m = (() => {
      let e = vt(qt, zt), t = b.fromImage(new ImageData(new Uint8ClampedArray([255, 255, 255, 255]), 1, 1));
      if (i.background) {
        let a = E.fromArray(i.background);
        c2.clearColor(a.r / 255, a.g / 255, a.b / 255, i.background[3] ?? 1);
      }
      c2.enable(c2.BLEND), c2.enable(c2.SCISSOR_TEST), c2.blendFuncSeparate(c2.SRC_ALPHA, c2.ONE_MINUS_SRC_ALPHA, c2.ONE, c2.ONE_MINUS_SRC_ALPHA);
      let n = c2.createBuffer();
      c2.bindBuffer(c2.ARRAY_BUFFER, n), c2.bufferData(c2.ARRAY_BUFFER, pr * 4, c2.DYNAMIC_DRAW), wr.reduce((a, l, d) => (c2.vertexAttribPointer(d, l.size, c2.FLOAT, false, wt * 4, a), c2.enableVertexAttribArray(d), a + l.size * 4), 0), c2.bindBuffer(c2.ARRAY_BUFFER, null);
      let s = c2.createBuffer();
      c2.bindBuffer(c2.ELEMENT_ARRAY_BUFFER, s), c2.bufferData(c2.ELEMENT_ARRAY_BUFFER, gr * 4, c2.DYNAMIC_DRAW), c2.bindBuffer(c2.ELEMENT_ARRAY_BUFFER, null);
      let h = b.fromImage(new ImageData(new Uint8ClampedArray([128, 128, 128, 255, 190, 190, 190, 255, 190, 190, 190, 255, 128, 128, 128, 255]), 2, 2), { wrap: "repeat", filter: "nearest" });
      return { drawCalls: 0, lastDrawCalls: 0, defShader: e, curShader: e, defTex: t, curTex: t, curUniform: {}, vbuf: n, ibuf: s, vqueue: [], iqueue: [], transform: new A(), transformStack: [], bgTex: h, width: i.width, height: i.height, viewport: { x: 0, y: 0, width: c2.drawingBufferWidth, height: c2.drawingBufferHeight } };
    })();
    class C {
      tex;
      frames = [new j(0, 0, 1, 1)];
      anims = {};
      constructor(t, n, s = {}) {
        this.tex = t, n && (this.frames = n), this.anims = s;
      }
      static from(t, n = {}) {
        return typeof t == "string" ? C.fromURL(t, n) : Promise.resolve(C.fromImage(t, n));
      }
      static fromImage(t, n = {}) {
        return new C(b.fromImage(t, n), Oe(n.sliceX || 1, n.sliceY || 1), n.anims ?? {});
      }
      static fromURL(t, n = {}) {
        return Te(t).then((s) => C.fromImage(s, n));
      }
    }
    u(C, "SpriteData");
    class R {
      buf;
      constructor(t) {
        this.buf = t;
      }
      static fromArrayBuffer(t) {
        return new Promise((n, s) => T.ctx.decodeAudioData(t, n, s)).then((n) => new R(n));
      }
      static fromURL(t) {
        return kt(t) ? R.fromArrayBuffer(er(t)) : rt(t).then((n) => R.fromArrayBuffer(n));
      }
    }
    u(R, "SoundData");
    let T = (() => {
      let e = new (window.AudioContext || window.webkitAudioContext)(), t = e.createGain();
      t.connect(e.destination);
      let n = new R($t());
      return e.decodeAudioData(_t.buffer.slice(0)).then((s) => {
        n.buf = s;
      }).catch((s) => {
        console.error("Failed to load burp: ", s);
      }), { ctx: e, masterNode: t, burpSnd: n };
    })();
    class O {
      done = false;
      data = null;
      error = null;
      onLoadEvents = new ne();
      onErrorEvents = new ne();
      onFinishEvents = new ne();
      constructor(t) {
        t.then((n) => {
          this.data = n, this.onLoadEvents.trigger(n);
        }).catch((n) => {
          if (this.error = n, this.onErrorEvents.numListeners() > 0)
            this.onErrorEvents.trigger(n);
          else
            throw n;
        }).finally(() => {
          this.onFinishEvents.trigger(), this.done = true;
        });
      }
      static loaded(t) {
        let n = new O(Promise.resolve(t));
        return n.data = t, n.done = true, n;
      }
      onLoad(t) {
        return this.onLoadEvents.add(t), this;
      }
      onError(t) {
        return this.onErrorEvents.add(t), this;
      }
      onFinish(t) {
        return this.onFinishEvents.add(t), this;
      }
      then(t) {
        return this.onLoad(t);
      }
      catch(t) {
        return this.onError(t);
      }
      finally(t) {
        return this.onFinish(t);
      }
    }
    u(O, "Asset");
    class M {
      assets = /* @__PURE__ */ new Map();
      lastUID = 0;
      add(t, n) {
        let s = t ?? this.lastUID++ + "", h = new O(n);
        return this.assets.set(s, h), h;
      }
      addLoaded(t, n) {
        let s = t ?? this.lastUID++ + "", h = O.loaded(n);
        this.assets.set(s, h);
      }
      get(t) {
        return this.assets.get(t);
      }
      progress() {
        if (this.assets.size === 0)
          return 1;
        let t = 0;
        return this.assets.forEach((n) => {
          n.done && t++;
        }), t / this.assets.size;
      }
    }
    u(M, "AssetBucket");
    let U = { urlPrefix: "", sprites: new M(), fonts: new M(), bitmapFonts: new M(), sounds: new M(), shaders: new M(), custom: new M(), loaded: false }, g = { ev: new le(), objEvents: new le(), root: Un([]), timers: new ce(), gravity: 0, scenes: {}, logs: [], cam: { pos: null, scale: f(1), angle: 0, shake: 0, transform: new A() } };
    function de(e) {
      return U.custom.add(null, e);
    }
    u(de, "load");
    function V() {
      let e = [U.sprites, U.sounds, U.shaders, U.fonts, U.bitmapFonts, U.custom];
      return e.reduce((t, n) => t + n.progress(), 0) / e.length;
    }
    u(V, "loadProgress");
    function Y(e) {
      return e !== void 0 && (U.urlPrefix = e), U.urlPrefix;
    }
    u(Y, "loadRoot");
    function Se(e) {
      let t = U.urlPrefix + e;
      return fetch(t).then((n) => {
        if (!n.ok)
          throw new Error(`Failed to fetch ${t}`);
        return n;
      });
    }
    u(Se, "fetchURL");
    function Ce(e) {
      return Se(e).then((t) => t.json());
    }
    u(Ce, "fetchJSON");
    function nt(e) {
      return Se(e).then((t) => t.text());
    }
    u(nt, "fetchText");
    function rt(e) {
      return Se(e).then((t) => t.arrayBuffer());
    }
    u(rt, "fetchArrayBuffer");
    function Te(e) {
      let t = new Image();
      return t.crossOrigin = "anonymous", t.src = kt(e) ? e : U.urlPrefix + e, new Promise((n, s) => {
        t.onload = () => n(t), t.onerror = () => s(new Error(`Failed to load image from "${e}"`));
      });
    }
    u(Te, "loadImg");
    function bt(e, t) {
      let n = new FontFace(e, typeof t == "string" ? `url(${t})` : t);
      return document.fonts.add(n), U.fonts.add(e, n.load().catch(() => {
        throw new Error(`Failed to load font from "${t}"`);
      }));
    }
    u(bt, "loadFont");
    function Ae(e, t, n, s, h = {}) {
      return U.bitmapFonts.add(e, Te(t).then((a) => Or(b.fromImage(a, h), n, s, h.chars ?? cr)));
    }
    u(Ae, "loadBitmapFont");
    function Oe(e = 1, t = 1, n = 0, s = 0, h = 1, a = 1) {
      let l = [], d = h / e, p = a / t;
      for (let w = 0; w < t; w++)
        for (let v = 0; v < e; v++)
          l.push(new j(n + v * d, s + w * p, d, p));
      return l;
    }
    u(Oe, "slice");
    function Yt(e, t) {
      return de(typeof t == "string" ? new Promise((n, s) => {
        Ce(t).then((h) => {
          Yt(e, h).onLoad(n).onError(s);
        });
      }) : C.from(e).then((n) => {
        let s = {};
        for (let h in t) {
          let a = n.tex.width, l = n.tex.height, d = t[h], p = new C(n.tex, Oe(d.sliceX, d.sliceY, d.x / a, d.y / l, d.width / a, d.height / l), d.anims);
          U.sprites.addLoaded(h, p), s[h] = p;
        }
        return s;
      }));
    }
    u(Yt, "loadSpriteAtlas");
    function Pe(e, t, n = { sliceX: 1, sliceY: 1, anims: {} }) {
      return U.sprites.add(e, typeof t == "string" ? C.fromURL(t, n) : Promise.resolve(C.fromImage(t, n)));
    }
    u(Pe, "loadSprite");
    function vr(e, t) {
      return U.sprites.add(e, new Promise(async (n) => {
        let s = typeof t == "string" ? await Ce(t) : t, h = await Promise.all(s.frames.map(Te)), a = document.createElement("canvas");
        a.width = s.width, a.height = s.height * s.frames.length;
        let l = a.getContext("2d");
        h.forEach((p, w) => {
          l.drawImage(p, 0, w * s.height);
        });
        let d = await Pe(null, a, { sliceY: s.frames.length, anims: s.anims });
        n(d);
      }));
    }
    u(vr, "loadPedit");
    function yr(e, t, n) {
      return U.sprites.add(e, new Promise(async (s) => {
        let h = await Pe(null, t), a = typeof n == "string" ? await Ce(n) : n, l = a.meta.size;
        h.frames = a.frames.map((d) => new j(d.frame.x / l.w, d.frame.y / l.h, d.frame.w / l.w, d.frame.h / l.h));
        for (let d of a.meta.frameTags)
          d.from === d.to ? h.anims[d.name] = d.from : h.anims[d.name] = { from: d.from, to: d.to, speed: 10, loop: true, pingpong: d.direction === "pingpong" };
        s(h);
      }));
    }
    u(yr, "loadAseprite");
    function Ur(e, t, n, s = false) {
      return U.shaders.add(e, new Promise((h, a) => {
        let l = u((d) => d ? nt(d) : new Promise((p) => p(null)), "resolveUrl");
        if (s)
          Promise.all([l(t), l(n)]).then(([d, p]) => {
            h(vt(d, p));
          }).catch(a);
        else
          try {
            h(vt(t, n));
          } catch (d) {
            a(d);
          }
      }));
    }
    u(Ur, "loadShader");
    function xr(e, t) {
      return U.sounds.add(e, typeof t == "string" ? R.fromURL(t) : R.fromArrayBuffer(t));
    }
    u(xr, "loadSound");
    function Er(e = "bean") {
      return Pe(e, ir);
    }
    u(Er, "loadBean");
    function Xt(e) {
      return U.sprites.get(e);
    }
    u(Xt, "getSprite");
    function Kt(e) {
      return U.sounds.get(e);
    }
    u(Kt, "getSound");
    function Sr(e) {
      return U.fonts.get(e);
    }
    u(Sr, "getFont");
    function Qt(e) {
      return U.bitmapFonts.get(e);
    }
    u(Qt, "getBitmapFont");
    function Jt(e) {
      return U.shaders.get(e);
    }
    u(Jt, "getShader");
    function Zt(e) {
      if (typeof e == "string") {
        let t = Xt(e);
        if (t)
          return t;
        if (V() < 1)
          return null;
        throw new Error(`Sprite not found: ${e}`);
      } else {
        if (e instanceof C)
          return O.loaded(e);
        if (e instanceof O)
          return e;
        throw new Error(`Invalid sprite: ${e}`);
      }
    }
    u(Zt, "resolveSprite");
    function Cr(e) {
      if (typeof e == "string") {
        let t = Kt(e);
        if (t)
          return t.data ? t.data : t;
        if (V() < 1)
          return null;
        throw new Error(`Sound not found: ${e}`);
      } else {
        if (e instanceof R)
          return e;
        if (e instanceof O)
          return e.data ? e.data : e;
        throw new Error(`Invalid sound: ${e}`);
      }
    }
    u(Cr, "resolveSound");
    function Tr(e) {
      if (!e)
        return m.defShader;
      if (typeof e == "string") {
        let t = Jt(e);
        if (t)
          return t.data ? t.data : t;
        if (V() < 1)
          return null;
        throw new Error(`Shader not found: ${e}`);
      } else if (e instanceof O)
        return e.data ? e.data : e;
      return e;
    }
    u(Tr, "resolveShader");
    function Wt(e) {
      if (!e)
        return Wt(i.font ?? Os);
      if (typeof e == "string") {
        let t = Qt(e);
        if (t)
          return t.data ? t.data : t;
        if (document.fonts.check(`${fr}px ${e}`))
          return e;
        if (V() < 1)
          return null;
        throw new Error(`Font not found: ${e}`);
      } else if (e instanceof O)
        return e.data ? e.data : e;
      return e;
    }
    u(Wt, "resolveFont");
    function Ar(e) {
      return e !== void 0 && (T.masterNode.gain.value = te(e, lr, hr)), T.masterNode.gain.value;
    }
    u(Ar, "volume");
    function Ye(e, t = { loop: false, volume: 1, speed: 1, detune: 0, seek: 0 }) {
      let n = Cr(e);
      if (n instanceof O) {
        let y = Ye(new R($t())), B = u((P) => {
          let q = Ye(P, t);
          for (let z2 in q)
            y[z2] = q[z2];
        }, "doPlay");
        return n.onLoad(B), y;
      } else if (n === null) {
        let y = Ye(new R($t()));
        return Rt(() => {
        }), y;
      }
      let s = T.ctx, h = false, a = s.createBufferSource();
      a.buffer = n.buf, a.loop = !!t.loop;
      let l = s.createGain();
      a.connect(l), l.connect(T.masterNode);
      let d = t.seek ?? 0;
      a.start(0, d);
      let p = s.currentTime - d, w = null, v = { stop() {
        h || (this.pause(), p = s.currentTime);
      }, play(y) {
        if (!h)
          return;
        let B = a;
        a = s.createBufferSource(), a.buffer = B.buffer, a.loop = B.loop, a.playbackRate.value = B.playbackRate.value, a.detune && (a.detune.value = B.detune.value), a.connect(l);
        let P = y ?? this.time();
        a.start(0, P), p = s.currentTime - P, h = false, w = null;
      }, pause() {
        h || (a.stop(), h = true, w = s.currentTime);
      }, isPaused() {
        return h;
      }, isStopped() {
        return h;
      }, speed(y) {
        return y !== void 0 && (a.playbackRate.value = te(y, Ss, Cs)), a.playbackRate.value;
      }, detune(y) {
        return a.detune ? (y !== void 0 && (a.detune.value = te(y, Ts, As)), a.detune.value) : 0;
      }, volume(y) {
        return y !== void 0 && (l.gain.value = te(y, lr, hr)), l.gain.value;
      }, loop() {
        a.loop = true;
      }, unloop() {
        a.loop = false;
      }, duration() {
        return n.buf.duration;
      }, time() {
        return h ? w - p : s.currentTime - p;
      } };
      return v.speed(t.speed), v.detune(t.detune), v.volume(t.volume), v;
    }
    u(Ye, "play");
    function en(e) {
      return Ye(T.burpSnd, e);
    }
    u(en, "burp");
    function vt(e = qt, t = zt) {
      let n = Ds.replace("{{user}}", e ?? qt), s = Ms.replace("{{user}}", t ?? zt), h = c2.createShader(c2.VERTEX_SHADER), a = c2.createShader(c2.FRAGMENT_SHADER);
      c2.shaderSource(h, n), c2.shaderSource(a, s), c2.compileShader(h), c2.compileShader(a);
      let l = c2.createProgram();
      if (r.push(() => c2.deleteProgram(l)), c2.attachShader(l, h), c2.attachShader(l, a), c2.bindAttribLocation(l, 0, "a_pos"), c2.bindAttribLocation(l, 1, "a_uv"), c2.bindAttribLocation(l, 2, "a_color"), c2.linkProgram(l), !c2.getProgramParameter(l, c2.LINK_STATUS)) {
        let d = u((y) => {
          let B = /^ERROR:\s0:(?<line>\d+):\s(?<msg>.+)/, P = y.match(B);
          return { line: Number(P.groups.line), msg: P.groups.msg.replace(/\n\0$/, "") };
        }, "formatShaderError"), p = c2.getShaderInfoLog(h), w = c2.getShaderInfoLog(a), v = "";
        if (p) {
          let y = d(p);
          v += `Vertex shader line ${y.line - 14}: ${y.msg}`;
        }
        if (w) {
          let y = d(w);
          v += `Fragment shader line ${y.line - 14}: ${y.msg}`;
        }
        throw new Error(v);
      }
      return c2.deleteShader(h), c2.deleteShader(a), { bind() {
        c2.useProgram(l);
      }, unbind() {
        c2.useProgram(null);
      }, free() {
        c2.deleteProgram(l);
      }, send(d) {
        for (let p in d) {
          let w = d[p], v = c2.getUniformLocation(l, p);
          typeof w == "number" ? c2.uniform1f(v, w) : w instanceof A ? c2.uniformMatrix4fv(v, false, new Float32Array(w.m)) : w instanceof E ? c2.uniform3f(v, w.r, w.g, w.b) : w instanceof je ? c2.uniform3f(v, w.x, w.y, w.z) : w instanceof D && c2.uniform2f(v, w.x, w.y);
        }
      } };
    }
    u(vt, "makeShader");
    function Or(e, t, n, s) {
      let h = e.width / t, a = {}, l = s.split("").entries();
      for (let [d, p] of l)
        a[p] = new j(d % h * t, Math.floor(d / h) * n, t, n);
      return { tex: e, map: a, size: n };
    }
    u(Or, "makeFont");
    function yt(e, t, n, s = m.defTex, h = m.defShader, a = {}) {
      let l = Tr(h);
      if (!(!l || l instanceof O)) {
        (s !== m.curTex || l !== m.curShader || !It(m.curUniform, a) || m.vqueue.length + e.length * wt > pr || m.iqueue.length + t.length > gr) && fe();
        for (let d of e) {
          let p = n ? m.transform : g.cam.transform.mult(m.transform), w = Dr(p.multVec2(d.pos.xy()));
          m.vqueue.push(w.x, w.y, d.pos.z, d.uv.x, d.uv.y, d.color.r / 255, d.color.g / 255, d.color.b / 255, d.opacity);
        }
        for (let d of t)
          m.iqueue.push(d + m.vqueue.length / wt - e.length);
        m.curTex = s, m.curShader = l, m.curUniform = a;
      }
    }
    u(yt, "drawRaw");
    function fe() {
      !m.curTex || !m.curShader || m.vqueue.length === 0 || m.iqueue.length === 0 || (c2.bindBuffer(c2.ARRAY_BUFFER, m.vbuf), c2.bufferSubData(c2.ARRAY_BUFFER, 0, new Float32Array(m.vqueue)), c2.bindBuffer(c2.ELEMENT_ARRAY_BUFFER, m.ibuf), c2.bufferSubData(c2.ELEMENT_ARRAY_BUFFER, 0, new Uint16Array(m.iqueue)), m.curShader.bind(), m.curShader.send(m.curUniform), m.curTex.bind(), c2.drawElements(c2.TRIANGLES, m.iqueue.length, c2.UNSIGNED_SHORT, 0), m.curTex.unbind(), m.curShader.unbind(), c2.bindBuffer(c2.ARRAY_BUFFER, null), c2.bindBuffer(c2.ELEMENT_ARRAY_BUFFER, null), m.vqueue = [], m.iqueue = [], m.drawCalls++);
    }
    u(fe, "flush");
    function Pr() {
      jr(), c2.clear(c2.COLOR_BUFFER_BIT), i.background || ae(() => {
        De({ width: k(), height: L(), quad: new j(0, 0, k() / dr, L() / dr), tex: m.bgTex, fixed: true });
      }), m.drawCalls = 0, m.transformStack = [], m.transform = new A();
    }
    u(Pr, "frameStart");
    function Rr() {
      fe(), m.lastDrawCalls = m.drawCalls;
    }
    u(Rr, "frameEnd");
    function Dr(e) {
      return f(e.x / k() * 2 - 1, -e.y / L() * 2 + 1);
    }
    u(Dr, "screen2ndc");
    function Mr(e) {
      m.transform = e.clone();
    }
    u(Mr, "pushMatrix");
    function G(...e) {
      if (e[0] === void 0)
        return;
      let t = f(...e);
      t.x === 0 && t.y === 0 || (m.transform = m.transform.translate(t));
    }
    u(G, "pushTranslate");
    function Re(...e) {
      if (e[0] === void 0)
        return;
      let t = f(...e);
      t.x === 1 && t.y === 1 || (m.transform = m.transform.scale(t));
    }
    u(Re, "pushScale");
    function Fr(e) {
      !e || (m.transform = m.transform.rotateX(e));
    }
    u(Fr, "pushRotateX");
    function Lr(e) {
      !e || (m.transform = m.transform.rotateY(e));
    }
    u(Lr, "pushRotateY");
    function we(e) {
      !e || (m.transform = m.transform.rotateZ(e));
    }
    u(we, "pushRotateZ");
    let Br = we;
    function W() {
      m.transformStack.push(m.transform.clone());
    }
    u(W, "pushTransform");
    function X() {
      m.transformStack.length > 0 && (m.transform = m.transformStack.pop());
    }
    u(X, "popTransform");
    function De(e) {
      if (e.width === void 0 || e.height === void 0)
        throw new Error('drawUVQuad() requires property "width" and "height".');
      if (e.width <= 0 || e.height <= 0)
        return;
      let t = e.width, n = e.height, h = tt(e.anchor || mt).scale(f(t, n).scale(-0.5)), a = e.quad || new j(0, 0, 1, 1), l = e.color || x(255, 255, 255), d = e.opacity ?? 1, p = e.tex ? mr / e.tex.width : 0, w = e.tex ? mr / e.tex.height : 0, v = a.x + p, y = a.y + w, B = a.w - p * 2, P = a.h - w * 2;
      W(), G(e.pos), we(e.angle), Re(e.scale), G(h), yt([{ pos: ge(-t / 2, n / 2, 0), uv: f(e.flipX ? v + B : v, e.flipY ? y : y + P), color: l, opacity: d }, { pos: ge(-t / 2, -n / 2, 0), uv: f(e.flipX ? v + B : v, e.flipY ? y + P : y), color: l, opacity: d }, { pos: ge(t / 2, -n / 2, 0), uv: f(e.flipX ? v : v + B, e.flipY ? y + P : y), color: l, opacity: d }, { pos: ge(t / 2, n / 2, 0), uv: f(e.flipX ? v : v + B, e.flipY ? y : y + P), color: l, opacity: d }], [0, 1, 3, 1, 2, 3], e.fixed, e.tex, e.shader, e.uniform), X();
    }
    u(De, "drawUVQuad");
    function Vr(e) {
      if (!e.tex)
        throw new Error('drawTexture() requires property "tex".');
      let t = e.quad ?? new j(0, 0, 1, 1), n = e.tex.width * t.w, s = e.tex.height * t.h, h = f(1);
      if (e.tiled) {
        let a = Math.ceil((e.width || n) / n), l = Math.ceil((e.height || s) / s), p = tt(e.anchor || mt).add(f(1, 1)).scale(0.5).scale(a * n, l * s);
        for (let w = 0; w < a; w++)
          for (let v = 0; v < l; v++)
            De({ ...e, pos: (e.pos || f(0)).add(f(n * w, s * v)).sub(p), scale: h.scale(e.scale || f(1)), tex: e.tex, quad: t, width: n, height: s, anchor: "topleft" });
      } else
        e.width && e.height ? (h.x = e.width / n, h.y = e.height / s) : e.width ? (h.x = e.width / n, h.y = h.x) : e.height && (h.y = e.height / s, h.x = h.y), De({ ...e, scale: h.scale(e.scale || f(1)), tex: e.tex, quad: t, width: n, height: s });
    }
    u(Vr, "drawTexture");
    function tn(e) {
      if (!e.sprite)
        throw new Error('drawSprite() requires property "sprite"');
      let t = Zt(e.sprite);
      if (!t || !t.data)
        return;
      let n = t.data.frames[e.frame ?? 0];
      if (!n)
        throw new Error(`Frame not found: ${e.frame ?? 0}`);
      Vr({ ...e, tex: t.data.tex, quad: n.scale(e.quad || new j(0, 0, 1, 1)) });
    }
    u(tn, "drawSprite");
    function Xe(e, t, n, s, h, a = 1) {
      s = me(s % 360), h = me(h % 360), h <= s && (h += Math.PI * 2);
      let l = Math.ceil(Math.max(Math.sqrt(t + n) * 3 * (a || 1), 16)), d = (h - s) / l, p = [];
      for (let w = s; w < h; w += d)
        p.push(e.add(t * Math.cos(w), n * Math.sin(w)));
      return p.push(e.add(t * Math.cos(h), n * Math.sin(h))), p;
    }
    u(Xe, "getArcPts");
    function K(e) {
      if (e.width === void 0 || e.height === void 0)
        throw new Error('drawRect() requires property "width" and "height".');
      if (e.width <= 0 || e.height <= 0)
        return;
      let t = e.width, n = e.height, h = tt(e.anchor || mt).add(1, 1).scale(f(t, n).scale(-0.5)), a = [f(0, 0), f(t, 0), f(t, n), f(0, n)];
      if (e.radius) {
        let l = Math.min(Math.min(t, n) / 2, e.radius);
        a = [f(l, 0), f(t - l, 0), ...Xe(f(t - l, l), l, l, 270, 360), f(t, l), f(t, n - l), ...Xe(f(t - l, n - l), l, l, 0, 90), f(t - l, n), f(l, n), ...Xe(f(l, n - l), l, l, 90, 180), f(0, n - l), f(0, l), ...Xe(f(l, l), l, l, 180, 270)];
      }
      ve({ ...e, offset: h, pts: a, ...e.gradient ? { colors: e.horizontal ? [e.gradient[0], e.gradient[1], e.gradient[1], e.gradient[0]] : [e.gradient[0], e.gradient[0], e.gradient[1], e.gradient[1]] } : {} });
    }
    u(K, "drawRect");
    function Ke(e) {
      let { p1: t, p2: n } = e;
      if (!t || !n)
        throw new Error('drawLine() requires properties "p1" and "p2".');
      let s = e.width || 1, h = n.sub(t).unit().normal().scale(s * 0.5), a = [t.sub(h), t.add(h), n.add(h), n.sub(h)].map((l) => ({ pos: ge(l.x, l.y, 0), uv: f(0), color: e.color ?? E.WHITE, opacity: e.opacity ?? 1 }));
      yt(a, [0, 1, 3, 1, 2, 3], e.fixed, m.defTex, e.shader, e.uniform);
    }
    u(Ke, "drawLine");
    function nn(e) {
      let t = e.pts;
      if (!t)
        throw new Error('drawLines() requires property "pts".');
      if (!(t.length < 2))
        if (e.radius && t.length >= 3) {
          let n = t[0].dist(t[1]);
          for (let h = 1; h < t.length - 1; h++)
            n = Math.min(t[h].dist(t[h + 1]), n);
          let s = Math.min(e.radius, n / 2);
          Ke({ ...e, p1: t[0], p2: t[1] });
          for (let h = 1; h < t.length - 2; h++) {
            let a = t[h], l = t[h + 1];
            Ke({ ...e, p1: a, p2: l });
          }
          Ke({ ...e, p1: t[t.length - 2], p2: t[t.length - 1] });
        } else
          for (let n = 0; n < t.length - 1; n++)
            Ke({ ...e, p1: t[n], p2: t[n + 1] }), e.join !== "none" && be({ ...e, pos: t[n], radius: e.width / 2 });
    }
    u(nn, "drawLines");
    function rn(e) {
      if (!e.p1 || !e.p2 || !e.p3)
        throw new Error('drawPolygon() requires properties "p1", "p2" and "p3".');
      return ve({ ...e, pts: [e.p1, e.p2, e.p3] });
    }
    u(rn, "drawTriangle");
    function be(e) {
      if (!e.radius)
        throw new Error('drawCircle() requires property "radius".');
      e.radius !== 0 && sn({ ...e, radiusX: e.radius, radiusY: e.radius, angle: 0 });
    }
    u(be, "drawCircle");
    function sn(e) {
      if (e.radiusX === void 0 || e.radiusY === void 0)
        throw new Error('drawEllipse() requires properties "radiusX" and "radiusY".');
      if (e.radiusX === 0 || e.radiusY === 0)
        return;
      let t = e.start ?? 0, n = e.end ?? 360, s = Xe(f(0), e.radiusX, e.radiusY, t, n, e.resolution);
      s.unshift(f(0));
      let h = { ...e, pts: s, radius: 0, ...e.gradient ? { colors: [e.gradient[0], ...Array(s.length - 1).fill(e.gradient[1])] } : {} };
      if (n - t >= 360 && e.outline) {
        e.fill !== false && ve({ ...h, outline: null }), ve({ ...h, pts: s.slice(1), fill: false });
        return;
      }
      ve(h);
    }
    u(sn, "drawEllipse");
    function ve(e) {
      if (!e.pts)
        throw new Error('drawPolygon() requires property "pts".');
      let t = e.pts.length;
      if (!(t < 3)) {
        if (W(), G(e.pos), Re(e.scale), we(e.angle), G(e.offset), e.fill !== false) {
          let n = e.color ?? E.WHITE, s = e.pts.map((a, l) => ({ pos: ge(a.x, a.y, 0), uv: f(0, 0), color: e.colors ? e.colors[l] ?? n : n, opacity: e.opacity ?? 1 })), h = [...Array(t - 2).keys()].map((a) => [0, a + 1, a + 2]).flat();
          yt(s, e.indices ?? h, e.fixed, m.defTex, e.shader, e.uniform);
        }
        e.outline && nn({ pts: [...e.pts, e.pts[0]], radius: e.radius, width: e.outline.width, color: e.outline.color, join: e.outline.join, uniform: e.uniform, fixed: e.fixed, opacity: e.opacity }), X();
      }
    }
    u(ve, "drawPolygon");
    function on(e, t, n) {
      fe(), c2.clear(c2.STENCIL_BUFFER_BIT), c2.enable(c2.STENCIL_TEST), c2.stencilFunc(c2.NEVER, 1, 255), c2.stencilOp(c2.REPLACE, c2.REPLACE, c2.REPLACE), t(), fe(), c2.stencilFunc(n, 1, 255), c2.stencilOp(c2.KEEP, c2.KEEP, c2.KEEP), e(), fe(), c2.disable(c2.STENCIL_TEST);
    }
    u(on, "drawStenciled");
    function Gr(e, t) {
      on(e, t, c2.EQUAL);
    }
    u(Gr, "drawMasked");
    function Ir(e, t) {
      on(e, t, c2.NOTEQUAL);
    }
    u(Ir, "drawSubtracted");
    function an() {
      return (m.viewport.width + m.viewport.height) / (m.width + m.height);
    }
    u(an, "getViewportScale");
    function ae(e) {
      fe();
      let t = m.width, n = m.height;
      m.width = m.viewport.width, m.height = m.viewport.height, e(), fe(), m.width = t, m.height = n;
    }
    u(ae, "drawUnscaled");
    function un(e, t) {
      t.pos && (e.pos = e.pos.add(t.pos)), t.scale && (e.scale = e.scale.scale(f(t.scale))), t.angle && (e.angle += t.angle), t.color && (e.color = e.color.mult(t.color)), t.opacity && (e.opacity *= t.opacity);
    }
    u(un, "applyCharTransform");
    let cn = /\[(?<text>[^\]]*)\]\.(?<style>[\w\.]+)+/g;
    function Nr(e) {
      let t = {}, n = e.replace(cn, "$1"), s = 0;
      for (let h of e.matchAll(cn)) {
        let a = h.groups.style.split("."), l = h.index - s;
        for (let d = l; d < h.index + h.groups.text.length; d++)
          t[d] = { localIdx: d - l, styles: a };
        s += 3 + h.groups.style.length;
      }
      return { charStyleMap: t, text: n };
    }
    u(Nr, "compileStyledText");
    let Ut = {};
    function ye(e) {
      if (e.text === void 0)
        throw new Error('formatText() requires property "text".');
      let t = Wt(e.font);
      if (e.text === "" || t instanceof O || !t)
        return { width: 0, height: 0, chars: [], opt: e };
      let { charStyleMap: n, text: s } = Nr(e.text + ""), h = s.split("");
      if (t instanceof FontFace || typeof t == "string") {
        let _ = t instanceof FontFace ? t.family : t, S = Ut[_] ?? { font: { tex: new b(gt, gt, { filter: "linear" }), map: {}, size: fr }, cursor: f(0) };
        Ut[_] || (Ut[_] = S), t = S.font;
        for (let N of h)
          if (!S.font.map[N]) {
            let re = o.canvas2.getContext("2d");
            re.font = `${t.size}px ${_}`, re.clearRect(0, 0, o.canvas2.width, o.canvas2.height), re.textBaseline = "top", re.textAlign = "left", re.fillStyle = "rgb(255, 255, 255)", re.fillText(N, 0, 0);
            let We = re.measureText(N), Ge = Math.ceil(We.width), Ie = re.getImageData(0, 0, Ge, t.size);
            if (S.cursor.x + Ge > gt && (S.cursor.x = 0, S.cursor.y += t.size, S.cursor.y > gt))
              throw new Error("Font atlas exceeds character limit");
            t.tex.update(S.cursor.x, S.cursor.y, Ie), t.map[N] = new j(S.cursor.x, S.cursor.y, Ge, t.size), S.cursor.x += Ge;
          }
      }
      let a = e.size || t.size, l = f(e.scale ?? 1).scale(a / t.size), d = e.lineSpacing ?? 0, p = e.letterSpacing ?? 0, w = 0, v = 0, y = 0, B = [], P = [], q = 0, z2 = null, Ee = null;
      for (; q < h.length; ) {
        let _ = h[q];
        if (_ === `
`)
          y += a + d, B.push({ width: w - p, chars: P }), z2 = null, Ee = null, w = 0, P = [];
        else {
          let S = t.map[_];
          if (S) {
            let N = S.w * l.x;
            e.width && w + N > e.width && (y += a + d, z2 != null && (q -= P.length - z2, _ = h[q], S = t.map[_], N = S.w * l.x, P = P.slice(0, z2 - 1), w = Ee), z2 = null, Ee = null, B.push({ width: w - p, chars: P }), w = 0, P = []), P.push({ tex: t.tex, width: S.w, height: S.h, quad: new j(S.x / t.tex.width, S.y / t.tex.height, S.w / t.tex.width, S.h / t.tex.height), ch: _, pos: f(w, y), opacity: e.opacity ?? 1, color: e.color ?? E.WHITE, scale: f(l), angle: 0 }), _ === " " && (z2 = P.length, Ee = w), w += N, v = Math.max(v, w), w += p;
          }
        }
        q++;
      }
      B.push({ width: w - p, chars: P }), y += a, e.width && (v = e.width);
      let J = [];
      for (let _ of B) {
        let S = (v - _.width) * Is(e.align ?? "left");
        for (let N of _.chars) {
          let re = t.map[N.ch], We = J.length, Ge = new D(re.w * l.x * 0.5, re.h * l.y * 0.5);
          if (N.pos = N.pos.add(S, 0).add(Ge), e.transform) {
            let Ie = typeof e.transform == "function" ? e.transform(We, N.ch) : e.transform;
            Ie && un(N, Ie);
          }
          if (n[We]) {
            let { styles: Ie, localIdx: as } = n[We];
            for (let us of Ie) {
              let Mt = e.styles[us], kn = typeof Mt == "function" ? Mt(as, N.ch) : Mt;
              kn && un(N, kn);
            }
          }
          J.push(N);
        }
      }
      return { width: v, height: y, chars: J, opt: e };
    }
    u(ye, "formatText");
    function it(e) {
      Ue(ye(e));
    }
    u(it, "drawText");
    function Ue(e) {
      W(), G(e.opt.pos), we(e.opt.angle), G(tt(e.opt.anchor ?? "topleft").add(1, 1).scale(e.width, e.height).scale(-0.5)), e.chars.forEach((t) => {
        De({ tex: t.tex, width: t.width, height: t.height, pos: t.pos, scale: t.scale, angle: t.angle, color: t.color, opacity: t.opacity, quad: t.quad, anchor: "center", uniform: e.opt.uniform, shader: e.opt.shader, fixed: e.opt.fixed });
      }), X();
    }
    u(Ue, "drawFormattedText");
    function jr() {
      if (o.stretchToParent && !Tt()) {
        let h = o.canvas.parentElement.offsetWidth, a = o.canvas.parentElement.offsetHeight;
        if (h !== o.lastParentWidth || a !== o.lastParentHeight) {
          o.canvas.width = h * o.pixelDensity, o.canvas.height = a * o.pixelDensity, o.canvas.style.width = h + "px", o.canvas.style.height = a + "px";
          let l = k(), d = L();
          g.ev.onOnce("frameEnd", () => {
            g.ev.trigger("resize", l, d, k(), L());
          });
        }
        o.lastParentWidth = h, o.lastParentHeight = a;
      }
      let e = o.pixelDensity, t = c2.drawingBufferWidth / e, n = c2.drawingBufferHeight / e;
      if (Tt()) {
        let h = window.innerWidth, a = window.innerHeight, l = h / a, d = t / n;
        if (l > d) {
          let p = window.innerHeight * d;
          m.viewport = { x: (h - p) / 2, y: 0, width: p, height: a };
        } else {
          let p = window.innerWidth / d;
          m.viewport = { x: 0, y: (a - p) / 2, width: h, height: p };
        }
        return;
      }
      if (i.letterbox) {
        if (!i.width || !i.height)
          throw new Error("Letterboxing requires width and height defined.");
        let h = t / n, a = i.width / i.height;
        if (h > a) {
          i.stretch || (m.width = n * a, m.height = n);
          let l = n * a, d = n, p = (t - l) / 2;
          c2.scissor(p * e, 0, l * e, d * e), c2.viewport(p * e, 0, l * e, n * e), m.viewport = { x: p, y: 0, width: l, height: n };
        } else {
          i.stretch || (m.width = t, m.height = t / a);
          let l = t, d = t / a, p = (n - d) / 2;
          c2.scissor(0, p * e, l * e, d * e), c2.viewport(0, p * e, t * e, d * e), m.viewport = { x: 0, y: p, width: t, height: d };
        }
        return;
      }
      if (i.stretch) {
        if (!i.width || !i.height)
          throw new Error("Stretching requires width and height defined.");
        c2.viewport(0, 0, t * e, n * e), m.viewport = { x: 0, y: 0, width: t, height: n };
        return;
      }
      let s = i.scale ?? 1;
      m.width = t / s, m.height = n / s, c2.viewport(0, 0, t * e, n * e), m.viewport = { x: 0, y: 0, width: t, height: n };
    }
    u(jr, "updateViewport");
    function k() {
      return m.width;
    }
    u(k, "width");
    function L() {
      return m.height;
    }
    u(L, "height");
    let $ = {}, Qe = {}, Me = {};
    function st(e) {
      return f((e.x - m.viewport.x) * k() / m.viewport.width, (e.y - m.viewport.y) * L() / m.viewport.height);
    }
    u(st, "windowToContent");
    function kr(e) {
      return f(e.x * m.viewport.width / m.width, e.y * m.viewport.height / m.height);
    }
    u(kr, "contentToView");
    function xt(e, t) {
      let n = st(f(e, t));
      o.mouseStarted && (o.mouseDeltaPos = n.sub(o.mousePos)), o.mousePos = n, o.mouseStarted = true, o.isMouseMoved = true;
    }
    u(xt, "setMousePos"), $.mousemove = (e) => {
      xt(e.offsetX, e.offsetY);
    }, $.mousedown = (e) => {
      let t = ur[e.button];
      t && (o.mouseStates[t] = "pressed");
    }, $.mouseup = (e) => {
      let t = ur[e.button];
      t && (o.mouseStates[t] = "released");
    }, $.keydown = (e) => {
      let t = ar[e.key] || e.key.toLowerCase();
      Es.includes(t) && e.preventDefault(), t.length === 1 && o.charInputted.push(e.key), t === "space" && o.charInputted.push(" "), e.repeat ? (o.isKeyPressedRepeat = true, o.keyStates[t] = "rpressed") : (o.isKeyPressed = true, o.keyStates[t] = "pressed"), o.numKeyDown++;
    }, $.keyup = (e) => {
      let t = ar[e.key] || e.key.toLowerCase();
      o.keyStates[t] = "released", o.isKeyReleased = true, o.numKeyDown--;
    }, $.touchstart = (e) => {
      e.preventDefault();
      let t = [...e.changedTouches];
      t.forEach((n) => {
        g.ev.trigger("onTouchStart", st(f(n.clientX, n.clientY)), n);
      }), i.touchToMouse !== false && (xt(t[0].clientX, t[0].clientY), o.mouseStates.left = "pressed");
    }, $.touchmove = (e) => {
      e.preventDefault();
      let t = [...e.changedTouches];
      t.forEach((n) => {
        g.ev.trigger("onTouchMove", st(f(n.clientX, n.clientY)), n);
      }), i.touchToMouse !== false && xt(t[0].clientX, t[0].clientY);
    }, $.touchend = (e) => {
      [...e.changedTouches].forEach((n) => {
        g.ev.trigger("onTouchEnd", st(f(n.clientX, n.clientY)), n);
      }), i.touchToMouse !== false && (o.mouseStates.left = "released");
    }, $.touchcancel = () => {
      i.touchToMouse !== false && (o.mouseStates.left = "released");
    }, $.contextmenu = function(e) {
      e.preventDefault();
    }, Qe.visibilitychange = () => {
      switch (document.visibilityState) {
        case "visible":
          o.skipTime = true, F.paused || T.ctx.resume();
          break;
        case "hidden":
          T.ctx.suspend();
          break;
      }
    }, Me.error = (e) => {
      e.error ? Dt(e.error) : Dt(new Error(e.message));
    }, Me.unhandledrejection = (e) => Dt(e.reason);
    for (let e in $)
      o.canvas.addEventListener(e, $[e]);
    for (let e in Qe)
      document.addEventListener(e, Qe[e]);
    for (let e in Me)
      window.addEventListener(e, Me[e]);
    function ee() {
      return o.mousePos.clone();
    }
    u(ee, "mousePos");
    function ln() {
      return o.mouseDeltaPos.clone();
    }
    u(ln, "mouseDeltaPos");
    function Fe(e = "left") {
      return o.mouseStates[e] === "pressed";
    }
    u(Fe, "isMousePressed");
    function Et(e = "left") {
      return o.mouseStates[e] === "pressed" || o.mouseStates[e] === "down";
    }
    u(Et, "isMouseDown");
    function Je(e = "left") {
      return o.mouseStates[e] === "released";
    }
    u(Je, "isMouseReleased");
    function hn() {
      return o.isMouseMoved;
    }
    u(hn, "isMouseMoved");
    function ot(e) {
      return e === void 0 ? o.isKeyPressed : o.keyStates[e] === "pressed";
    }
    u(ot, "isKeyPressed");
    function dn(e) {
      return e === void 0 ? o.isKeyPressedRepeat : o.keyStates[e] === "pressed" || o.keyStates[e] === "rpressed";
    }
    u(dn, "isKeyPressedRepeat");
    function fn(e) {
      return e === void 0 ? o.numKeyDown > 0 : o.keyStates[e] === "pressed" || o.keyStates[e] === "rpressed" || o.keyStates[e] === "down";
    }
    u(fn, "isKeyDown");
    function St(e) {
      return e === void 0 ? o.isKeyReleased : o.keyStates[e] === "released";
    }
    u(St, "isKeyReleased");
    function mn(e) {
      return o.virtualButtonStates[e] === "pressed";
    }
    u(mn, "isVirtualButtonPressed");
    function pn(e) {
      return o.virtualButtonStates[e] === "pressed" || o.virtualButtonStates[e] === "down";
    }
    u(pn, "isVirtualButtonDown");
    function gn(e) {
      return o.virtualButtonStates[e] === "released";
    }
    u(gn, "isVirtualButtonReleased");
    function _r() {
      return [...o.charInputted];
    }
    u(_r, "charInputted");
    function Ct() {
      return o.time;
    }
    u(Ct, "time");
    function qr() {
      return o.canvas.toDataURL();
    }
    u(qr, "screenshot");
    function wn(e) {
      return e && (o.canvas.style.cursor = e), o.canvas.style.cursor;
    }
    u(wn, "setCursor");
    function zr(e = true) {
      e ? Bs(o.canvas) : Vs();
    }
    u(zr, "setFullscreen");
    function Tt() {
      return Boolean(Gs());
    }
    u(Tt, "isFullscreen");
    function bn() {
      return o.isTouchScreen;
    }
    u(bn, "isTouchScreen");
    let F = { inspect: false, timeScale: 1, showLog: true, fps: () => o.fpsCounter.fps, numFrames: () => o.numFrames, stepFrame: In, drawCalls: () => m.drawCalls, clearLog: () => g.logs = [], log: (e) => {
      let t = i.logMax ?? Rs;
      g.logs.unshift(`${`[${Ct().toFixed(2)}].time `}[${e?.toString ? e.toString() : e}].${e instanceof Error ? "error" : "info"}`), g.logs.length > t && (g.logs = g.logs.slice(0, t));
    }, error: (e) => F.log(new Error(e.toString ? e.toString() : e)), curRecording: null, get paused() {
      return o.paused;
    }, set paused(e) {
      o.paused = e, e ? T.ctx.suspend() : T.ctx.resume();
    } };
    function Q() {
      return o.dt * F.timeScale;
    }
    u(Q, "dt");
    function Hr(...e) {
      return e.length > 0 && (g.cam.pos = f(...e)), g.cam.pos ? g.cam.pos.clone() : lt();
    }
    u(Hr, "camPos");
    function $r(...e) {
      return e.length > 0 && (g.cam.scale = f(...e)), g.cam.scale.clone();
    }
    u($r, "camScale");
    function Yr(e) {
      return e !== void 0 && (g.cam.angle = e), g.cam.angle;
    }
    u(Yr, "camRot");
    function Xr(e = 12) {
      g.cam.shake = e;
    }
    u(Xr, "shake");
    function At(e) {
      return g.cam.transform.multVec2(e);
    }
    u(At, "toScreen");
    function vn(e) {
      return g.cam.transform.invert().multVec2(e);
    }
    u(vn, "toWorld");
    function yn(e) {
      let t = new A();
      return e.pos && (t = t.translate(e.pos)), e.scale && (t = t.scale(e.scale)), e.angle && (t = t.rotateZ(e.angle)), e.parent ? t.mult(e.parent.transform) : t;
    }
    u(yn, "calcTransform");
    function Un(e) {
      let t = /* @__PURE__ */ new Map(), n = {}, s = new le(), h = { id: nr(), hidden: false, paused: false, transform: new A(), children: [], parent: null, add(a) {
        let l = (() => {
          if (Array.isArray(a))
            return Un(a);
          if (a.parent)
            throw new Error("Cannot add a game obj that already has a parent.");
          return a;
        })();
        return l.parent = this, l.transform = yn(l), this.children.push(l), l.trigger("add", this), g.ev.trigger("add", this), l;
      }, readd(a) {
        let l = this.children.indexOf(a);
        return l !== -1 && (this.children.splice(l, 1), this.children.push(a)), a;
      }, remove(a) {
        let l = this.children.indexOf(a);
        l !== -1 && (a.parent = null, a.trigger("destroy"), g.ev.trigger("destroy", a), this.children.splice(l, 1));
      }, removeAll(a) {
        this.get(a).forEach((l) => this.remove(l));
      }, update() {
        this.paused || (this.get().forEach((a) => a.update()), this.trigger("update"));
      }, draw() {
        this.hidden || (W(), G(this.pos), Re(this.scale), we(this.angle), this.trigger("draw"), this.get().forEach((a) => a.draw()), X());
      }, drawInspect() {
        this.hidden || (W(), G(this.pos), Re(this.scale), we(this.angle), this.get().forEach((a) => a.drawInspect()), this.trigger("drawInspect"), X());
      }, use(a) {
        if (!a)
          return;
        if (typeof a == "string")
          return this.use({ id: a });
        a.id && (this.unuse(a.id), t.set(a.id, { cleanups: [] }));
        let l = a.id ? t.get(a.id) : n, d = a.id ? l.cleanups : [], p = u(() => {
          if (a.require) {
            for (let w of a.require)
              if (!this.c(w))
                throw new Error(`Component "${a.id}" requires component "${w}"`);
          }
        }, "checkDeps");
        a.destroy && d.push(a.destroy), a.require && !this.exists() && l.cleanups && d.push(this.on("add", p));
        for (let w in a)
          if (!Fs.has(w)) {
            if (typeof a[w] == "function") {
              let v = a[w].bind(this);
              if (Ls.has(w)) {
                d.push(this.on(w, v)), l[w] = v;
                continue;
              } else
                l[w] = v;
            } else
              l[w] = a[w];
            if (this[w] === void 0)
              Object.defineProperty(this, w, { get: () => l[w], set: (v) => l[w] = v, configurable: true, enumerable: true });
            else
              throw new Error(`Duplicate component property: "${w}"`);
          }
        this.exists() && (p(), a.add && a.add.call(this));
      }, unuse(a) {
        if (t.has(a)) {
          let l = t.get(a);
          l.cleanups.forEach((d) => d());
          for (let d in l)
            delete l[d];
        }
        t.delete(a);
      }, c(a) {
        return t.get(a);
      }, get(a) {
        return this.children.filter((l) => a ? l.is(a) : true).sort((l, d) => (l.z ?? 0) - (d.z ?? 0));
      }, getAll(a) {
        return this.children.sort((l, d) => (l.z ?? 0) - (d.z ?? 0)).flatMap((l) => [l, ...l.getAll(a)]).filter((l) => a ? l.is(a) : true);
      }, isAncestorOf(a) {
        return a.parent ? a.parent === this || this.isAncestorOf(a.parent) : false;
      }, exists() {
        return g.root.isAncestorOf(this);
      }, is(a) {
        if (a === "*")
          return true;
        if (Array.isArray(a)) {
          for (let l of a)
            if (!this.c(l))
              return false;
          return true;
        } else
          return this.c(a) != null;
      }, on(a, l) {
        return s.on(a, l.bind(this));
      }, trigger(a, ...l) {
        s.trigger(a, ...l), g.objEvents.trigger(a, this, ...l);
      }, destroy() {
        this.parent && this.parent.remove(this);
      }, inspect() {
        let a = {};
        for (let [l, d] of t)
          a[l] = d.inspect ? d.inspect() : null;
        return a;
      }, onAdd(a) {
        return this.on("add", a);
      }, onUpdate(a) {
        return this.on("update", a);
      }, onDraw(a) {
        return this.on("draw", a);
      }, onDestroy(a) {
        return this.on("destroy", a);
      }, clearEvents() {
        s.clear();
      } };
      for (let a of e)
        h.use(a);
      return h;
    }
    u(Un, "make");
    function Le(e, t, n) {
      return g.objEvents[e] || (g.objEvents[e] = new ce()), g.objEvents.on(e, (s, ...h) => {
        s.is(t) && n(s, ...h);
      });
    }
    u(Le, "on");
    function xn(e, t) {
      if (typeof e == "function" && t === void 0) {
        let n = xe([{ update: e }]);
        return () => n.destroy();
      } else if (typeof e == "string")
        return Le("update", e, t);
    }
    u(xn, "onUpdate");
    function Kr(e, t) {
      if (typeof e == "function" && t === void 0) {
        let n = xe([{ draw: e }]);
        return () => n.destroy();
      } else if (typeof e == "string")
        return Le("draw", e, t);
    }
    u(Kr, "onDraw");
    function En(e, t) {
      if (typeof e == "function" && t === void 0) {
        let n = xe([{ draw: e }]);
        return () => n.destroy();
      } else if (typeof e == "string")
        return Le("add", e, t);
    }
    u(En, "onAdd");
    function Qr(e, t) {
      if (typeof e == "function" && t === void 0) {
        let n = xe([{ draw: e }]);
        return () => n.destroy();
      } else if (typeof e == "string")
        return Le("destroy", e, t);
    }
    u(Qr, "onDestroy");
    function Jr(e, t, n) {
      return Le("collide", e, (s, h, a) => h.is(t) && n(s, h, a));
    }
    u(Jr, "onCollide");
    function at(e, t) {
      Bn(e).forEach(t), En(e, t);
    }
    u(at, "forAllCurrentAndFuture");
    function Zr(e, t) {
      if (typeof e == "function")
        return On(e);
      {
        let n = [];
        return at(e, (s) => {
          if (!s.area)
            throw new Error("onClick() requires the object to have area() component");
          n.push(s.onClick(() => t(s)));
        }), () => n.forEach((s) => s());
      }
    }
    u(Zr, "onClick");
    function Wr(e, t) {
      let n = [];
      return at(e, (s) => {
        if (!s.area)
          throw new Error("onHover() requires the object to have area() component");
        n.push(s.onHover(() => t(s)));
      }), () => n.forEach((s) => s());
    }
    u(Wr, "onHover");
    function ei(e, t) {
      let n = [];
      return at(e, (s) => {
        if (!s.area)
          throw new Error("onHoverUpdate() requires the object to have area() component");
        n.push(s.onHoverUpdate(() => t(s)));
      }), () => n.forEach((s) => s());
    }
    u(ei, "onHoverUpdate");
    function ti(e, t) {
      let n = [];
      return at(e, (s) => {
        if (!s.area)
          throw new Error("onHoverEnd() requires the object to have area() component");
        n.push(s.onHoverEnd(() => t(s)));
      }), () => n.forEach((s) => s());
    }
    u(ti, "onHoverEnd");
    function Sn(e, t) {
      return new Promise((n) => {
        g.timers.push(new he(e, () => {
          t && t(), n();
        }));
      });
    }
    u(Sn, "wait");
    function ni(e, t) {
      let n = false, s = u(() => {
        n || (t(), Sn(e, s));
      }, "newF");
      return s(), () => n = true;
    }
    u(ni, "loop");
    function Cn(e, t) {
      if (Array.isArray(e)) {
        let n = e.map((s) => Cn(s, t));
        return () => n.forEach((s) => s());
      }
      return g.ev.on("input", () => fn(e) && t());
    }
    u(Cn, "onKeyDown");
    function ue(e, t) {
      if (Array.isArray(e)) {
        let n = e.map((s) => ue(s, t));
        return () => n.forEach((s) => s());
      } else
        return typeof e == "function" ? g.ev.on("input", () => ot() && e()) : g.ev.on("input", () => ot(e) && t());
    }
    u(ue, "onKeyPress");
    function Tn(e, t) {
      if (Array.isArray(e)) {
        let n = e.map((s) => Tn(s, t));
        return () => n.forEach((s) => s());
      } else
        return typeof e == "function" ? g.ev.on("input", () => ot() && e()) : g.ev.on("input", () => dn(e) && t());
    }
    u(Tn, "onKeyPressRepeat");
    function An(e, t) {
      if (Array.isArray(e)) {
        let n = e.map((s) => An(s, t));
        return () => n.forEach((s) => s());
      } else
        return typeof e == "function" ? g.ev.on("input", () => St() && e()) : g.ev.on("input", () => St(e) && t());
    }
    u(An, "onKeyRelease");
    function ri(e, t) {
      return typeof e == "function" ? g.ev.on("input", () => Et() && e(ee())) : g.ev.on("input", () => Et(e) && t(ee()));
    }
    u(ri, "onMouseDown");
    function On(e, t) {
      return typeof e == "function" ? g.ev.on("input", () => Fe() && e(ee())) : g.ev.on("input", () => Fe(e) && t(ee()));
    }
    u(On, "onMousePress");
    function ii(e, t) {
      return typeof e == "function" ? g.ev.on("input", () => Je() && e(ee())) : g.ev.on("input", () => Je(e) && t(ee()));
    }
    u(ii, "onMouseRelease");
    function si(e) {
      return g.ev.on("input", () => hn() && e(ee(), ln()));
    }
    u(si, "onMouseMove");
    function oi(e) {
      return g.ev.on("input", () => _r().forEach((t) => e(t)));
    }
    u(oi, "onCharInput");
    function ai(e) {
      return g.ev.on("onTouchStart", e);
    }
    u(ai, "onTouchStart");
    function ui(e) {
      return g.ev.on("onTouchMove", e);
    }
    u(ui, "onTouchMove");
    function ci(e) {
      return g.ev.on("onTouchEnd", e);
    }
    u(ci, "onTouchEnd");
    function li(e, t) {
      return g.ev.on("input", () => mn(e) && t());
    }
    u(li, "onVirtualButtonPress");
    function hi(e, t) {
      return g.ev.on("input", () => pn(e) && t());
    }
    u(hi, "onVirtualButtonDown");
    function di(e, t) {
      return g.ev.on("input", () => gn(e) && t());
    }
    u(di, "onVirtualButtonRelease");
    function Pn() {
      ue("f1", () => {
        F.inspect = !F.inspect;
      }), ue("f2", () => {
        F.clearLog();
      }), ue("f8", () => {
        F.paused = !F.paused;
      }), ue("f7", () => {
        F.timeScale = Be(te(F.timeScale - 0.2, 0, 2), 1);
      }), ue("f9", () => {
        F.timeScale = Be(te(F.timeScale + 0.2, 0, 2), 1);
      }), ue("f10", () => {
        F.stepFrame();
      });
    }
    u(Pn, "enterDebugMode");
    function Rn() {
      ue("b", en);
    }
    u(Rn, "enterBurpMode");
    function fi(e) {
      return e !== void 0 && (g.gravity = e), g.gravity;
    }
    u(fi, "gravity");
    function ut(...e) {
      return { id: "pos", pos: f(...e), moveBy(...t) {
        this.pos = this.pos.add(f(...t));
      }, move(...t) {
        this.moveBy(f(...t).scale(Q()));
      }, moveTo(...t) {
        if (typeof t[0] == "number" && typeof t[1] == "number")
          return this.moveTo(f(t[0], t[1]), t[2]);
        let n = t[0], s = t[1];
        if (s === void 0) {
          this.pos = f(n);
          return;
        }
        let h = n.sub(this.pos);
        if (h.len() <= s * Q()) {
          this.pos = f(n);
          return;
        }
        this.move(h.unit().scale(s));
      }, worldPos() {
        return this.parent ? this.parent.transform.multVec2(this.pos) : this.pos;
      }, screenPos() {
        return this.fixed ? this.pos : At(this.pos);
      }, inspect() {
        return `(${Math.round(this.pos.x)}, ${Math.round(this.pos.y)})`;
      }, drawInspect() {
        be({ color: x(255, 0, 0), radius: 4 / an() });
      } };
    }
    u(ut, "pos");
    function ct(...e) {
      return e.length === 0 ? ct(1) : { id: "scale", scale: f(...e), scaleTo(...t) {
        this.scale = f(...t);
      }, inspect() {
        return typeof this.scale == "number" ? `${Be(this.scale, 2)}` : `(${Be(this.scale.x, 2)}, ${Be(this.scale.y, 2)})`;
      } };
    }
    u(ct, "scale");
    function mi(e) {
      return { id: "rotate", angle: e ?? 0, rotate(t) {
        this.rotateBy(t * Q());
      }, rotateBy(t) {
        this.angle += t;
      }, inspect() {
        return `${Math.round(this.angle)}`;
      } };
    }
    u(mi, "rotate");
    function pi(...e) {
      return { id: "color", color: x(...e), inspect() {
        return this.color.toString();
      } };
    }
    u(pi, "color");
    function Be(e, t) {
      return Number(e.toFixed(t));
    }
    u(Be, "toFixed");
    function gi(e) {
      return { id: "opacity", opacity: e ?? 1, inspect() {
        return `${Be(this.opacity, 2)}`;
      } };
    }
    u(gi, "opacity");
    function Ot(e) {
      if (!e)
        throw new Error("Please define an anchor");
      return { id: "anchor", anchor: e, inspect() {
        return typeof this.anchor == "string" ? this.anchor : this.anchor.toString();
      } };
    }
    u(Ot, "anchor");
    function wi(e) {
      return { id: "z", z: e, inspect() {
        return `${this.z}`;
      } };
    }
    u(wi, "z");
    function bi(e, t) {
      return { id: "follow", require: ["pos"], follow: { obj: e, offset: t ?? f(0) }, add() {
        e.exists() && (this.pos = this.follow.obj.pos.add(this.follow.offset));
      }, update() {
        e.exists() && (this.pos = this.follow.obj.pos.add(this.follow.offset));
      } };
    }
    u(bi, "follow");
    function vi(e, t) {
      let n = typeof e == "number" ? D.fromAngle(e) : e.unit();
      return { id: "move", require: ["pos"], update() {
        this.move(n.scale(t));
      } };
    }
    u(vi, "move");
    function yi(e = {}) {
      let t = e.distance ?? 64, n = false;
      return { id: "outview", require: ["pos"], isOutOfView() {
        let s = At(this.pos), h = new I(f(0), k(), L());
        return !He(h, s) && h.distToPoint(s) > t;
      }, onExitView(s) {
        return this.on("exitView", s);
      }, onEnterView(s) {
        return this.on("enterView", s);
      }, update() {
        this.isOutOfView() ? (n || (this.trigger("exitView"), n = true), e.hide && (this.hidden = true), e.pause && (this.paused = true), e.destroy && this.destroy()) : (n && (this.trigger("enterView"), n = false), e.hide && (this.hidden = false), e.pause && (this.paused = false));
      }, inspect() {
        return `${this.isOutOfView()}`;
      } };
    }
    u(yi, "outview");
    function Ui(e = {}) {
      let t = [];
      return { id: "area", colliding: {}, collisionIgnore: e.collisionIgnore ?? [], add() {
        this.area.cursor && t.push(this.onHover(() => wn(this.area.cursor))), t.push(this.onCollideUpdate((n, s) => {
          this.colliding[n.id] || this.trigger("collide", n, s), this.colliding[n.id] = s;
        }));
      }, update() {
        for (let n in this.colliding) {
          let s = this.colliding[n];
          this.checkCollision(s.target) || (delete this.colliding[n], this.trigger("collideEnd", s.target, s));
        }
      }, drawInspect() {
        let n = this.localArea();
        W(), Re(this.area.scale), G(this.area.offset);
        let s = { outline: { width: 4 / an(), color: x(0, 0, 255) }, anchor: this.anchor, fill: false, fixed: this.fixed };
        n instanceof I ? K({ ...s, pos: n.pos, width: n.width, height: n.height }) : n instanceof oe ? ve({ ...s, pts: n.pts }) : n instanceof pe && be({ ...s, pos: n.center, radius: n.radius }), X();
      }, destroy() {
        t.forEach((n) => n());
      }, area: { shape: e.shape ?? null, scale: e.scale ?? f(1), offset: e.offset ?? f(0), cursor: e.cursor ?? null }, isClicked() {
        return Fe() && this.isHovering();
      }, isHovering() {
        let n = this.fixed ? ee() : vn(ee());
        return this.hasPoint(n);
      }, checkCollision(n) {
        if (this === n || !n.area || !n.exists())
          return null;
        let s = this.worldArea(), h = n.worldArea();
        return Wn(s, h);
      }, isColliding(n) {
        let s = this.checkCollision(n);
        return s && !s.isZero();
      }, isTouching(n) {
        return Boolean(this.checkCollision(n));
      }, onClick(n) {
        return this.onUpdate(() => {
          this.isClicked() && n();
        });
      }, onHover(n) {
        let s = false;
        return this.onUpdate(() => {
          s ? s = this.isHovering() : this.isHovering() && (s = true, n());
        });
      }, onHoverUpdate(n) {
        return this.onUpdate(() => {
          this.isHovering() && n();
        });
      }, onHoverEnd(n) {
        let s = false;
        return this.onUpdate(() => {
          s ? this.isHovering() || (s = false, n()) : s = this.isHovering();
        });
      }, onCollide(n, s) {
        if (typeof n == "function" && s === void 0)
          return this.on("collide", n);
        if (typeof n == "string")
          return this.onCollide((h, a) => {
            h.is(n) && s(h, a);
          });
      }, onCollideUpdate(n, s) {
        if (typeof n == "function" && s === void 0)
          return this.on("collideUpdate", n);
        if (typeof n == "string")
          return this.on("collideUpdate", (h, a) => h.is(n) && s(h, a));
      }, onCollideEnd(n, s) {
        if (typeof n == "function" && s === void 0)
          return this.on("collideEnd", n);
        if (typeof n == "string")
          return this.on("collideEnd", (h) => h.is(n) && s(h));
      }, hasPoint(n) {
        return Zn(this.worldArea(), n);
      }, pushOut(n) {
        let s = this.checkCollision(n);
        s && (this.pos = this.pos.add(s));
      }, pushOutAll() {
        g.root.getAll().forEach(this.pushOut);
      }, localArea() {
        return this.area.shape ? this.area.shape : this.renderArea();
      }, worldArea() {
        let n = this.localArea();
        if (!(n instanceof oe || n instanceof I))
          throw new Error("Only support polygon and rect shapes for now");
        let s = this.transform.scale(f(this.area.scale ?? 1)).translate(this.area.offset);
        if (n instanceof I) {
          let h = n.bbox(), a = tt(this.anchor || mt).add(1, 1).scale(-0.5).scale(h.width, h.height);
          s = s.translate(a);
        }
        return n.transform(s);
      }, screenArea() {
        let n = this.worldArea();
        return this.fixed ? n : n.transform(g.cam.transform);
      } };
    }
    u(Ui, "area");
    function Ze(e) {
      return { color: e.color, opacity: e.opacity, anchor: e.anchor, outline: e.outline, fixed: e.fixed, shader: e.shader, uniform: e.uniform };
    }
    u(Ze, "getRenderProps");
    function Pt(e, t = {}) {
      let n = null, s = null;
      if (!e)
        throw new Error("Please pass the resource name or data to sprite()");
      let h = u((a, l, d, p) => {
        let w = f(1, 1);
        return d && p ? (w.x = d / (a.width * l.w), w.y = p / (a.height * l.h)) : d ? (w.x = d / (a.width * l.w), w.y = w.x) : p && (w.y = p / (a.height * l.h), w.x = w.y), w;
      }, "calcTexScale");
      return { id: "sprite", width: 0, height: 0, frame: t.frame || 0, quad: t.quad || new j(0, 0, 1, 1), animSpeed: t.animSpeed ?? 1, draw() {
        !n || tn({ ...Ze(this), sprite: n, frame: this.frame, quad: this.quad, flipX: t.flipX, flipY: t.flipY, tiled: t.tiled, width: t.width, height: t.height });
      }, update() {
        if (!n) {
          let l = Zt(e);
          if (!l || !l.data)
            return;
          let d = l.data.frames[0].clone();
          t.quad && (d = d.scale(t.quad));
          let p = h(l.data.tex, d, t.width, t.height);
          this.width = l.data.tex.width * d.w * p.x, this.height = l.data.tex.height * d.h * p.y, t.anim && this.play(t.anim), n = l.data, this.trigger("spriteLoaded", n);
        }
        if (!s)
          return;
        let a = n.anims[s.name];
        if (typeof a == "number") {
          this.frame = a;
          return;
        }
        if (a.speed === 0)
          throw new Error("Sprite anim speed cannot be 0");
        s.timer += Q() * this.animSpeed, s.timer >= 1 / s.speed && (s.timer = 0, a.from > a.to ? (this.frame--, this.frame < a.to && (s.loop ? this.frame = a.from : (this.frame++, s.onEnd(), this.stop()))) : (this.frame++, this.frame > a.to && (s.loop ? this.frame = a.from : (this.frame--, s.onEnd(), this.stop()))));
      }, play(a, l = {}) {
        if (!n) {
          this.on("spriteLoaded", () => {
            this.play(a, l);
          });
          return;
        }
        let d = n.anims[a];
        if (!d)
          throw new Error(`Anim not found: ${a}`);
        s && this.stop(), s = typeof d == "number" ? { name: a, timer: 0, loop: false, pingpong: false, speed: 0, onEnd: () => {
        } } : { name: a, timer: 0, loop: l.loop ?? d.loop ?? false, pingpong: l.pingpong ?? d.pingpong ?? false, speed: l.speed ?? d.speed ?? 10, onEnd: l.onEnd ?? (() => {
        }) }, this.frame = typeof d == "number" ? d : d.from, this.trigger("animStart", a);
      }, stop() {
        if (!s)
          return;
        let a = s.name;
        s = null, this.trigger("animEnd", a);
      }, numFrames() {
        return n ? n.frames.length : 0;
      }, curAnim() {
        return s?.name;
      }, flipX(a) {
        t.flipX = a;
      }, flipY(a) {
        t.flipY = a;
      }, onAnimEnd(a, l) {
        return this.on("animEnd", (d) => {
          d === a && l();
        });
      }, onAnimStart(a, l) {
        return this.on("animStart", (d) => {
          d === a && l();
        });
      }, renderArea() {
        return new I(f(0), this.width, this.height);
      }, inspect() {
        if (typeof e == "string")
          return `"${e}"`;
      } };
    }
    u(Pt, "sprite");
    function xi(e, t = {}) {
      function n(s) {
        let h = ye({ ...Ze(s), text: s.text + "", size: s.textSize, font: s.font, width: t.width && s.width, align: s.align, letterSpacing: s.letterSpacing, lineSpacing: s.lineSpacing, transform: s.textTransform, styles: s.textStyles });
        return t.width || (s.width = h.width / (s.scale?.x || 1)), s.height = h.height / (s.scale?.y || 1), h;
      }
      return u(n, "update"), { id: "text", text: e, textSize: t.size ?? Ps, font: t.font, width: t.width, height: 0, align: t.align, lineSpacing: t.lineSpacing, letterSpacing: t.letterSpacing, textTransform: t.transform, textStyles: t.styles, add() {
        Rt(() => n(this));
      }, draw() {
        Ue(n(this));
      }, renderArea() {
        return new I(f(0), this.width, this.height);
      } };
    }
    u(xi, "text");
    function Ei(e, t, n = {}) {
      return { id: "rect", width: e, height: t, radius: n.radius || 0, draw() {
        K({ ...Ze(this), width: this.width, height: this.height, radius: this.radius });
      }, renderArea() {
        return new I(f(0), this.width, this.height);
      }, inspect() {
        return `${Math.ceil(this.width)}, ${Math.ceil(this.height)}`;
      } };
    }
    u(Ei, "rect");
    function Si(e, t) {
      return { id: "rect", width: e, height: t, draw() {
        De({ ...Ze(this), width: this.width, height: this.height });
      }, renderArea() {
        return new I(f(0), this.width, this.height);
      }, inspect() {
        return `${Math.ceil(this.width)}, ${Math.ceil(this.height)}`;
      } };
    }
    u(Si, "uvquad");
    function Ci(e) {
      return { id: "circle", radius: e, draw() {
        be({ ...Ze(this), radius: this.radius });
      }, renderArea() {
        return new pe(f(0), this.radius);
      }, inspect() {
        return `${Math.ceil(this.radius)}`;
      } };
    }
    u(Ci, "circle");
    function Ti(e = 1, t = x(0, 0, 0)) {
      return { id: "outline", outline: { width: e, color: t } };
    }
    u(Ti, "outline");
    function Dn(e, t) {
      let n = new ce();
      return e && t && n.pushd(new he(e, t)), { id: "timer", wait(s, h) {
        return n.pushd(new he(s, h));
      }, update() {
        n.forEach((s, h) => {
          s.tick(Q()) && n.delete(h);
        });
      } };
    }
    u(Dn, "timer");
    let Ai = 640, Oi = 65536;
    function Pi(e = {}) {
      let t = 0, n = null, s = null, h = false, a = [];
      return { id: "body", require: ["pos", "area"], jumpForce: e.jumpForce ?? Ai, gravityScale: e.gravityScale ?? 1, isStatic: e.isStatic ?? false, mass: e.mass ?? 0, add() {
        a.push(this.onCollideUpdate((l, d) => {
          if (!l.is("body") || d.resolved || this.isStatic && l.isStatic)
            return;
          let p = !this.isStatic && l.isStatic ? d : d.reverse();
          p.source.trigger("beforePhysicsResolve", p), p.target.trigger("beforePhysicsResolve", p.reverse()), !d.resolved && (p.source.pos = p.source.pos.add(p.displacement), p.source.transform = yn(p.source), d.resolved = true, p.source.trigger("physicsResolve", p), p.target.trigger("physicsResolve", p.reverse()));
        })), a.push(this.onPhysicsResolve((l) => {
          g.gravity && (l.isBottom() && this.isFalling() ? (t = 0, n = l.target, s = l.target.pos, h ? h = false : this.trigger("ground", n)) : l.isTop() && this.isJumping() && (t = 0, this.trigger("headbutt", l.target)));
        }));
      }, update() {
        if (!g.gravity || this.isStatic)
          return;
        if (h && (n = null, s = null, this.trigger("fallOff"), h = false), n)
          if (!this.isTouching(n) || !n.exists() || !n.is("body"))
            h = true;
          else {
            !n.pos.eq(s) && e.stickToPlatform !== false && this.moveBy(n.pos.sub(s)), s = n.pos;
            return;
          }
        let l = t;
        t += g.gravity * this.gravityScale * Q(), t = Math.min(t, e.maxVelocity ?? Oi), l < 0 && t >= 0 && this.trigger("fall"), this.move(0, t);
      }, destroy() {
        a.forEach((l) => l());
      }, onPhysicsResolve(l) {
        return this.on("physicsResolve", l);
      }, onBeforePhysicsResolve(l) {
        return this.on("beforePhysicsResolve", l);
      }, curPlatform() {
        return n;
      }, isGrounded() {
        return n !== null;
      }, isFalling() {
        return t > 0;
      }, isJumping() {
        return t < 0;
      }, jump(l) {
        n = null, s = null, t = -l || -this.jumpForce;
      }, onGround(l) {
        return this.on("ground", l);
      }, onFall(l) {
        return this.on("fall", l);
      }, onFallOff(l) {
        return this.on("fallOff", l);
      }, onHeadbutt(l) {
        return this.on("headbutt", l);
      }, inspect() {
        return `${this.isGrounded() ? "grounded" : this.isJumping() ? "jumping" : "falling"}`;
      } };
    }
    u(Pi, "body");
    function Ri(e = 2) {
      let t = e, n = [];
      return { id: "doubleJump", require: ["body"], numJumps: e, add() {
        n.push(this.onGround(() => {
          t = this.numJumps;
        }));
      }, destroy() {
        n.forEach((s) => s());
      }, doubleJump(s) {
        t <= 0 || (t < this.numJumps && this.trigger("doubleJump"), t--, this.jump(s));
      }, onDoubleJump(s) {
        return this.on("doubleJump", s);
      }, inspect() {
        return `${t}`;
      } };
    }
    u(Ri, "doubleJump");
    function Di(e, t = {}) {
      return { id: "shader", shader: e, uniform: t };
    }
    u(Di, "shader");
    function Mi() {
      return { id: "fixed", fixed: true };
    }
    u(Mi, "fixed");
    function Mn() {
      return { id: "stay", stay: true };
    }
    u(Mn, "stay");
    function Fi(e) {
      if (e == null)
        throw new Error("health() requires the initial amount of hp");
      return { id: "health", hurt(t = 1) {
        this.setHP(e - t), this.trigger("hurt");
      }, heal(t = 1) {
        this.setHP(e + t), this.trigger("heal");
      }, hp() {
        return e;
      }, setHP(t) {
        e = t, e <= 0 && this.trigger("death");
      }, onHurt(t) {
        return this.on("hurt", t);
      }, onHeal(t) {
        return this.on("heal", t);
      }, onDeath(t) {
        return this.on("death", t);
      }, inspect() {
        return `${e}`;
      } };
    }
    u(Fi, "health");
    function Li(e, t = {}) {
      if (e == null)
        throw new Error("lifespan() requires time");
      let n = 0, s = null, h = t.fade ?? 0, a = Math.max(e - h, 0);
      return { id: "lifespan", update() {
        n += Q(), n >= a && (s === null && (s = this.opacity ?? 1), this.opacity = dt(n, a, e, s, 0)), n >= e && this.destroy();
      } };
    }
    u(Li, "lifespan");
    function Bi(e, t, n) {
      if (!e)
        throw new Error("state() requires an initial state");
      let s = {};
      function h(p) {
        s[p] || (s[p] = { enter: new ne(), end: new ne(), update: new ne(), draw: new ne() });
      }
      u(h, "initStateEvents");
      function a(p, w, v) {
        return h(w), s[w][p].add(v);
      }
      u(a, "on");
      function l(p, w, ...v) {
        h(w), s[w][p].trigger(...v);
      }
      u(l, "trigger");
      let d = false;
      return { id: "state", state: e, enterState(p, ...w) {
        if (d = true, t && !t.includes(p))
          throw new Error(`State not found: ${p}`);
        let v = this.state;
        if (n) {
          if (!n?.[v])
            return;
          let y = typeof n[v] == "string" ? [n[v]] : n[v];
          if (!y.includes(p))
            throw new Error(`Cannot transition state from "${v}" to "${p}". Available transitions: ${y.map((B) => `"${B}"`).join(", ")}`);
        }
        l("end", v, ...w), this.state = p, l("enter", p, ...w), l("enter", `${v} -> ${p}`, ...w);
      }, onStateTransition(p, w, v) {
        return a("enter", `${p} -> ${w}`, v);
      }, onStateEnter(p, w) {
        return a("enter", p, w);
      }, onStateUpdate(p, w) {
        return a("update", p, w);
      }, onStateDraw(p, w) {
        return a("draw", p, w);
      }, onStateEnd(p, w) {
        return a("end", p, w);
      }, update() {
        d || (l("enter", e), d = true), l("update", this.state);
      }, draw() {
        l("draw", this.state);
      }, inspect() {
        return this.state;
      } };
    }
    u(Bi, "state");
    function Rt(e) {
      U.loaded ? e() : g.ev.on("load", e);
    }
    u(Rt, "onLoad");
    function Vi(e, t) {
      g.scenes[e] = t;
    }
    u(Vi, "scene");
    function Gi(e, ...t) {
      if (!g.scenes[e])
        throw new Error(`Scene not found: ${e}`);
      g.ev.onOnce("frameEnd", () => {
        g.ev = new le(), g.objEvents = new le(), g.root.get().forEach((n) => {
          n.stay || g.root.remove(n);
        }), g.root.clearEvents(), g.timers = new ce(), g.cam = { pos: null, scale: f(1), angle: 0, shake: 0, transform: new A() }, g.gravity = 0, g.scenes[e](...t), i.debug !== false && Pn(), i.burp && Rn();
      });
    }
    u(Gi, "go");
    function Ii(e, t) {
      try {
        return JSON.parse(window.localStorage[e]);
      } catch {
        return t ? (Fn(e, t), t) : null;
      }
    }
    u(Ii, "getData");
    function Fn(e, t) {
      window.localStorage[e] = JSON.stringify(t);
    }
    u(Fn, "setData");
    function Ln(e) {
      let t = e(Ve);
      for (let n in t)
        Ve[n] = t[n], i.global !== false && (window[n] = t[n]);
      return Ve;
    }
    u(Ln, "plug");
    function lt() {
      return f(k() / 2, L() / 2);
    }
    u(lt, "center");
    function Ni(e, t) {
      return { id: "grid", gridPos: t.clone(), setGridPos(...n) {
        let s = f(...n);
        this.gridPos = s.clone(), this.pos = f(this.gridPos.x * e.gridWidth(), this.gridPos.y * e.gridHeight());
      }, moveLeft() {
        this.setGridPos(this.gridPos.add(f(-1, 0)));
      }, moveRight() {
        this.setGridPos(this.gridPos.add(f(1, 0)));
      }, moveUp() {
        this.setGridPos(this.gridPos.add(f(0, -1)));
      }, moveDown() {
        this.setGridPos(this.gridPos.add(f(0, 1)));
      } };
    }
    u(Ni, "grid");
    function ji(e, t) {
      if (!t.width || !t.height)
        throw new Error("Must provide level grid width & height.");
      let n = xe([ut(t.pos ?? f(0))]), s = 0, h = { id: "level", gridWidth() {
        return t.width;
      }, gridHeight() {
        return t.height;
      }, getPos(...a) {
        let l = f(...a);
        return f(l.x * t.width, l.y * t.height);
      }, spawn(a, ...l) {
        let d = f(...l), p = (() => {
          if (t[a]) {
            if (typeof t[a] != "function")
              throw new Error("Level symbol def must be a function returning a component list");
            return t[a](d);
          } else if (t.any)
            return t.any(a, d);
        })();
        if (!p)
          return;
        let w = f(d.x * t.width, d.y * t.height);
        for (let v of p)
          if (v.id === "pos") {
            w.x += v.pos.x, w.y += v.pos.y;
            break;
          }
        return p.push(ut(w)), p.push(Ni(this, d)), n.add(p);
      }, levelWidth() {
        return s * t.width;
      }, levelHeight() {
        return e.length * t.height;
      } };
      return n.use(h), e.forEach((a, l) => {
        let d = a.split("");
        s = Math.max(d.length, s), d.forEach((p, w) => {
          n.spawn(p, f(w, l));
        });
      }), n;
    }
    u(ji, "addLevel");
    function ki(e) {
      let t = o.canvas.captureStream(e), n = T.ctx.createMediaStreamDestination();
      T.masterNode.connect(n);
      let s = new MediaRecorder(t), h = [];
      return s.ondataavailable = (a) => {
        a.data.size > 0 && h.push(a.data);
      }, s.onerror = () => {
        T.masterNode.disconnect(n), t.getTracks().forEach((a) => a.stop());
      }, s.start(), { resume() {
        s.resume();
      }, pause() {
        s.pause();
      }, stop() {
        return s.stop(), T.masterNode.disconnect(n), t.getTracks().forEach((a) => a.stop()), new Promise((a) => {
          s.onstop = () => {
            a(new Blob(h, { type: "video/mp4" }));
          };
        });
      }, download(a = "kaboom.mp4") {
        this.stop().then((l) => jt(a, l));
      } };
    }
    u(ki, "record");
    function _i() {
      return document.activeElement === o.canvas;
    }
    u(_i, "isFocused");
    function qi(e) {
      e.destroy();
    }
    u(qi, "destroy");
    let xe = g.root.add.bind(g.root), zi = g.root.readd.bind(g.root), Hi = g.root.removeAll.bind(g.root), Bn = g.root.get.bind(g.root), Vn = g.root.getAll.bind(g.root);
    function Gn(e = 2, t = 1) {
      let n = 0;
      return { id: "boom", require: ["scale"], update() {
        let s = Math.sin(n * e) * t;
        s < 0 && this.destroy(), this.scale = f(s), n += Q();
      } };
    }
    u(Gn, "boom");
    let $i = Pe(null, sr), Yi = Pe(null, or);
    function Xi(e, t = {}) {
      let n = xe([ut(e), Mn()]), s = (t.speed || 1) * 5, h = t.scale || 1;
      n.add([Pt(Yi), ct(0), Ot("center"), Gn(s, h), ...t.comps ?? []]);
      let a = n.add([Pt($i), ct(0), Ot("center"), Dn(0.4 / s, () => a.use(Gn(s, h))), ...t.comps ?? []]);
      return a.onDestroy(() => n.destroy()), n;
    }
    u(Xi, "addKaboom");
    function In() {
      g.timers.forEach((e, t) => {
        e.time -= Q(), e.time <= 0 && (e.action(), g.timers.delete(t));
      }), g.root.update();
    }
    u(In, "updateFrame");
    let Ki = 64;
    class ht {
      source;
      target;
      displacement;
      resolved = false;
      constructor(t, n, s, h = false) {
        this.source = t, this.target = n, this.displacement = s, this.resolved = h;
      }
      reverse() {
        return new ht(this.target, this.source, this.displacement.scale(-1), this.resolved);
      }
      isLeft() {
        return this.displacement.x > 0;
      }
      isRight() {
        return this.displacement.x < 0;
      }
      isTop() {
        return this.displacement.y > 0;
      }
      isBottom() {
        return this.displacement.y < 0;
      }
      preventResolve() {
        this.resolved = true;
      }
    }
    u(ht, "Collision");
    function Qi() {
      let e = {}, t = i.hashGridSize || Ki, n = new A(), s = [];
      function h(a) {
        if (s.push(n), a.pos && (n = n.translate(a.pos)), a.scale && (n = n.scale(a.scale)), a.angle && (n = n.rotateZ(a.angle)), a.transform = n.clone(), a.c("area") && !a.paused) {
          let l = a, p = l.worldArea().bbox(), w = Math.floor(p.pos.x / t), v = Math.floor(p.pos.y / t), y = Math.ceil((p.pos.x + p.width) / t), B = Math.ceil((p.pos.y + p.height) / t), P = /* @__PURE__ */ new Set();
          for (let q = w; q <= y; q++)
            for (let z2 = v; z2 <= B; z2++)
              if (!e[q])
                e[q] = {}, e[q][z2] = [l];
              else if (!e[q][z2])
                e[q][z2] = [l];
              else {
                let Ee = e[q][z2];
                for (let J of Ee) {
                  if (!J.exists() || P.has(J.id))
                    continue;
                  for (let S of l.collisionIgnore)
                    J.is(S);
                  for (let S of J.collisionIgnore)
                    l.is(S);
                  let _ = l.checkCollision(J);
                  if (_ && !_.isZero()) {
                    let S = new ht(l, J, _);
                    l.trigger("collideUpdate", J, S);
                    let N = S.reverse();
                    N.resolved = S.resolved, J.trigger("collideUpdate", l, N);
                  }
                  P.add(J.id);
                }
                Ee.push(l);
              }
        }
        a.get().forEach(h), n = s.pop();
      }
      u(h, "checkObj"), h(g.root);
    }
    u(Qi, "checkFrame");
    function Ji() {
      let e = g.cam, t = D.fromAngle(et(0, 360)).scale(e.shake);
      e.shake = ze(e.shake, 0, 5 * Q()), e.transform = new A().translate(lt()).scale(e.scale).rotateZ(e.angle).translate((e.pos ?? lt()).scale(-1).add(t)), g.root.draw(), fe();
    }
    u(Ji, "drawFrame");
    function Zi() {
      let e = V();
      ae(() => {
        let t = k() / 2, n = 24, s = f(k() / 2, L() / 2).sub(f(t / 2, n / 2));
        K({ pos: f(0), width: k(), height: L(), color: x(0, 0, 0) }), K({ pos: s, width: t, height: n, fill: false, outline: { width: 4 } }), K({ pos: s, width: t * e, height: n });
      }), g.ev.trigger("loading", e);
    }
    u(Zi, "drawLoadScreen");
    function Nn(e, t) {
      ae(() => {
        let n = f(8);
        W(), G(e);
        let s = ye({ text: t, font: pt, size: 16, pos: n, color: x(255, 255, 255), fixed: true }), h = s.width + n.x * 2, a = s.height + n.x * 2;
        e.x + h >= k() && G(f(-h, 0)), e.y + a >= L() && G(f(0, -a)), K({ width: h, height: a, color: x(0, 0, 0), radius: 4, opacity: 0.8, fixed: true }), Ue(s), X();
      });
    }
    u(Nn, "drawInspectText");
    function Wi() {
      if (F.inspect) {
        let e = null;
        for (let t of Vn())
          if (t.c("area") && t.isHovering()) {
            e = t;
            break;
          }
        if (g.root.drawInspect(), e) {
          let t = [], n = e.inspect();
          for (let s in n)
            n[s] ? t.push(`${s}: ${n[s]}`) : t.push(`${s}`);
          Nn(kr(ee()), t.join(`
`));
        }
        Nn(f(8), `FPS: ${F.fps()}`);
      }
      F.paused && ae(() => {
        W(), G(k(), 0), G(-8, 8);
        let e = 32;
        K({ width: e, height: e, anchor: "topright", color: x(0, 0, 0), opacity: 0.8, radius: 4, fixed: true });
        for (let t = 1; t <= 2; t++)
          K({ width: 4, height: e * 0.6, anchor: "center", pos: f(-e / 3 * t, e * 0.5), color: x(255, 255, 255), radius: 2, fixed: true });
        X();
      }), F.timeScale !== 1 && ae(() => {
        W(), G(k(), L()), G(-8, -8);
        let e = 8, t = ye({ text: F.timeScale.toFixed(1), font: pt, size: 16, color: x(255, 255, 255), pos: f(-e), anchor: "botright", fixed: true });
        K({ width: t.width + e * 2 + e * 4, height: t.height + e * 2, anchor: "botright", color: x(0, 0, 0), opacity: 0.8, radius: 4, fixed: true });
        for (let n = 0; n < 2; n++) {
          let s = F.timeScale < 1;
          rn({ p1: f(-t.width - e * (s ? 2 : 3.5), -e), p2: f(-t.width - e * (s ? 2 : 3.5), -e - t.height), p3: f(-t.width - e * (s ? 3.5 : 2), -e - t.height / 2), pos: f(-n * e * 1 + (s ? -e * 0.5 : 0), 0), color: x(255, 255, 255), fixed: true });
        }
        Ue(t), X();
      }), F.curRecording && ae(() => {
        W(), G(0, L()), G(24, -24), be({ radius: 12, color: x(255, 0, 0), opacity: Vt(0, 1, Ct() * 4), fixed: true }), X();
      }), F.showLog && g.logs.length > 0 && ae(() => {
        W(), G(0, L()), G(8, -8);
        let e = 8, t = ye({ text: g.logs.join(`
`), font: pt, pos: f(e, -e), anchor: "botleft", size: 16, width: k() * 0.6, lineSpacing: e / 2, fixed: true, styles: { time: { color: x(127, 127, 127) }, info: { color: x(255, 255, 255) }, error: { color: x(255, 0, 127) } } });
        K({ width: t.width + e * 2, height: t.height + e * 2, anchor: "botleft", color: x(0, 0, 0), radius: 4, opacity: 0.8, fixed: true }), Ue(t), X();
      });
    }
    u(Wi, "drawDebug");
    function es() {
      let e = ee(), t = u((s, h, a) => {
        be({ radius: 80 / 2, pos: s, outline: { width: 4, color: x(0, 0, 0) }, opacity: 0.5 }), a && it({ text: a, pos: s, color: x(0, 0, 0), size: 40, anchor: "center", opacity: 0.5 }), Fe("left") && Jn(new pe(s, 80 / 2), e) && g.ev.onOnce("frameEnd", () => {
          o.virtualButtonStates[h] = "pressed", o.keyStates[h] = "pressed";
        }), Je("left") && g.ev.onOnce("frameEnd", () => {
          o.virtualButtonStates[h] = "released", o.keyStates[h] = "released";
        });
      }, "drawCircleButton"), n = u((s, h, a) => {
        K({ width: 64, height: 64, pos: s, outline: { width: 4, color: x(0, 0, 0) }, radius: 4, anchor: "center", opacity: 0.5 }), a && it({ text: a, pos: s, color: x(0, 0, 0), size: 40, anchor: "center", opacity: 0.5 }), Fe("left") && He(new I(s.add(-64 / 2, -64 / 2), 64, 64), e) && g.ev.onOnce("frameEnd", () => {
          o.virtualButtonStates[h] = "pressed", o.keyStates[h] = "pressed";
        }), Je("left") && g.ev.onOnce("frameEnd", () => {
          o.virtualButtonStates[h] = "released", o.keyStates[h] = "released";
        });
      }, "drawSquareButton");
      ae(() => {
        t(f(k() - 80, L() - 160), "a"), t(f(k() - 160, L() - 80), "b"), n(f(60, L() - 124), "left"), n(f(188, L() - 124), "right"), n(f(124, L() - 188), "up"), n(f(124, L() - 60), "down");
      });
    }
    u(es, "drawVirtualControls"), i.debug !== false && Pn(), i.burp && Rn();
    function ts(e) {
      g.ev.on("loading", e);
    }
    u(ts, "onLoadUpdate");
    function ns(e) {
      g.ev.on("resize", e);
    }
    u(ns, "onResize");
    function rs(e) {
      g.ev.on("error", e);
    }
    u(rs, "onError");
    function Dt(e) {
      jn(() => {
        ae(() => {
          let s = k(), h = L(), a = { size: 36, width: s - 32 * 2, letterSpacing: 4, lineSpacing: 4, font: pt, fixed: true };
          K({ width: s, height: h, color: x(0, 0, 255), fixed: true });
          let l = ye({ ...a, text: e.name, pos: f(32), color: x(255, 128, 0), fixed: true });
          Ue(l), it({ ...a, text: e.message, pos: f(32, 32 + l.height + 16), fixed: true }), X(), g.ev.trigger("error", e);
        });
      });
    }
    u(Dt, "handleErr");
    function is() {
      for (let e in o.keyStates)
        o.keyStates[e] = Ht(o.keyStates[e]);
      for (let e in o.mouseStates)
        o.mouseStates[e] = Ht(o.mouseStates[e]);
      for (let e in o.virtualButtonStates)
        o.virtualButtonStates[e] = Ht(o.virtualButtonStates[e]);
      o.charInputted = [], o.isMouseMoved = false, o.isKeyPressed = false, o.isKeyPressedRepeat = false, o.isKeyReleased = false;
    }
    u(is, "resetInputState");
    function jn(e) {
      o.loopID !== null && cancelAnimationFrame(o.loopID);
      let t = u((n) => {
        if (o.stopped)
          return;
        if (document.visibilityState !== "visible") {
          o.loopID = requestAnimationFrame(t);
          return;
        }
        let s = n / 1e3, h = s - o.realTime;
        o.realTime = s, o.skipTime || (o.dt = h, o.time += Q(), o.fpsCounter.tick(o.dt)), o.skipTime = false, o.numFrames++, Pr(), e(), Rr(), is(), g.ev.trigger("frameEnd"), o.loopID = requestAnimationFrame(t);
      }, "frame");
      t(0);
    }
    u(jn, "run");
    function ss() {
      g.ev.onOnce("frameEnd", () => {
        o.stopped = true, c2.clear(c2.COLOR_BUFFER_BIT | c2.DEPTH_BUFFER_BIT | c2.STENCIL_BUFFER_BIT);
        let e = c2.getParameter(c2.MAX_TEXTURE_IMAGE_UNITS);
        for (let t = 0; t < e; t++)
          c2.activeTexture(c2.TEXTURE0 + t), c2.bindTexture(c2.TEXTURE_2D, null), c2.bindTexture(c2.TEXTURE_CUBE_MAP, null);
        c2.bindBuffer(c2.ARRAY_BUFFER, null), c2.bindBuffer(c2.ELEMENT_ARRAY_BUFFER, null), c2.bindRenderbuffer(c2.RENDERBUFFER, null), c2.bindFramebuffer(c2.FRAMEBUFFER, null), r.forEach((t) => t()), c2.deleteBuffer(m.vbuf), c2.deleteBuffer(m.ibuf);
        for (let t in $)
          o.canvas.removeEventListener(t, $[t]);
        for (let t in Qe)
          document.removeEventListener(t, Qe[t]);
        for (let t in Me)
          window.removeEventListener(t, Me[t]);
      });
    }
    u(ss, "quit"), Ae("happy", rr, 28, 36), jn(() => {
      U.loaded || V() === 1 && (U.loaded = true, g.ev.trigger("load")), !U.loaded && i.loadingScreen !== false ? Zi() : (g.ev.trigger("input"), F.paused || In(), Qi(), Ji(), i.debug !== false && Wi(), i.virtualControls && bn() && es());
    });
    function os(e, t, n, s, h = qe.linear) {
      let a = 0, l = xn(() => {
        a += Q();
        let d = Math.min(a / n, 1);
        s(ze(e, t, h(d))), d === 1 && l();
      });
      return l;
    }
    u(os, "tween");
    let Ve = { VERSION: xs, loadRoot: Y, loadProgress: V, loadSprite: Pe, loadSpriteAtlas: Yt, loadSound: xr, loadBitmapFont: Ae, loadFont: bt, loadShader: Ur, loadAseprite: yr, loadPedit: vr, loadBean: Er, load: de, getSprite: Xt, getSound: Kt, getFont: Sr, getBitmapFont: Qt, getShader: Jt, Asset: O, SpriteData: C, SoundData: R, width: k, height: L, center: lt, dt: Q, time: Ct, screenshot: qr, record: ki, isFocused: _i, setCursor: wn, setFullscreen: zr, isFullscreen: Tt, isTouchScreen: bn, onLoad: Rt, onLoadUpdate: ts, onResize: ns, onError: rs, camPos: Hr, camScale: $r, camRot: Yr, shake: Xr, toScreen: At, toWorld: vn, gravity: fi, add: xe, destroy: qi, destroyAll: Hi, get: Bn, getAll: Vn, readd: zi, pos: ut, scale: ct, rotate: mi, color: pi, opacity: gi, anchor: Ot, area: Ui, sprite: Pt, text: xi, rect: Ei, circle: Ci, uvquad: Si, outline: Ti, body: Pi, doubleJump: Ri, shader: Di, timer: Dn, fixed: Mi, stay: Mn, health: Fi, lifespan: Li, z: wi, move: vi, outview: yi, follow: bi, state: Bi, on: Le, onUpdate: xn, onDraw: Kr, onAdd: En, onDestroy: Qr, onCollide: Jr, onClick: Zr, onHover: Wr, onHoverUpdate: ei, onHoverEnd: ti, onKeyDown: Cn, onKeyPress: ue, onKeyPressRepeat: Tn, onKeyRelease: An, onMouseDown: ri, onMousePress: On, onMouseRelease: ii, onMouseMove: si, onCharInput: oi, onTouchStart: ai, onTouchMove: ui, onTouchEnd: ci, onVirtualButtonPress: li, onVirtualButtonDown: hi, onVirtualButtonRelease: di, mousePos: ee, mouseDeltaPos: ln, isKeyDown: fn, isKeyPressed: ot, isKeyPressedRepeat: dn, isKeyReleased: St, isMouseDown: Et, isMousePressed: Fe, isMouseReleased: Je, isMouseMoved: hn, isVirtualButtonPressed: mn, isVirtualButtonDown: pn, isVirtualButtonReleased: gn, loop: ni, wait: Sn, play: Ye, volume: Ar, burp: en, audioCtx: T.ctx, Timer: he, Line: ie, Rect: I, Circle: pe, Polygon: oe, Vec2: D, Color: E, Mat4: A, Quad: j, RNG: ke, rand: et, randi: Gt, randSeed: $n, vec2: f, rgb: x, hsl2rgb: zn, quad: Hn, choose: Xn, chance: Yn, lerp: ze, tween: os, easings: qe, map: dt, mapc: qn, wave: Vt, deg2rad: me, rad2deg: Bt, testLineLine: Ne, testRectRect: Kn, testRectLine: Qn, testRectPoint: He, drawSprite: tn, drawText: it, formatText: ye, drawRect: K, drawLine: Ke, drawLines: nn, drawTriangle: rn, drawCircle: be, drawEllipse: sn, drawUVQuad: De, drawPolygon: ve, drawFormattedText: Ue, drawMasked: Gr, drawSubtracted: Ir, pushTransform: W, popTransform: X, pushTranslate: G, pushScale: Re, pushRotate: Br, pushRotateX: Fr, pushRotateY: Lr, pushRotateZ: we, pushMatrix: Mr, debug: F, scene: Vi, go: Gi, addLevel: ji, getData: Ii, setData: Fn, download: ft, downloadJSON: tr, downloadText: Nt, downloadBlob: jt, plug: Ln, ASCII_CHARS: cr, canvas: o.canvas, addKaboom: Xi, LEFT: D.LEFT, RIGHT: D.RIGHT, UP: D.UP, DOWN: D.DOWN, RED: E.RED, GREEN: E.GREEN, BLUE: E.BLUE, YELLOW: E.YELLOW, MAGENTA: E.MAGENTA, CYAN: E.CYAN, WHITE: E.WHITE, BLACK: E.BLACK, quit: ss };
    if (i.plugins && i.plugins.forEach(Ln), i.global !== false)
      for (let e in Ve)
        window[e] = Ve[e];
    return Ve;
  }, "default");

  // src/components.js
  function checkbox(spr, spr2, icon, oncheck, onuncheck, extraT = "unuseful") {
    return {
      id: "checkbox",
      requires: ["area"],
      checked: false,
      add() {
        this.use(sprite(spr));
        this.check = add([
          sprite(spr2),
          anchor("center"),
          z(100),
          pos(spr2 === "correct" ? this.pos.add(6, -5) : this.pos.clone()),
          "gui",
          "check",
          extraT,
          {
            checked: false
          }
        ]);
        this.check.hidden = true;
        if (icon)
          add([
            sprite(icon),
            pos(this.pos.add(40, 0)),
            anchor("center"),
            "gui"
          ]);
        this.onClick(() => {
          this.checked = !this.checked;
          this.check.checked = this.checked;
          if (this.checked) {
            this.check.hidden = false;
            this.onCheck();
          } else {
            this.check.hidden = true;
            this.onUnCheck();
          }
        });
      },
      onCheck() {
        if (oncheck)
          oncheck();
      },
      onUnCheck() {
        if (onuncheck)
          onuncheck();
      },
      isChecked() {
        return this.checked;
      }
    };
  }
  function tlsprite(spr, langs) {
    return {
      id: "tlsprite",
      require: ["sprite"],
      lang: "n",
      add() {
        this.langs = langs;
      },
      changeLang(lang) {
        this.lang = lang;
        this.use(sprite(`${lang}_${spr}`));
      }
    };
  }
  function tltext(texts) {
    return {
      id: "tltext",
      require: ["text"],
      lang: "n",
      dfont: "n",
      add() {
        this.langs = /* @__PURE__ */ new Map();
        this.langs.set(this.lang, this.text);
        this.dfont = this.font;
        texts.map((t) => {
          this.langs.set(t.lang, t);
        });
      },
      changeLang(lang) {
        const l = this.langs.get(lang);
        this.lang = lang;
        this.use(text(l.text, { size: this.textSize, font: `${l.lang}_${this.dfont}` }));
      }
    };
  }

  // src/main.ts
  co({
    width: 576,
    height: 324,
    letterbox: true,
    stretch: true,
    background: [141, 183, 255],
    touchToMouse: true,
    debug: true,
    font: "en_juiceisntbelow",
    canvas: document.querySelector("#myGame")
  });
  var OUTFITS_COUNT = 0;
  var HAIR_COUNT = 0;
  var FACES_COUNT = 0;
  var EN_CHARS = " ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890\xD1\xF1,.?!+-=_:;/\\\xBF\xA1@#'&*<>[]{}()$%\u20AC~`|";
  var JP_CHARS = " \u4E0B\u904A\u65E5\u672C\u4EBA\u63CF\u98F2\u58F2\u4F7F\u30A2\u30D7\u30AF\u30EA\u30B7\u30B8\u30E6\u30E5\u30B9\u30CD\u30C3\u30C4\u30A8\u30C7\u30A4\u30C8\u30E3\u30E5\u30E7\u30A3\u3042\u3044\u306A\u3060\u306F\u3076\u3058\u3083\u308A\u307E\u3093\u3057\u3066\u3059\u3067\u304C\u3068\u3046\u3054\u3056\u3044\u306E\u3092\u3064\u3063x\u3073\u697D\u97F3\u51FA\u7248\u793E";
  var bgs = [
    rgb(141, 183, 255),
    rgb(57, 9, 71),
    Color.fromHex("ffb879"),
    Color.fromHex("834dc4")
  ];
  var rooms = [
    camPos().clone(),
    camPos().clone().add(width(), 0)
  ];
  var layers = {
    belowbody: 1,
    hair: 2,
    body: 3,
    belowface: 4,
    face: 5,
    outfit: 6,
    fronthair: 7
  };
  var bgMusic;
  loadSprite("about", "./sprites/about.png");
  loadSprite("arrow", "./sprites/arrow.png");
  loadSprite("body", "./sprites/body.png");
  loadSprite("button", "./sprites/button.png");
  loadSprite("catwithhotdog", "./sprites/catwithhotdog.png");
  loadSprite("checkbox", "./sprites/checkbox.png");
  loadSprite("correct", "./sprites/correct.png");
  loadSprite("default", "./sprites/default.png");
  loadSprite("download", "./sprites/download.png");
  loadSprite("flush", "./sprites/flush.png");
  loadSprite("flush_icon", "./sprites/flush_icon.png");
  loadSprite("guicheck", "./sprites/guicheck.png");
  loadSprite("incorrect", "./sprites/incorrect.png");
  loadSprite("musiccheck", "./sprites/musiccheck.png");
  loadSprite("neko", "./sprites/neko.png");
  loadSprite("neko_icon", "./sprites/neko_icon.png");
  loadSprite("palette", "./sprites/palette.png");
  loadSprite("pointer", "./sprites/pointer.png");
  loadSprite("random", "./sprites/random.png");
  loadSprite("sorbet", "./sprites/sorbet.png");
  loadSprite("sorbet_icon", "./sprites/sorbet_icon.png");
  loadSprite("en_title", "./sprites/title.png");
  loadSprite("jp_title", "./sprites/jp_title.png");
  loadAseprite("hair", "./sprites/hair.png", "./sprites/hair.json").onLoad((d) => {
    HAIR_COUNT = d.frames.length / 2;
  });
  loadAseprite("faces", "./sprites/faces.png", "./sprites/faces.json").onLoad((d) => {
    FACES_COUNT = d.frames.length;
  });
  loadAseprite("outfits", "./sprites/outfits.png", "./sprites/outfits.json").onLoad((d) => {
    OUTFITS_COUNT = d.frames.length;
  });
  loadSound("chillaxation", "./sounds/chillaxation.mp3");
  loadBitmapFont("juiceisntbelow", "./sprites/thejuiceisntbelow.png", 26, 37, { chars: EN_CHARS });
  loadBitmapFont("en_juiceisntbelow", "./sprites/thejuiceisntbelow.png", 26, 37, { chars: EN_CHARS });
  loadBitmapFont("jp_juiceisntbelow", "./sprites/thejuiceisntbelow_jp.png", 26, 37, { chars: JP_CHARS });
  var camHelper = add([
    pos(camPos().sub(width(), 0))
  ]);
  camHelper.onUpdate(() => camPos(camHelper.pos));
  onClick("camera_changer", (ch) => {
    tween(camHelper.pos.x, ch.to.x, 0.9, (val) => camHelper.pos.x = val, easings.easeOutBounce);
  });
  onLoad(() => {
    const attr = document.getElementById("myGame")?.attributes.style.nodeValue;
    document.getElementById("myGame")?.setAttribute("style", attr.replace("default", "none;"));
  });
  var canvasIsHover = () => canvas.parentElement?.querySelector(":hover") === canvas;
  var c = add([
    sprite("default"),
    pos(0, 0),
    z(1e3),
    fixed(),
    {
      h: false
    }
  ]);
  c.hidden = true;
  onUpdate(() => {
    const canvasIsHovered = canvasIsHover();
    if (canvasIsHovered !== c.h) {
      if (canvasIsHovered === true)
        c.hidden = false;
      else
        c.hidden = true;
      c.h = canvasIsHover();
    }
    c.pos = mousePos();
  });
  add([
    text("click\n to\nstart", { size: 36, font: "juiceisntbelow" }),
    tltext([
      { lang: "en", text: "click\n to\nstart" },
      { lang: "jp", text: "\u30AF\u30EA\u30C3\u30AF\u3057\u3066\n\u904A\u3073\u307E\u3059" }
    ]),
    color(74, 48, 82),
    anchor("center"),
    pos(center().sub(width(), 0))
  ]);
  var cts = add([
    rect(width(), height()),
    opacity(0),
    pos(-width(), 0),
    area()
  ]);
  cts.onClick(() => {
    tween(camHelper.pos.x, rooms[0].x, 0.9, (val) => camHelper.pos.x = val, easings.easeOutBounce);
    bgMusic = play("chillaxation", { volume: 0.05, loop: true });
    cts.destroy();
  });
  var bg = add([
    pos(0, 0),
    rect(width(), height()),
    color(bgs[0]),
    {
      cur: 0
    }
  ]);
  var title = add([
    sprite("en_title"),
    pos(center().x - 25, 30),
    anchor("center"),
    z(50),
    tlsprite("title", ["en", "jp"])
  ]);
  var body = add([
    sprite("body"),
    pos(center().x, height()),
    anchor("bot"),
    z(layers.body)
  ]);
  var hair = add([
    pos(body.pos.add(0, -193)),
    anchor("top"),
    z(layers.hair),
    "hair",
    {
      cur: 0
    }
  ]);
  add([
    pos(body.pos.add(0, -193)),
    anchor("top"),
    z(layers.fronthair),
    "fronthair"
  ]);
  var face = add([
    pos(center().x, height() - 86),
    anchor("bot"),
    z(layers.face),
    "faces",
    {
      cur: 0
    }
  ]);
  var outfit = add([
    pos(center().x, height()),
    anchor("bot"),
    z(layers.outfit),
    "outfits",
    {
      cur: 0
    }
  ]);
  var neko = add([
    pos(body.pos.add(0, -158)),
    sprite("neko"),
    anchor("center"),
    z(layers.belowbody),
    "extra"
  ]);
  var sorbet = add([
    pos(body.pos.add(-14, -178)),
    sprite("sorbet"),
    z(layers.belowbody),
    "extra"
  ]);
  var flush = add([
    pos(body.pos.add(0, -118)),
    sprite("flush"),
    anchor("center"),
    z(layers.belowface),
    "extra"
  ]);
  get("extra").forEach((obj) => obj.hidden = true);
  add([
    pos(25, 156),
    color(74, 48, 82),
    z(50),
    area(),
    anchor("center"),
    checkbox("guicheck", "incorrect", "", hideGui, showGui, "nohide"),
    "bc"
  ]);
  var changeBG = add([
    sprite("palette"),
    anchor("center"),
    pos(title.pos.add(160, 0)),
    z(50),
    area(),
    {
      change() {
        if (bg.cur >= bgs.length)
          bg.cur = 0;
        bg.color = bgs[bg.cur];
      }
    }
  ]);
  changeBG.onClick(() => {
    bg.cur++;
    changeBG.change();
  });
  var random = add([
    sprite("random"),
    color(74, 48, 82),
    anchor("center"),
    pos(25, 256),
    z(50),
    area(),
    "bc"
  ]);
  random.onClick(randomPart);
  add([
    pos(25, 206),
    color(74, 48, 82),
    z(50),
    area(),
    anchor("center"),
    checkbox(
      "musiccheck",
      "incorrect",
      "",
      () => bgMusic.volume(0),
      () => bgMusic.volume(0.05),
      "nohide"
    ),
    "bc"
  ]);
  addLeftButton(body.pos.add(-85, -160), "hair");
  addRightButton(body.pos.add(83, -160), "hair");
  addLeftButton(body.pos.add(-65, -110), "faces");
  addRightButton(body.pos.add(63, -110), "faces");
  addLeftButton(body.pos.add(-70, -28), "outfits");
  addRightButton(body.pos.add(68, -28), "outfits");
  add([
    pos(center().x - 120 - 24.5, 80),
    z(50),
    color(74, 48, 82),
    area(),
    anchor("center"),
    checkbox(
      "checkbox",
      "correct",
      "sorbet_icon",
      () => sorbet.hidden = false,
      () => sorbet.hidden = true
    ),
    "gui",
    "bc"
  ]);
  add([
    pos(center().x - 24.5, 80),
    color(74, 48, 82),
    z(50),
    area(),
    anchor("center"),
    checkbox(
      "checkbox",
      "correct",
      "flush_icon",
      () => flush.hidden = false,
      () => flush.hidden = true
    ),
    "gui",
    "bc"
  ]);
  add([
    pos(center().x + 120 - 24.5, 80),
    z(50),
    color(74, 48, 82),
    area(),
    anchor("center"),
    checkbox(
      "checkbox",
      "correct",
      "neko_icon",
      () => neko.hidden = false,
      () => neko.hidden = true
    ),
    "gui",
    "bc"
  ]);
  var about = add([
    pos(width() + 6, 0)
  ]);
  add([
    text("the juicy edit", { size: 22, font: "juiceisntbelow" }),
    tltext([
      { lang: "en", text: "the juicy edit" },
      { lang: "jp", text: "\u30B8\u30E5x\u30B9\u30C7\u30A3\u30C8" }
    ]),
    pos(about.pos.add(4, 10)),
    color(74, 48, 82)
  ]);
  about.add([
    text("by lajbel", { size: 16 }),
    pos(4, 30),
    color(74, 48, 82)
  ]);
  add([
    text("Music", { size: 18, font: "juiceisntbelow" }),
    tltext([
      { lang: "en", text: "Music" },
      { lang: "jp", text: "\u697D\u97F3" }
    ]),
    pos(about.pos.add(4, 54)),
    color(74, 48, 82)
  ]);
  about.add([
    text("HibbityBibbityBop", { size: 16 }),
    pos(4, 72),
    color(74, 48, 82)
  ]);
  add([
    text("Publishing", { size: 18, font: "juiceisntbelow" }),
    tltext([
      { lang: "en", text: "Publishing" },
      { lang: "jp", text: "\u51FA\u7248\u793E" }
    ]),
    pos(about.pos.add(4, 96)),
    color(74, 48, 82)
  ]);
  about.add([
    text("The Juicy Sorbet", { size: 16 }),
    pos(4, 114),
    color(74, 48, 82)
  ]);
  add([
    text("Japanese Translation", { size: 18, font: "juiceisntbelow" }),
    tltext([
      { lang: "en", text: "Japanese Translation" },
      { lang: "jp", text: "\u65E5\u672C" }
    ]),
    pos(about.pos.add(4, 138)),
    color(74, 48, 82)
  ]);
  about.add([
    text("Hoshi", { size: 16 }),
    pos(4, 156),
    color(74, 48, 82)
  ]);
  about.add([
    sprite("catwithhotdog"),
    pos(230, 10)
  ]);
  add([
    sprite("about"),
    anchor("topright"),
    color(74, 48, 82),
    pos(width() - 3, 3),
    area(),
    "camera_changer",
    "bc",
    "gui",
    {
      to: rooms[1]
    }
  ]);
  add([
    sprite("arrow"),
    anchor("botleft"),
    color(74, 48, 82),
    pos(width() + 3, height() - 5),
    area(),
    "camera_changer",
    "bc",
    "gui",
    {
      to: rooms[0]
    }
  ]);
  onHover("bc", (o) => {
    o.color = rgb(31, 16, 42);
  });
  onHoverEnd("bc", (o) => {
    o.color = rgb(74, 48, 82);
  });
  onHover("btn", (btn2) => {
    btn2.color = rgb(135, 62, 132);
  });
  onHoverEnd("btn", (btn2) => {
    btn2.color = rgb(212, 110, 179);
  });
  onClick("left", (b) => {
    btn(b, true);
  });
  onClick("right", (b) => {
    btn(b, false);
  });
  onKeyPressRepeat("r", randomPart);
  function addLeftButton(pos2, toChange) {
    addButton(1, pos2, toChange, "left");
  }
  function addRightButton(pos2, toChange) {
    addButton(0, pos2, toChange, "right");
  }
  function addButton(number, w, thing, side) {
    add([
      sprite("button", { flipX: number }),
      color(212, 110, 179),
      pos(w),
      anchor("center"),
      area(),
      z(10),
      "btn",
      "gui",
      thing,
      side
    ]);
  }
  function randomPart() {
    hair.cur = Math.round((Math.random() * (HAIR_COUNT - 0) + 0) / 2) * 2;
    face.cur = randi(FACES_COUNT);
    outfit.cur = randi(OUTFITS_COUNT);
    setPart2(HAIR_COUNT, "hair", "fronthair", true, false);
    setPart(FACES_COUNT, "faces", true, false);
    setPart(OUTFITS_COUNT, "outfits", true, false);
  }
  function hideGui() {
    get("gui").forEach((g) => {
      if (!g.is("nohide"))
        g.hidden = true;
    });
  }
  function showGui() {
    get("gui").forEach((g) => {
      if (g.is("ahide")) {
        g.hidden = true;
      } else {
        if (g.is("check")) {
          g.hidden = !g.checked;
        } else {
          g.hidden = false;
        }
      }
    });
  }
  function setPart(count, tag, sub, set = true) {
    const obj = get(tag)[0];
    if (set) {
      if (sub)
        obj.cur--;
      else
        obj.cur++;
      if (obj.cur < 0)
        obj.cur = count;
      else if (obj.cur > count)
        obj.cur = 0;
    }
    if (obj.cur === 0)
      obj.unuse("sprite");
    else
      obj.use(sprite(tag, { frame: obj.cur - 1 }));
  }
  function setPart2(count, tag, tag2, sub, set = true) {
    const obj = get(tag)[0];
    const obj2 = get(tag2)[0];
    if (set) {
      if (sub)
        obj.cur = obj.cur - 2;
      else
        obj.cur = obj.cur + 2;
      if (obj.cur < 0)
        obj.cur = count * 2;
      else if (obj.cur > count * 2)
        obj.cur = 0;
    }
    if (obj.cur == 0) {
      obj.unuse("sprite");
      obj2.unuse("sprite");
    } else {
      obj.use(sprite(tag, { frame: obj.cur - 2 }));
      obj2.use(sprite(tag, { frame: obj.cur - 1 }));
    }
  }
  function btn(b, s) {
    if (b.is("hair"))
      setPart2(HAIR_COUNT, "hair", "fronthair", s);
    else if (b.is("faces"))
      setPart(FACES_COUNT, "faces", s);
    else if (b.is("outfits"))
      setPart(OUTFITS_COUNT, "outfits", s);
  }
  getAll().forEach((o) => {
    if (!o.is("area"))
      return;
    o.onHover(() => {
      c.use(sprite("pointer"));
    });
    o.onHoverEnd(() => {
      c.use(sprite("default"));
    });
  });
})();
